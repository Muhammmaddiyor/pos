"use client"
import { addDays, format } from "date-fns"
import { CalendarIcon } from "lucide-react"
import type { DateRange } from "react-day-picker"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"

interface DatePickerWithRangeProps {
  className?: string
  date?: DateRange
  setDate: (date: DateRange | undefined) => void
}

export function DatePickerWithRange({ className, date, setDate }: DatePickerWithRangeProps) {
  return (
    <div className={cn("grid gap-2", className)}>
      <Popover>
        <PopoverTrigger asChild>
          <Button
            id="date"
            variant={"outline"}
            className={cn("w-[300px] justify-start text-left font-normal", !date && "text-muted-foreground")}
          >
            <CalendarIcon className="mr-2 h-4 w-4" />
            {date?.from ? (
              date.to ? (
                <>
                  {format(date.from, "dd/MM/yyyy")} - {format(date.to, "dd/MM/yyyy")}
                </>
              ) : (
                format(date.from, "dd/MM/yyyy")
              )
            ) : (
              <span>Sana oralig'ini tanlang</span>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <Calendar
            initialFocus
            mode="range"
            defaultMonth={date?.from}
            selected={date}
            onSelect={setDate}
            numberOfMonths={2}
          />
          <div className="p-3 border-t border-border">
            <div className="flex items-center justify-between gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() =>
                  setDate({
                    from: new Date(),
                    to: new Date(),
                  })
                }
              >
                Bugun
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() =>
                  setDate({
                    from: addDays(new Date(), -7),
                    to: new Date(),
                  })
                }
              >
                So'nggi 7 kun
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() =>
                  setDate({
                    from: addDays(new Date(), -30),
                    to: new Date(),
                  })
                }
              >
                So'nggi 30 kun
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() =>
                  setDate({
                    from: addDays(new Date(), -90),
                    to: new Date(),
                  })
                }
              >
                So'nggi 90 kun
              </Button>
            </div>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  )
}
