"use client"

import Image from "next/image"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import type { Product } from "@/lib/types"
import { PlusCircle, AlertTriangle, Scale, Package } from "lucide-react"

interface ProductCardProps {
  product: Product
  onAddToCart: (product: Product) => void
}

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat("uz-UZ", { style: "currency", currency: "UZS", minimumFractionDigits: 0 }).format(amount)
}

const formatStock = (quantity: number, unitType: "piece" | "weight") => {
  if (unitType === "weight") {
    return `${quantity.toFixed(3)} kg`
  }
  return `${quantity} ta`
}

export default function ProductCard({ product, onAddToCart }: ProductCardProps) {
  const isLowStock = product.stock_quantity <= product.min_stock_level
  const isOutOfStock = product.stock_quantity <= 0

  return (
    <Card
      className={`overflow-hidden flex flex-col h-full hover:shadow-lg transition-shadow ${isOutOfStock ? "opacity-50" : ""}`}
    >
      <CardHeader className="p-0 relative aspect-square">
        <Image
          src={product.image || "/placeholder.svg"}
          alt={product.name}
          width={150}
          height={150}
          className="object-cover w-full h-full"
        />
        {/* Unit type indicator */}
        <div className="absolute top-1 left-1">
          {product.unit_type === "weight" ? (
            <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-800 px-1 py-0.5">
              <Scale className="h-2 w-2 mr-0.5" />
              kg
            </Badge>
          ) : (
            <Badge variant="secondary" className="text-xs bg-gray-100 text-gray-800 px-1 py-0.5">
              <Package className="h-2 w-2 mr-0.5" />
              ta
            </Badge>
          )}
        </div>
        {/* Stock status */}
        {isLowStock && !isOutOfStock && (
          <Badge variant="destructive" className="absolute top-1 right-1 text-xs px-1 py-0.5">
            <AlertTriangle className="h-2 w-2 mr-0.5" />
            Kam
          </Badge>
        )}
        {isOutOfStock && (
          <Badge variant="destructive" className="absolute top-1 right-1 text-xs px-1 py-0.5">
            Tugagan
          </Badge>
        )}
      </CardHeader>
      <CardContent className="p-2 lg:p-3 flex-grow">
        <h3 className="text-xs lg:text-sm font-semibold truncate" title={product.name}>
          {product.name}
        </h3>
        <p className="text-xs text-muted-foreground">
          {formatCurrency(product.price)}
          {product.unit_type === "weight" ? " / kg" : ""}
        </p>
        <p className="text-xs text-muted-foreground">
          Qoldiq: {formatStock(product.stock_quantity, product.unit_type)}
        </p>
        {product.barcode && <p className="text-xs text-muted-foreground font-mono truncate">{product.barcode}</p>}
      </CardContent>
      <CardFooter className="p-1 lg:p-2 border-t">
        <Button
          variant="outline"
          size="sm"
          className="w-full h-8 lg:h-9 text-xs lg:text-sm"
          onClick={() => onAddToCart(product)}
          disabled={isOutOfStock}
        >
          <PlusCircle className="mr-1 lg:mr-2 h-3 w-3 lg:h-4 lg:w-4" />
          {isOutOfStock ? "Tugagan" : product.unit_type === "weight" ? "Tortish" : "Savatga"}
        </Button>
      </CardFooter>
    </Card>
  )
}
