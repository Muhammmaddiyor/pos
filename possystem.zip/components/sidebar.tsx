"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  Warehouse,
  Users,
  UserCheck,
  BarChart3,
  CreditCard,
  Settings,
  Store,
  RotateCcw,
  AlertTriangle,
  DollarSign,
  UsersRound,
  AreaChart,
  BookmarkCheck,
} from "lucide-react"

const navItems = [
  { href: "/dashboard", label: "Asosiy Panel", icon: LayoutDashboard },
  { href: "/sales", label: "Sotuv", icon: ShoppingCart },
  { href: "/products", label: "Mahsulotlar", icon: Package },
  { href: "/warehouse", label: "Ombor", icon: Warehouse },
  { href: "/suppliers", label: "Ta'minotchilar", icon: UsersRound },
  { href: "/corrections", label: "Korrektirovka", icon: RotateCcw },
  { href: "/customers", label: "Mijozlar", icon: Users },
  { href: "/debtors", label: "Qarzdorlar", icon: AlertTriangle },
  { href: "/expenses", label: "Harajatlar", icon: DollarSign },
  { href: "/employees", label: "Xodimlar", icon: UserCheck },
  { href: "/reports", label: "Hisobotlar", icon: BarChart3 },
  { href: "/analytics", label: "Analitika", icon: AreaChart },
  { href: "/cash-register", label: "Kassa", icon: CreditCard },
  { href: "/delivery", label: "BAND", icon: BookmarkCheck },
  { href: "/settings", label: "Sozlamalar", icon: Settings },
]

export default function Sidebar() {
  const pathname = usePathname()

  return (
    <aside className="w-64 flex-shrink-0 border-r bg-background flex flex-col">
      <div className="h-16 border-b flex items-center px-6">
        <Link href="/dashboard" className="flex items-center gap-2 font-bold text-lg">
          <Store className="h-6 w-6 text-primary" />
          <span>POS Pro</span>
        </Link>
      </div>
      <nav className="flex-1 px-4 py-4 overflow-y-auto">
        <ul className="space-y-1">
          {navItems.map((item) => (
            <li key={item.href}>
              <Link
                href={item.href}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary hover:bg-muted",
                  pathname.startsWith(item.href) && "bg-muted text-primary",
                )}
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  )
}
