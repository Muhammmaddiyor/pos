"use client"

import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { PlusCircle, MinusCircle, Trash2, Scale, Package } from "lucide-react"
import type { CartItem } from "@/lib/types"

interface CartItemRowProps {
  item: CartItem
  onUpdateQuantity: (productId: string, change: number) => void
  onSetExactQuantity: (productId: string, quantity: number) => void
  onRemoveItem: (productId: string) => void
  formatCurrency: (amount: number) => string
  formatQuantity: (quantity: number, unitType: "piece" | "weight") => string
}

// Vazn input uchun formatlash funksiyasi
const formatWeightInput = (value: string) => {
  if (value === "0") {
    return "0,"
  }

  if (value.length === 2 && value.startsWith("0") && /\d/.test(value[1])) {
    return `0,${value[1]}`
  }

  return value.replace(".", ",")
}

// Vazn qiymatini raqamga aylantirish
const parseWeightValue = (value: string) => {
  return Number.parseFloat(value.replace(",", "."))
}

export default function CartItemRow({
  item,
  onUpdateQuantity,
  onSetExactQuantity,
  onRemoveItem,
  formatCurrency,
  formatQuantity,
}: CartItemRowProps) {
  const handleQuantityInputChange = (value: string) => {
    if (item.unit_type === "weight") {
      const formattedValue = formatWeightInput(value)
      const quantity = parseWeightValue(formattedValue)
      if (!isNaN(quantity) && quantity >= 0) {
        onSetExactQuantity(item.id, quantity)
      }
    } else {
      const quantity = Number.parseFloat(value)
      if (!isNaN(quantity) && quantity >= 0) {
        onSetExactQuantity(item.id, quantity)
      }
    }
  }

  const getStepSize = () => {
    return item.unit_type === "weight" ? 0.1 : 1
  }

  const formatInputValue = () => {
    if (item.unit_type === "weight") {
      return item.quantity.toFixed(3).replace(".", ",")
    }
    return item.quantity.toString()
  }

  return (
    <div className="flex items-center gap-2 lg:gap-3 p-2 border rounded-md hover:bg-accent">
      <Image
        src={item.image || "/placeholder.svg"}
        alt={item.name}
        width={32}
        height={32}
        className="lg:w-10 lg:h-10 rounded-md object-cover"
      />
      <div className="flex-grow min-w-0">
        <div className="flex items-center gap-1 lg:gap-2">
          <p className="text-xs lg:text-sm font-medium truncate" title={item.name}>
            {item.name}
          </p>
          {item.unit_type === "weight" ? (
            <Scale className="h-2 w-2 lg:h-3 lg:w-3 text-blue-600 flex-shrink-0" />
          ) : (
            <Package className="h-2 w-2 lg:h-3 lg:w-3 text-gray-600 flex-shrink-0" />
          )}
        </div>
        <p className="text-xs text-muted-foreground">
          {formatCurrency(item.price)}
          {item.unit_type === "weight" ? " / kg" : ""}
        </p>
        <p className="text-xs text-muted-foreground hidden lg:block">
          Qoldiq: {formatQuantity(item.stock_quantity, item.unit_type)}
        </p>
      </div>
      <div className="flex items-center gap-0.5 lg:gap-1">
        <Button
          variant="ghost"
          size="icon"
          className="h-6 w-6 lg:h-7 lg:w-7"
          onClick={() => onUpdateQuantity(item.id, -1)}
        >
          <MinusCircle className="h-3 w-3 lg:h-4 lg:w-4" />
          <span className="sr-only">Kamaytirish</span>
        </Button>
        <Input
          type="text"
          inputMode={item.unit_type === "weight" ? "decimal" : "numeric"}
          value={formatInputValue()}
          onChange={(e) => handleQuantityInputChange(e.target.value)}
          className="h-6 w-12 lg:h-7 lg:w-16 text-center px-1 text-xs"
          min="0"
        />
        <Button
          variant="ghost"
          size="icon"
          className="h-6 w-6 lg:h-7 lg:w-7"
          onClick={() => onUpdateQuantity(item.id, 1)}
        >
          <PlusCircle className="h-3 w-3 lg:h-4 lg:w-4" />
          <span className="sr-only">Ko'paytirish</span>
        </Button>
      </div>
      <p className="text-xs lg:text-sm font-medium w-16 lg:w-20 text-right">
        {formatCurrency(item.price * item.quantity)}
      </p>
      <Button
        variant="ghost"
        size="icon"
        className="h-6 w-6 lg:h-7 lg:w-7 text-destructive hover:text-destructive"
        onClick={() => onRemoveItem(item.id)}
      >
        <Trash2 className="h-3 w-3 lg:h-4 lg:w-4" />
        <span className="sr-only">O'chirish</span>
      </Button>
    </div>
  )
}
