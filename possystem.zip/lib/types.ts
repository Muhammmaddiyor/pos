// Asosiy turlar va interfeyslar
export interface Product {
  id: string
  name: string
  price: number
  cost: number
  barcode?: string
  category_id: string
  brand?: string
  min_stock_level: number
  image?: string
  description?: string
  is_active: boolean
  unit_type: "piece" | "weight"
  is_returnable?: boolean
  shelf_life_days?: number
  created_at: string
  updated_at: string
}

export interface StockBatch {
  id: string
  product_id: string
  supplier_id: string
  quantity: number
  cost_price: number
  received_at: string
  expiration_date?: string
}

export interface Category {
  id: string
  name: string
  description?: string
  parent_id?: string
  is_active: boolean
}

export interface Customer {
  id: string
  name: string
  phone?: string
  email?: string
  address?: string
  bonus_points: number
  total_purchases: number
  debt_amount: number
  created_at: string
}

export interface Employee {
  id: string
  name: string
  phone: string
  email?: string
  role: "admin" | "cashier" | "warehouse" | "manager"
  salary?: number
  is_active: boolean
  created_at: string
}

export interface Sale {
  id: string
  customer_id?: string
  employee_id: string
  total_amount: number
  discount_amount: number
  tax_amount: number
  payment_method: "cash" | "card" | "qr" | "bonus" | "credit"
  status: "completed" | "pending" | "cancelled"
  created_at: string
}

export interface SaleItem {
  id: string
  sale_id: string
  product_id: string
  quantity: number
  unit_price: number
  total_price: number
}

export interface ReportSaleItem {
  id: string
  productId: string
  productName: string
  category: string
  quantity: number
  unitPrice: number
  unitCost: number
  totalAmount: number
  totalCost: number
  profit: number
  customerId?: string
  employeeId?: string
  date: string
}

export interface StockMovement {
  id: string
  product_id: string
  type: "in" | "out" | "adjustment" | "transfer"
  quantity: number
  reason: string
  employee_id: string
  created_at: string
}

export interface CashRegister {
  id: string
  employee_id: string
  opening_balance: number
  closing_balance?: number
  total_sales: number
  total_cash: number
  total_card: number
  status: "open" | "closed"
  opened_at: string
  closed_at?: string
}

export interface CartItem extends Product {
  quantity: number
  stock_quantity: number
}

export interface Supplier {
  id: string
  name: string
  contact_person?: string
  phone?: string
  email?: string
  address?: string
  brand_represented?: string
  our_debt_to_them: number
  their_debt_to_us: number
  notes?: string
  created_at: string
  updated_at: string
}

export interface SupplierTransaction {
  id: string
  supplier_id: string
  type:
    | "initial_balance"
    | "goods_received"
    | "payment_made"
    | "goods_returned"
    | "payment_received"
    | "debt_adjustment"
  amount: number
  description?: string
  transaction_date: string
  created_at: string
}
