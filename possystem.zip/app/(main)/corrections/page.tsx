"use client"

import { useState, useMemo, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Plus, RotateCcw, AlertTriangle, CheckCircle, XCircle, FileText } from "lucide-react"
import type { Product } from "@/lib/types"

// Sample products if none exist
const sampleProducts = [
  {
    id: "prod-1",
    name: "Olma",
    description: "Qizil olma",
    price: 10000,
    category_id: "cat-1",
    stock_quantity: 100,
    barcode: "1234567890",
    created_at: new Date().toISOString(),
  },
  {
    id: "prod-2",
    name: "Non",
    description: "Yangi pishgan non",
    price: 5000,
    category_id: "cat-2",
    stock_quantity: 50,
    barcode: "0987654321",
    created_at: new Date().toISOString(),
  },
  {
    id: "prod-3",
    name: "Sut",
    description: "Yangi sut",
    price: 8000,
    category_id: "cat-3",
    stock_quantity: 30,
    barcode: "5678901234",
    created_at: new Date().toISOString(),
  },
]

interface Correction {
  id: string
  product_id: string
  type: "increase" | "decrease" | "set_exact"
  old_quantity: number
  new_quantity: number
  difference: number
  reason: string
  employee_id: string
  status: "pending" | "approved" | "rejected"
  created_at: string
  approved_at?: string
  approved_by?: string
  notes?: string
}

// LocalStorage functions
const loadFromLocalStorage = <T,>(key: string, defaultValue: T): T => {
  if (typeof window === "undefined") return defaultValue
  try {
    const item = window.localStorage.getItem(key)
    return item ? JSON.parse(item) : defaultValue
  } catch (error) {
    console.error(`Error loading ${key} from localStorage:`, error)
    return defaultValue
  }
}

const saveToLocalStorage = <T,>(key: string, value: T): void => {
  if (typeof window === "undefined") return
  try {
    window.localStorage.setItem(key, JSON.stringify(value))
  } catch (error) {
    console.error(`Error saving ${key} to localStorage:`, error)
  }
}

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat("uz-UZ", { style: "currency", currency: "UZS", minimumFractionDigits: 0 }).format(amount)
}

const correctionTypeLabels = {
  increase: "Ko'paytirish",
  decrease: "Kamaytirish",
  set_exact: "Aniq qiymat",
}

const statusLabels = {
  pending: "Kutilmoqda",
  approved: "Tasdiqlangan",
  rejected: "Rad etilgan",
}

export default function CorrectionsPage() {
  // State for dialog
  const [dialogOpen, setDialogOpen] = useState(false)

  // Load products from localStorage - combining both sources
  const [products, setProducts] = useState<Product[]>(() => {
    // Load products from products_list (from Products page)
    const productsList = loadFromLocalStorage<Product[]>("products_list", [])

    // Load products from warehouse_products (from Warehouse page)
    const warehouseProducts = loadFromLocalStorage<Product[]>("warehouse_products", [])

    // Combine products, ensuring no duplicates by ID
    const combinedProducts = [...productsList]

    // Add warehouse products that don't exist in products_list
    warehouseProducts.forEach((wp) => {
      if (!combinedProducts.some((p) => p.id === wp.id)) {
        combinedProducts.push(wp)
      }
    })

    console.log("Loaded products:", combinedProducts)
    return combinedProducts
  })

  // Load corrections from localStorage
  const [corrections, setCorrections] = useState<Correction[]>(() =>
    loadFromLocalStorage<Correction[]>("corrections", []),
  )

  const [searchTerm, setSearchTerm] = useState("")
  const [selectedStatus, setSelectedStatus] = useState<string>("all")
  const [formData, setFormData] = useState({
    product_id: "",
    type: "set_exact" as Correction["type"],
    new_quantity: "",
    reason: "",
  })

  // Save corrections to localStorage whenever they change
  useEffect(() => {
    console.log("Saving corrections to localStorage:", corrections)
    saveToLocalStorage("corrections", corrections)
  }, [corrections])

  // Listen for storage events to update data if changed in another tab
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === "products_list" || e.key === "warehouse_products") {
        // Reload products from both sources
        const productsList = loadFromLocalStorage<Product[]>("products_list", [])
        const warehouseProducts = loadFromLocalStorage<Product[]>("warehouse_products", [])

        // Combine products, ensuring no duplicates by ID
        const combinedProducts = [...productsList]

        // Add warehouse products that don't exist in products_list
        warehouseProducts.forEach((wp) => {
          if (!combinedProducts.some((p) => p.id === wp.id)) {
            combinedProducts.push(wp)
          }
        })

        setProducts(combinedProducts)
      }
      if (e.key === "corrections") {
        setCorrections(loadFromLocalStorage<Correction[]>("corrections", []))
      }
    }

    window.addEventListener("storage", handleStorageChange)
    return () => window.removeEventListener("storage", handleStorageChange)
  }, [])

  const filteredCorrections = useMemo(() => {
    return corrections.filter((correction) => {
      const product = products.find((p) => p.id === correction.product_id)
      const matchesSearch = product?.name?.toLowerCase().includes(searchTerm.toLowerCase()) || false
      const matchesStatus = selectedStatus === "all" || correction.status === selectedStatus
      return matchesSearch && matchesStatus
    })
  }, [corrections, products, searchTerm, selectedStatus])

  const handleAddCorrection = () => {
    console.log("Adding correction with form data:", formData)

    const product = products.find((p) => p.id === formData.product_id)
    if (!product) {
      console.error("Product not found:", formData.product_id)
      alert("Mahsulot topilmadi!")
      return
    }

    const newQuantity = Number.parseInt(formData.new_quantity) || 0
    let difference = 0

    if (formData.type === "increase") {
      difference = newQuantity
    } else if (formData.type === "decrease") {
      difference = -newQuantity
    } else if (formData.type === "set_exact") {
      difference = newQuantity - (product.stock_quantity || 0)
    }

    const newCorrection: Correction = {
      id: Date.now().toString(),
      product_id: formData.product_id,
      type: formData.type,
      old_quantity: product.stock_quantity || 0,
      new_quantity: formData.type === "set_exact" ? newQuantity : (product.stock_quantity || 0) + difference,
      difference: difference,
      reason: formData.reason,
      employee_id: "current_user",
      status: "pending",
      created_at: new Date().toISOString(),
    }

    console.log("New correction object:", newCorrection)
    setCorrections([newCorrection, ...corrections])
    resetForm()
    setDialogOpen(false)
  }

  const handleApproveCorrection = (correctionId: string) => {
    console.log("Approving correction:", correctionId)

    const correction = corrections.find((c) => c.id === correctionId)
    if (!correction) {
      alert("Korrektirovka topilmadi!")
      return
    }

    // Update correction status
    const updatedCorrections = corrections.map((correction) => {
      if (correction.id === correctionId) {
        return {
          ...correction,
          status: "approved" as const,
          approved_at: new Date().toISOString(),
          approved_by: "current_manager",
        }
      }
      return correction
    })
    setCorrections(updatedCorrections)

    // Update product quantities in localStorage
    try {
      // Update products_list
      const productsList = loadFromLocalStorage<Product[]>("products_list", [])
      const updatedProductsList = productsList.map((product) => {
        if (product.id === correction.product_id) {
          return {
            ...product,
            stock_quantity: correction.new_quantity,
          }
        }
        return product
      })
      saveToLocalStorage("products_list", updatedProductsList)

      // Update warehouse_products
      const warehouseProducts = loadFromLocalStorage<Product[]>("warehouse_products", [])
      const updatedWarehouseProducts = warehouseProducts.map((product) => {
        if (product.id === correction.product_id) {
          return {
            ...product,
            stock_quantity: correction.new_quantity,
          }
        }
        return product
      })
      saveToLocalStorage("warehouse_products", updatedWarehouseProducts)

      // Update local products state
      setProducts((prevProducts) =>
        prevProducts.map((product) => {
          if (product.id === correction.product_id) {
            return {
              ...product,
              stock_quantity: correction.new_quantity,
            }
          }
          return product
        }),
      )

      alert(
        `Korrektirovka tasdiqlandi va mahsulot zaxirasi yangilandi!\n\nMahsulot: ${getProductName(correction.product_id)}\nEski miqdor: ${correction.old_quantity}\nYangi miqdor: ${correction.new_quantity}\nFarq: ${correction.difference > 0 ? "+" : ""}${correction.difference}`,
      )
    } catch (error) {
      console.error("Error updating product quantities:", error)
      alert("Korrektirovka tasdiqlandi, lekin mahsulot zaxirasini yangilashda xatolik yuz berdi!")
    }
  }

  const handleRejectCorrection = (correctionId: string, notes?: string) => {
    console.log("Rejecting correction:", correctionId)

    const correction = corrections.find((c) => c.id === correctionId)
    const productName = correction ? getProductName(correction.product_id) : "Noma'lum mahsulot"

    setCorrections(
      corrections.map((correction) => {
        if (correction.id === correctionId) {
          return {
            ...correction,
            status: "rejected" as const,
            notes: notes,
          }
        }
        return correction
      }),
    )

    alert(`Korrektirovka rad etildi!\n\nMahsulot: ${productName}\nSabab: ${notes || "Rad etildi"}`)
  }

  const resetForm = () => {
    setFormData({
      product_id: "",
      type: "set_exact",
      new_quantity: "",
      reason: "",
    })
  }

  const getProductName = (productId: string) => {
    return products.find((p) => p.id === productId)?.name || "Noma'lum mahsulot"
  }

  const getProductCurrentStock = (productId: string) => {
    return products.find((p) => p.id === productId)?.stock_quantity || 0
  }

  const getStatusBadge = (status: Correction["status"]) => {
    const colors = {
      pending: "bg-yellow-100 text-yellow-800",
      approved: "bg-green-100 text-green-800",
      rejected: "bg-red-100 text-red-800",
    }
    return <Badge className={colors[status]}>{statusLabels[status]}</Badge>
  }

  const getStatusIcon = (status: Correction["status"]) => {
    switch (status) {
      case "pending":
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />
      case "approved":
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case "rejected":
        return <XCircle className="h-4 w-4 text-red-600" />
      default:
        return <AlertTriangle className="h-4 w-4" />
    }
  }

  const getTypeBadge = (type: Correction["type"]) => {
    const colors = {
      increase: "bg-green-100 text-green-800",
      decrease: "bg-red-100 text-red-800",
      set_exact: "bg-blue-100 text-blue-800",
    }
    return <Badge className={colors[type]}>{correctionTypeLabels[type]}</Badge>
  }

  const totalCorrections = corrections.length
  const pendingCorrections = corrections.filter((c) => c.status === "pending").length
  const approvedCorrections = corrections.filter((c) => c.status === "approved").length
  const rejectedCorrections = corrections.filter((c) => c.status === "rejected").length

  const generateReport = () => {
    const reportData = {
      date: new Date().toLocaleDateString("uz-UZ"),
      total: totalCorrections,
      pending: pendingCorrections,
      approved: approvedCorrections,
      rejected: rejectedCorrections,
    }

    alert(
      `KORREKTIROVKA HISOBOTI\n\nSana: ${reportData.date}\n\nJami korrektirovkalar: ${reportData.total}\nKutilayotgan: ${reportData.pending}\nTasdiqlangan: ${reportData.approved}\nRad etilgan: ${reportData.rejected}`,
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Korrektirovka</h1>
        <div className="flex gap-2">
          <Button variant="outline" onClick={generateReport}>
            <FileText className="mr-2 h-4 w-4" />
            Hisobot
          </Button>

          {/* Simplified dialog implementation */}
          <Button
            onClick={() => {
              console.log("Opening dialog")
              resetForm()
              setDialogOpen(true)
            }}
          >
            <Plus className="mr-2 h-4 w-4" />
            Yangi Korrektirovka
          </Button>
        </div>
      </div>

      {/* Dialog implementation */}
      {dialogOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Yangi Korrektirovka</h2>
              <Button variant="ghost" size="sm" onClick={() => setDialogOpen(false)}>
                ✕
              </Button>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="product">Mahsulot *</Label>
                <select
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  value={formData.product_id}
                  onChange={(e) => {
                    console.log("Selected product:", e.target.value)
                    setFormData({ ...formData, product_id: e.target.value })
                  }}
                >
                  <option value="">Mahsulotni tanlang</option>
                  {products.length > 0 ? (
                    products
                      .filter((product) => product.name && product.id) // Filter out invalid products
                      .map((product) => (
                        <option key={product.id} value={product.id}>
                          {product.name} (Joriy: {product.stock_quantity || 0})
                        </option>
                      ))
                  ) : (
                    <option disabled>Mahsulotlar mavjud emas</option>
                  )}
                </select>
              </div>

              <div>
                <Label htmlFor="type">Korrektirovka turi *</Label>
                <select
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  value={formData.type}
                  onChange={(e) => {
                    console.log("Selected type:", e.target.value)
                    setFormData({ ...formData, type: e.target.value as any })
                  }}
                >
                  <option value="increase">Ko'paytirish</option>
                  <option value="decrease">Kamaytirish</option>
                  <option value="set_exact">Aniq qiymat o'rnatish</option>
                </select>
              </div>

              <div>
                <Label htmlFor="new_quantity">
                  {formData.type === "set_exact"
                    ? "Yangi miqdor"
                    : formData.type === "increase"
                      ? "Qo'shiladigan miqdor"
                      : "Kamaytirilgan miqdor"}{" "}
                  *
                </Label>
                <Input
                  id="new_quantity"
                  type="number"
                  value={formData.new_quantity}
                  onChange={(e) => {
                    console.log("New quantity:", e.target.value)
                    setFormData({ ...formData, new_quantity: e.target.value })
                  }}
                  placeholder="0"
                />
                {formData.product_id && (
                  <p className="text-sm text-muted-foreground mt-1">
                    Joriy miqdor: {getProductCurrentStock(formData.product_id)}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="reason">Sabab *</Label>
                <Textarea
                  id="reason"
                  value={formData.reason}
                  onChange={(e) => {
                    console.log("Reason:", e.target.value)
                    setFormData({ ...formData, reason: e.target.value })
                  }}
                  placeholder="Korrektirovka sababini kiriting"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <Button variant="outline" onClick={() => setDialogOpen(false)} className="flex-1">
                  Bekor qilish
                </Button>
                <Button
                  onClick={() => {
                    console.log("Save button clicked")
                    handleAddCorrection()
                  }}
                  className="flex-1"
                  disabled={!formData.product_id || !formData.new_quantity || !formData.reason}
                >
                  Saqlash
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Statistika kartalari */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Jami Korrektirovkalar</CardTitle>
            <RotateCcw className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalCorrections}</div>
            <p className="text-xs text-muted-foreground">Barcha vaqt</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Kutilayotgan</CardTitle>
            <AlertTriangle className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{pendingCorrections}</div>
            <p className="text-xs text-muted-foreground">Tasdiq kutilmoqda</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tasdiqlangan</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{approvedCorrections}</div>
            <p className="text-xs text-muted-foreground">Muvaffaqiyatli</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Rad Etilgan</CardTitle>
            <XCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{rejectedCorrections}</div>
            <p className="text-xs text-muted-foreground">Bekor qilingan</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList>
          <TabsTrigger value="all">Barcha Korrektirovkalar</TabsTrigger>
          <TabsTrigger value="pending">Kutilayotgan</TabsTrigger>
          <TabsTrigger value="approved">Tasdiqlangan</TabsTrigger>
          <TabsTrigger value="rejected">Rad Etilgan</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Korrektirovkalar Ro'yxati</CardTitle>
              <div className="flex gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Korrektirovkalarni qidirish..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Holat" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Barcha holatlar</SelectItem>
                    <SelectItem value="pending">Kutilayotgan</SelectItem>
                    <SelectItem value="approved">Tasdiqlangan</SelectItem>
                    <SelectItem value="rejected">Rad etilgan</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Sana</TableHead>
                    <TableHead>Mahsulot</TableHead>
                    <TableHead>Tur</TableHead>
                    <TableHead>Eski → Yangi</TableHead>
                    <TableHead>Farq</TableHead>
                    <TableHead>Sabab</TableHead>
                    <TableHead>Holat</TableHead>
                    <TableHead>Amallar</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredCorrections.length > 0 ? (
                    filteredCorrections.map((correction) => (
                      <TableRow key={correction.id}>
                        <TableCell>{new Date(correction.created_at).toLocaleDateString("uz-UZ")}</TableCell>
                        <TableCell className="font-medium">{getProductName(correction.product_id)}</TableCell>
                        <TableCell>{getTypeBadge(correction.type)}</TableCell>
                        <TableCell>
                          <span className="font-mono">
                            {correction.old_quantity} → {correction.new_quantity}
                          </span>
                        </TableCell>
                        <TableCell>
                          <span
                            className={`font-medium ${correction.difference > 0 ? "text-green-600" : correction.difference < 0 ? "text-red-600" : "text-gray-600"}`}
                          >
                            {correction.difference > 0 ? "+" : ""}
                            {correction.difference}
                          </span>
                        </TableCell>
                        <TableCell className="max-w-xs truncate" title={correction.reason}>
                          {correction.reason}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {getStatusIcon(correction.status)}
                            {getStatusBadge(correction.status)}
                          </div>
                        </TableCell>
                        <TableCell>
                          {correction.status === "pending" && (
                            <div className="flex gap-1">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleApproveCorrection(correction.id)}
                                className="text-green-600 hover:text-green-600"
                              >
                                <CheckCircle className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleRejectCorrection(correction.id, "Rad etildi")}
                                className="text-red-600 hover:text-red-600"
                              >
                                <XCircle className="h-4 w-4" />
                              </Button>
                            </div>
                          )}
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center py-4">
                        Korrektirovkalar mavjud emas
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pending" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Tasdiq Kutayotgan Korrektirovkalar</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Mahsulot</TableHead>
                    <TableHead>Tur</TableHead>
                    <TableHead>O'zgarish</TableHead>
                    <TableHead>Sabab</TableHead>
                    <TableHead>Amallar</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {corrections.filter((c) => c.status === "pending").length > 0 ? (
                    corrections
                      .filter((c) => c.status === "pending")
                      .map((correction) => (
                        <TableRow key={correction.id}>
                          <TableCell className="font-medium">{getProductName(correction.product_id)}</TableCell>
                          <TableCell>{getTypeBadge(correction.type)}</TableCell>
                          <TableCell>
                            <span className="font-mono">
                              {correction.old_quantity} → {correction.new_quantity}
                            </span>
                          </TableCell>
                          <TableCell>{correction.reason}</TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleApproveCorrection(correction.id)}
                                className="text-green-600 hover:text-green-600"
                              >
                                Tasdiqlash
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleRejectCorrection(correction.id)}
                                className="text-red-600 hover:text-red-600"
                              >
                                Rad etish
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-4">
                        Kutilayotgan korrektirovkalar mavjud emas
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="approved" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Tasdiqlangan Korrektirovkalar</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Sana</TableHead>
                    <TableHead>Mahsulot</TableHead>
                    <TableHead>O'zgarish</TableHead>
                    <TableHead>Tasdiqlagan</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {corrections.filter((c) => c.status === "approved").length > 0 ? (
                    corrections
                      .filter((c) => c.status === "approved")
                      .map((correction) => (
                        <TableRow key={correction.id}>
                          <TableCell>{new Date(correction.created_at).toLocaleDateString("uz-UZ")}</TableCell>
                          <TableCell>{getProductName(correction.product_id)}</TableCell>
                          <TableCell>
                            <span className="font-mono">
                              {correction.old_quantity} → {correction.new_quantity} (
                              <span
                                className={
                                  correction.difference > 0
                                    ? "text-green-600"
                                    : correction.difference < 0
                                      ? "text-red-600"
                                      : "text-gray-600"
                                }
                              >
                                {correction.difference > 0 ? "+" : ""}
                                {correction.difference}
                              </span>
                              )
                            </span>
                          </TableCell>
                          <TableCell>
                            {correction.approved_at && new Date(correction.approved_at).toLocaleDateString("uz-UZ")}
                          </TableCell>
                        </TableRow>
                      ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center py-4">
                        Tasdiqlangan korrektirovkalar mavjud emas
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="rejected" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Rad Etilgan Korrektirovkalar</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Sana</TableHead>
                    <TableHead>Mahsulot</TableHead>
                    <TableHead>Taklif Qilingan O'zgarish</TableHead>
                    <TableHead>Sabab</TableHead>
                    <TableHead>Eslatma</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {corrections.filter((c) => c.status === "rejected").length > 0 ? (
                    corrections
                      .filter((c) => c.status === "rejected")
                      .map((correction) => (
                        <TableRow key={correction.id}>
                          <TableCell>{new Date(correction.created_at).toLocaleDateString("uz-UZ")}</TableCell>
                          <TableCell>{getProductName(correction.product_id)}</TableCell>
                          <TableCell>
                            <span className="font-mono">
                              {correction.old_quantity} → {correction.new_quantity}
                            </span>
                          </TableCell>
                          <TableCell>{correction.reason}</TableCell>
                          <TableCell>{correction.notes || "-"}</TableCell>
                        </TableRow>
                      ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-4">
                        Rad etilgan korrektirovkalar mavjud emas
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
