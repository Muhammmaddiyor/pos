"use client"

import { useState, useMemo, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Plus, Users, Clock, TrendingUp, Edit, Trash2, UserCheck } from "lucide-react"
import type { Employee } from "@/lib/types"

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat("uz-UZ", { style: "currency", currency: "UZS", minimumFractionDigits: 0 }).format(amount)
}

const roleLabels = {
  admin: "Administrator",
  cashier: "Kassir",
  warehouse: "Omborchi",
  manager: "Menejer",
}

export default function EmployeesPage() {
  const [employees, setEmployees] = useState<Employee[]>(() => {
    if (typeof window === "undefined") return []
    try {
      const savedEmployees = window.localStorage.getItem("employees")
      return savedEmployees ? JSON.parse(savedEmployees) : []
    } catch (error) {
      console.error("Error parsing employees from localStorage:", error)
      return []
    }
  })

  useEffect(() => {
    try {
      window.localStorage.setItem("employees", JSON.stringify(employees))
    } catch (error) {
      console.error("Error saving employees to localStorage:", error)
    }
  }, [employees])

  const [searchTerm, setSearchTerm] = useState("")
  const [selectedRole, setSelectedRole] = useState<string>("all")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    role: "cashier" as Employee["role"],
    salary: "",
    is_active: true,
  })

  const resetForm = () => {
    setFormData({
      name: "",
      phone: "",
      email: "",
      role: "cashier",
      salary: "",
      is_active: true,
    })
  }

  const filteredEmployees = useMemo(() => {
    return employees.filter((employee) => {
      const matchesSearch =
        employee.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        employee.phone.includes(searchTerm) ||
        employee.email?.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesRole = selectedRole === "all" || employee.role === selectedRole
      return matchesSearch && matchesRole
    })
  }, [employees, searchTerm, selectedRole])

  const handleAddEmployee = () => {
    const newEmployee: Employee = {
      id: Date.now().toString(),
      name: formData.name,
      phone: formData.phone,
      email: formData.email || undefined,
      role: formData.role,
      salary: Number.parseFloat(formData.salary) || undefined,
      is_active: formData.is_active,
      created_at: new Date().toISOString(),
    }

    setEmployees([...employees, newEmployee])
    resetForm()
    setIsAddDialogOpen(false)
  }

  const handleEditEmployee = () => {
    if (!editingEmployee) return

    const updatedEmployee: Employee = {
      ...editingEmployee,
      name: formData.name,
      phone: formData.phone,
      email: formData.email || undefined,
      role: formData.role,
      salary: Number.parseFloat(formData.salary) || undefined,
      is_active: formData.is_active,
    }

    setEmployees(employees.map((e) => (e.id === editingEmployee.id ? updatedEmployee : e)))
    resetForm()
    setIsEditDialogOpen(false)
    setEditingEmployee(null)
  }

  const handleDeleteEmployee = (employeeId: string) => {
    if (confirm("Bu xodimni o'chirishni xohlaysizmi?")) {
      setEmployees(employees.filter((e) => e.id !== employeeId))
    }
  }

  const openEditDialog = (employee: Employee) => {
    setEditingEmployee(employee)
    setFormData({
      name: employee.name,
      phone: employee.phone,
      email: employee.email || "",
      role: employee.role,
      salary: employee.salary?.toString() || "",
      is_active: employee.is_active,
    })
    setIsEditDialogOpen(true)
  }

  const getRoleBadge = (role: Employee["role"]) => {
    const colors = {
      admin: "bg-red-100 text-red-800",
      manager: "bg-blue-100 text-blue-800",
      cashier: "bg-green-100 text-green-800",
      warehouse: "bg-yellow-100 text-yellow-800",
    }
    return <Badge className={colors[role]}>{roleLabels[role]}</Badge>
  }

  const totalEmployees = employees.length
  const activeEmployees = employees.filter((e) => e.is_active).length
  const totalSalary = employees.filter((e) => e.is_active && e.salary).reduce((sum, e) => sum + (e.salary || 0), 0)

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Xodimlar</h1>
        <Button
          onClick={() => {
            resetForm()
            setIsAddDialogOpen(true)
          }}
        >
          <Plus className="mr-2 h-4 w-4" />
          Yangi Xodim
        </Button>

        {isAddDialogOpen && (
          <Dialog
            open={isAddDialogOpen}
            onOpenChange={(open) => {
              if (!open) resetForm()
              setIsAddDialogOpen(open)
            }}
          >
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Yangi Xodim Qo'shish</DialogTitle>
              </DialogHeader>
              <EmployeeForm
                formData={formData}
                setFormData={setFormData}
                onSubmit={handleAddEmployee}
                onCancel={() => setIsAddDialogOpen(false)}
              />
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Statistika kartalari */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Jami Xodimlar</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalEmployees}</div>
            <p className="text-xs text-muted-foreground">Ro'yxatdan o'tgan</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Faol Xodimlar</CardTitle>
            <UserCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeEmployees}</div>
            <p className="text-xs text-muted-foreground">Ishlamoqda</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Oylik Maosh</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalSalary)}</div>
            <p className="text-xs text-muted-foreground">Jami oylik</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">O'rtacha Maosh</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(activeEmployees > 0 ? totalSalary / activeEmployees : 0)}
            </div>
            <p className="text-xs text-muted-foreground">Har bir xodim uchun</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList>
          <TabsTrigger value="all">Barcha Xodimlar</TabsTrigger>
          <TabsTrigger value="active">Faol Xodimlar</TabsTrigger>
          <TabsTrigger value="roles">Lavozimlar</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Xodimlar Ro'yxati</CardTitle>
              <div className="flex gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Xodimlarni qidirish..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <Select value={selectedRole} onValueChange={setSelectedRole}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Lavozim" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Barcha lavozimlar</SelectItem>
                    <SelectItem value="admin">Administrator</SelectItem>
                    <SelectItem value="manager">Menejer</SelectItem>
                    <SelectItem value="cashier">Kassir</SelectItem>
                    <SelectItem value="warehouse">Omborchi</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Xodim</TableHead>
                    <TableHead>Telefon</TableHead>
                    <TableHead>Lavozim</TableHead>
                    <TableHead>Maosh</TableHead>
                    <TableHead>Holat</TableHead>
                    <TableHead>Amallar</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredEmployees.length > 0 ? (
                    filteredEmployees.map((employee) => (
                      <TableRow key={employee.id}>
                        <TableCell>
                          <div>
                            <p className="font-medium">{employee.name}</p>
                            {employee.email && <p className="text-sm text-muted-foreground">{employee.email}</p>}
                          </div>
                        </TableCell>
                        <TableCell>{employee.phone}</TableCell>
                        <TableCell>{getRoleBadge(employee.role)}</TableCell>
                        <TableCell>{employee.salary ? formatCurrency(employee.salary) : "-"}</TableCell>
                        <TableCell>
                          {employee.is_active ? (
                            <Badge className="bg-green-100 text-green-800">Faol</Badge>
                          ) : (
                            <Badge variant="secondary">Nofaol</Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm" onClick={() => openEditDialog(employee)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDeleteEmployee(employee.id)}
                              className="text-destructive hover:text-destructive"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center h-24">
                        Xodimlar topilmadi.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="active" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Faol Xodimlar</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Xodim</TableHead>
                    <TableHead>Lavozim</TableHead>
                    <TableHead>Maosh</TableHead>
                    <TableHead>Ishga kirgan</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {employees
                    .filter((e) => e.is_active)
                    .map((employee) => (
                      <TableRow key={employee.id}>
                        <TableCell>
                          <div>
                            <p className="font-medium">{employee.name}</p>
                            <p className="text-sm text-muted-foreground">{employee.phone}</p>
                          </div>
                        </TableCell>
                        <TableCell>{getRoleBadge(employee.role)}</TableCell>
                        <TableCell className="font-medium">
                          {employee.salary ? formatCurrency(employee.salary) : "-"}
                        </TableCell>
                        <TableCell>{new Date(employee.created_at).toLocaleDateString("uz-UZ")}</TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="roles" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {Object.entries(roleLabels).map(([role, label]) => {
              const roleEmployees = employees.filter((e) => e.role === role && e.is_active)
              return (
                <Card key={role}>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>{label}</span>
                      <Badge variant="secondary">{roleEmployees.length} ta</Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {roleEmployees.map((employee) => (
                        <div key={employee.id} className="flex justify-between items-center p-2 border rounded">
                          <span className="font-medium">{employee.name}</span>
                          <span className="text-sm text-muted-foreground">
                            {employee.salary ? formatCurrency(employee.salary) : "-"}
                          </span>
                        </div>
                      ))}
                      {roleEmployees.length === 0 && (
                        <p className="text-sm text-muted-foreground text-center py-4">Bu lavozimda xodim yo'q</p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>
      </Tabs>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Xodimni Tahrirlash</DialogTitle>
          </DialogHeader>
          <EmployeeForm
            formData={formData}
            setFormData={setFormData}
            onSubmit={handleEditEmployee}
            onCancel={() => setIsEditDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  )
}

function EmployeeForm({
  formData,
  setFormData,
  onSubmit,
  onCancel,
}: {
  formData: any
  setFormData: any
  onSubmit: () => void
  onCancel: () => void
}) {
  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="name">Ism-familiya *</Label>
        <Input
          id="name"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          placeholder="Xodim ismini kiriting"
        />
      </div>

      <div>
        <Label htmlFor="phone">Telefon raqami *</Label>
        <Input
          id="phone"
          value={formData.phone}
          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
          placeholder="+998901234567"
        />
      </div>

      <div>
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          type="email"
          value={formData.email}
          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          placeholder="email@example.com"
        />
      </div>

      <div>
        <Label htmlFor="role">Lavozim *</Label>
        <Select value={formData.role} onValueChange={(value: any) => setFormData({ ...formData, role: value })}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="admin">Administrator</SelectItem>
            <SelectItem value="manager">Menejer</SelectItem>
            <SelectItem value="cashier">Kassir</SelectItem>
            <SelectItem value="warehouse">Omborchi</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="salary">Oylik maosh</Label>
        <Input
          id="salary"
          type="number"
          value={formData.salary}
          onChange={(e) => setFormData({ ...formData, salary: e.target.value })}
          placeholder="0"
        />
      </div>

      <div className="flex items-center space-x-2">
        <Switch
          id="is_active"
          checked={formData.is_active}
          onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
        />
        <Label htmlFor="is_active">Faol xodim</Label>
      </div>

      <div className="flex gap-2 pt-4">
        <Button variant="outline" onClick={onCancel} className="flex-1">
          Bekor qilish
        </Button>
        <Button onClick={onSubmit} className="flex-1">
          Saqlash
        </Button>
      </div>
    </div>
  )
}
