"use client"

import { useState, useMemo, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Search, Plus, Edit, Trash2, Package, Tag } from "lucide-react"
import type { Product, Category } from "@/lib/types"

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat("uz-UZ", { style: "currency", currency: "UZS", minimumFractionDigits: 0 }).format(amount)
}

export default function ProductsPage() {
  const [products, setProducts] = useState<Omit<Product, "stock_quantity">[]>(() => {
    if (typeof window === "undefined") return []
    try {
      const saved = window.localStorage.getItem("products_list") // Using a different key to avoid conflict with warehouse products
      return saved ? JSON.parse(saved) : []
    } catch (error) {
      console.error("Error parsing products from localStorage:", error)
      return []
    }
  })

  const [categories, setCategories] = useState<Category[]>(() => {
    if (typeof window === "undefined") return []
    try {
      const saved = window.localStorage.getItem("product_categories")
      return saved ? JSON.parse(saved) : []
    } catch (error) {
      console.error("Error parsing categories from localStorage:", error)
      return []
    }
  })

  useEffect(() => {
    try {
      window.localStorage.setItem("products_list", JSON.stringify(products))
    } catch (error) {
      console.error("Error saving products to localStorage:", error)
    }
  }, [products])

  useEffect(() => {
    try {
      window.localStorage.setItem("product_categories", JSON.stringify(categories))
    } catch (error) {
      console.error("Error saving categories to localStorage:", error)
    }
  }, [categories])

  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<string>("all")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isCategoryDialogOpen, setIsCategoryDialogOpen] = useState(false)
  const [editingProduct, setEditingProduct] = useState<Omit<Product, "stock_quantity"> | null>(null)
  const [categoryForm, setCategoryForm] = useState({ name: "" })
  const [formData, setFormData] = useState({
    name: "",
    price: "",
    cost: "",
    barcode: "",
    category_id: "",
    brand: "",
    min_stock_level: "",
    description: "",
    is_active: true,
    unit_type: "piece" as "piece" | "weight",
    is_returnable: true,
    shelf_life_days: "",
  })

  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      const matchesSearch =
        product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.barcode?.includes(searchTerm) ||
        product.brand?.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesCategory = selectedCategory === "all" || product.category_id === selectedCategory
      return matchesSearch && matchesCategory
    })
  }, [products, searchTerm, selectedCategory])

  const handleAddProduct = () => {
    if (!formData.name.trim()) {
      alert("Iltimos, mahsulot nomini kiriting.")
      return
    }
    if (!formData.price || Number.parseFloat(formData.price) <= 0) {
      alert("Iltimos, to'g'ri narx kiriting.")
      return
    }
    if (!formData.cost || Number.parseFloat(formData.cost) <= 0) {
      alert("Iltimos, to'g'ri tannarx kiriting.")
      return
    }
    if (!formData.category_id) {
      alert("Iltimos, mahsulot kategoriyasini tanlang.")
      return
    }
    if (!formData.min_stock_level || Number.parseInt(formData.min_stock_level) < 0) {
      alert("Iltimos, minimal qoldiq darajasini kiriting.")
      return
    }

    const newProduct: Omit<Product, "stock_quantity"> = {
      id: Date.now().toString(),
      name: formData.name.trim(),
      price: Number.parseFloat(formData.price),
      cost: Number.parseFloat(formData.cost),
      barcode: formData.barcode.trim(),
      category_id: formData.category_id,
      brand: formData.brand.trim(),
      min_stock_level: Number.parseInt(formData.min_stock_level),
      description: formData.description.trim(),
      is_active: formData.is_active,
      unit_type: formData.unit_type,
      is_returnable: formData.is_returnable,
      shelf_life_days: formData.shelf_life_days ? Number.parseInt(formData.shelf_life_days) : undefined,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }

    setProducts([...products, newProduct])
    resetForm()
    setIsAddDialogOpen(false)
  }

  const handleEditProduct = () => {
    if (!editingProduct) return

    const updatedProduct: Omit<Product, "stock_quantity"> = {
      ...editingProduct,
      name: formData.name,
      price: Number.parseFloat(formData.price),
      cost: Number.parseFloat(formData.cost),
      barcode: formData.barcode,
      category_id: formData.category_id,
      brand: formData.brand,
      min_stock_level: Number.parseInt(formData.min_stock_level),
      description: formData.description,
      is_active: formData.is_active,
      unit_type: formData.unit_type,
      is_returnable: formData.is_returnable,
      shelf_life_days: formData.shelf_life_days ? Number.parseInt(formData.shelf_life_days) : undefined,
      updated_at: new Date().toISOString(),
    }

    setProducts(products.map((p) => (p.id === editingProduct.id ? updatedProduct : p)))
    resetForm()
    setIsEditDialogOpen(false)
    setEditingProduct(null)
  }

  const handleDeleteProduct = (productId: string) => {
    if (confirm("Bu mahsulotni o'chirishni xohlaysizmi?")) {
      setProducts(products.filter((p) => p.id !== productId))
    }
  }

  const handleAddCategory = () => {
    if (!categoryForm.name.trim()) {
      alert("Kategoriya nomini kiriting.")
      return
    }
    const newCategory: Category = {
      id: `cat${Date.now()}`,
      name: categoryForm.name.trim(),
      is_active: true,
    }
    setCategories([...categories, newCategory])
    setCategoryForm({ name: "" })
    setIsCategoryDialogOpen(false)
  }

  const handleDeleteCategory = (categoryId: string) => {
    // Check if any products are using this category
    const productsUsingCategory = products.filter((p) => p.category_id === categoryId)

    if (productsUsingCategory.length > 0) {
      alert(
        `Bu kategoriyani o'chirib bo'lmaydi. ${productsUsingCategory.length} ta mahsulot bu kategoriyani ishlatmoqda.`,
      )
      return
    }

    if (confirm("Bu kategoriyani o'chirishni xohlaysizmi?")) {
      setCategories(categories.filter((c) => c.id !== categoryId))
    }
  }

  const openEditDialog = (product: Omit<Product, "stock_quantity">) => {
    setEditingProduct(product)
    setFormData({
      name: product.name,
      price: product.price.toString(),
      cost: product.cost.toString(),
      barcode: product.barcode || "",
      category_id: product.category_id,
      brand: product.brand || "",
      min_stock_level: product.min_stock_level.toString(),
      description: product.description || "",
      is_active: product.is_active,
      unit_type: product.unit_type,
      is_returnable: product.is_returnable === undefined ? true : product.is_returnable,
      shelf_life_days: product.shelf_life_days ? product.shelf_life_days.toString() : "",
    })
    setIsEditDialogOpen(true)
  }

  const resetForm = () => {
    setFormData({
      name: "",
      price: "",
      cost: "",
      barcode: "",
      category_id: "",
      brand: "",
      min_stock_level: "",
      description: "",
      is_active: true,
      unit_type: "piece",
      is_returnable: true,
      shelf_life_days: "",
    })
  }

  const getCategoryName = (categoryId: string) => {
    return categories.find((c) => c.id === categoryId)?.name || "Noma'lum"
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Mahsulotlar</h1>
        <div className="flex gap-2">
          <Dialog open={isCategoryDialogOpen} onOpenChange={setIsCategoryDialogOpen}>
            <DialogTrigger asChild>
              <Button
                variant="outline"
                onClick={() => {
                  console.log("Opening category dialog")
                  setCategoryForm({ name: "" })
                  setIsCategoryDialogOpen(true)
                }}
              >
                <Tag className="mr-2 h-4 w-4" />
                Kategoriyalarni Boshqarish
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Kategoriyalarni Boshqarish</DialogTitle>
              </DialogHeader>
              <div className="space-y-6 py-4">
                {/* Add new category section */}
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Yangi Kategoriya Qo'shish</h3>
                  <div>
                    <Label htmlFor="category_name">Kategoriya nomi *</Label>
                    <Input
                      id="category_name"
                      value={categoryForm.name}
                      onChange={(e) => setCategoryForm({ name: e.target.value })}
                      placeholder="Masalan, Ichimliklar"
                    />
                  </div>
                  <Button onClick={handleAddCategory} className="w-full">
                    Kategoriya Qo'shish
                  </Button>
                </div>

                {/* Existing categories section */}
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Mavjud Kategoriyalar</h3>
                  {categories.length > 0 ? (
                    <div className="space-y-2 max-h-60 overflow-y-auto">
                      {categories.map((category) => (
                        <div key={category.id} className="flex items-center justify-between p-3 border rounded-lg">
                          <span className="font-medium">{category.name}</span>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDeleteCategory(category.id)}
                            className="text-destructive hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-center text-muted-foreground py-4">Kategoriyalar mavjud emas</p>
                  )}
                </div>

                <div className="flex justify-end pt-4">
                  <Button variant="outline" onClick={() => setIsCategoryDialogOpen(false)}>
                    Yopish
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button
                onClick={() => {
                  console.log("Opening product dialog")
                  resetForm()
                  setIsAddDialogOpen(true)
                }}
              >
                <Plus className="mr-2 h-4 w-4" />
                Yangi Mahsulot
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Yangi Mahsulot Qo'shish</DialogTitle>
              </DialogHeader>
              <ProductForm
                formData={formData}
                setFormData={setFormData}
                categories={categories}
                onSubmit={handleAddProduct}
                onCancel={() => setIsAddDialogOpen(false)}
              />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            Mahsulotlar Ro'yxati
          </CardTitle>
          <div className="flex gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Mahsulot, barkod yoki brend bo'yicha qidirish..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Kategoriya" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Barcha kategoriyalar</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category.id} value={category.id}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Mahsulot</TableHead>
                <TableHead>Kategoriya</TableHead>
                <TableHead>Narx</TableHead>
                <TableHead>O'lchov Birligi</TableHead>
                <TableHead>Yaroqlilik muddati</TableHead>
                <TableHead>Qaytarish</TableHead>
                <TableHead>Barkod</TableHead>
                <TableHead>Amallar</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredProducts.length > 0 ? (
                filteredProducts.map((product) => (
                  <TableRow key={product.id}>
                    <TableCell>
                      <div>
                        <p className="font-medium">{product.name}</p>
                        {product.brand && <p className="text-sm text-muted-foreground">{product.brand}</p>}
                      </div>
                    </TableCell>
                    <TableCell>{getCategoryName(product.category_id)}</TableCell>
                    <TableCell>{formatCurrency(product.price)}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{product.unit_type === "piece" ? "Dona" : "Vazn (kg)"}</Badge>
                    </TableCell>
                    <TableCell>{product.shelf_life_days ? `${product.shelf_life_days} kun` : "-"}</TableCell>
                    <TableCell>
                      {product.is_returnable === undefined || product.is_returnable ? (
                        <Badge className="bg-green-100 text-green-800">Mumkin</Badge>
                      ) : (
                        <Badge variant="secondary" className="bg-red-100 text-red-800">
                          Mumkin emas
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <code className="text-xs">{product.barcode}</code>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => openEditDialog(product)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteProduct(product.id)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={8} className="text-center h-24">
                    Mahsulotlar topilmadi.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Mahsulotni Tahrirlash</DialogTitle>
          </DialogHeader>
          <ProductForm
            formData={formData}
            setFormData={setFormData}
            categories={categories}
            onSubmit={handleEditProduct}
            onCancel={() => setIsEditDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  )
}

function ProductForm({
  formData,
  setFormData,
  categories,
  onSubmit,
  onCancel,
}: {
  formData: any
  setFormData: any
  categories: Category[]
  onSubmit: () => void
  onCancel: () => void
}) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="name">Mahsulot nomi *</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            placeholder="Mahsulot nomini kiriting"
          />
        </div>
        <div>
          <Label htmlFor="brand">Brend</Label>
          <Input
            id="brand"
            value={formData.brand}
            onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
            placeholder="Brend nomini kiriting"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="price">Sotuv narxi *</Label>
          <Input
            id="price"
            type="number"
            value={formData.price}
            onChange={(e) => setFormData({ ...formData, price: e.target.value })}
            placeholder="0"
          />
        </div>
        <div>
          <Label htmlFor="cost">Tannarx *</Label>
          <Input
            id="cost"
            type="number"
            value={formData.cost}
            onChange={(e) => setFormData({ ...formData, cost: e.target.value })}
            placeholder="0"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="category">Kategoriya *</Label>
          <Select
            value={formData.category_id}
            onValueChange={(value) => setFormData({ ...formData, category_id: value })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Kategoriyani tanlang" />
            </SelectTrigger>
            <SelectContent>
              {categories.length > 0 ? (
                categories.map((category) => (
                  <SelectItem key={category.id} value={category.id}>
                    {category.name}
                  </SelectItem>
                ))
              ) : (
                <div className="p-4 text-center text-sm text-muted-foreground">Kategoriyalar yo'q</div>
              )}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="barcode">Barkod</Label>
          <Input
            id="barcode"
            value={formData.barcode}
            onChange={(e) => setFormData({ ...formData, barcode: e.target.value })}
            placeholder="1234567890123"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="unit_type">O'lchov birligi *</Label>
          <Select
            value={formData.unit_type}
            onValueChange={(value: any) => setFormData({ ...formData, unit_type: value })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="piece">Dona</SelectItem>
              <SelectItem value="weight">Vazn (kg)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="min_stock_level">Minimal qoldiq *</Label>
          <Input
            id="min_stock_level"
            type="number"
            value={formData.min_stock_level}
            onChange={(e) => setFormData({ ...formData, min_stock_level: e.target.value })}
            placeholder="0"
          />
        </div>
      </div>
      <div>
        <Label htmlFor="shelf_life_days">Yaroqlilik muddati (kunlarda)</Label>
        <Input
          id="shelf_life_days"
          type="number"
          value={formData.shelf_life_days}
          onChange={(e) => setFormData({ ...formData, shelf_life_days: e.target.value })}
          placeholder="Masalan: 30"
        />
      </div>

      <div>
        <Label htmlFor="description">Tavsif</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          placeholder="Mahsulot haqida qo'shimcha ma'lumot"
        />
      </div>

      <div className="flex items-center space-x-2">
        <Switch
          id="is_active"
          checked={formData.is_active}
          onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
        />
        <Label htmlFor="is_active">Faol mahsulot</Label>
      </div>

      <div className="flex items-center space-x-2">
        <Switch
          id="is_returnable"
          checked={formData.is_returnable}
          onCheckedChange={(checked) => setFormData({ ...formData, is_returnable: checked })}
        />
        <Label htmlFor="is_returnable">Qaytarish mumkin</Label>
      </div>

      <div className="flex gap-2 pt-4">
        <Button variant="outline" onClick={onCancel} className="flex-1">
          Bekor qilish
        </Button>
        <Button onClick={onSubmit} className="flex-1">
          Saqlash
        </Button>
      </div>
    </div>
  )
}
