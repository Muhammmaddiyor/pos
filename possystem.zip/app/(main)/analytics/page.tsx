"use client"

import { useState, useMemo, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DatePickerWithRange } from "@/components/ui/date-range-picker"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import {
  Lightbulb,
  TrendingUp,
  Package,
  Snowflake,
  Sun,
  Leaf,
  Wind,
  BarChart3,
  Download,
  ShoppingBag,
  DollarSign,
  TrendingDown,
  AlertTriangle,
  Info,
  ArrowRight,
} from "lucide-react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  LineChart,
  Line,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import type { DateRange } from "react-day-picker"
import { parseISO, startOfMonth, subMonths, format, differenceInDays } from "date-fns"
import type { Product, Sale, SaleItem, StockBatch, Category } from "@/lib/types"

// --- Helper Functions ---
const getSeason = (date: Date): "Qish" | "Bahor" | "Yoz" | "Kuz" => {
  const month = date.getMonth()
  if (month >= 2 && month <= 4) return "Bahor" // Mart, Aprel, May
  if (month >= 5 && month <= 7) return "Yoz" // Iyun, Iyul, Avgust
  if (month >= 8 && month <= 10) return "Kuz" // Sentyabr, Oktyabr, Noyabr
  return "Qish" // Dekabr, Yanvar, Fevral
}

const seasonIcons = {
  Qish: <Snowflake className="h-5 w-5 text-blue-400" />,
  Bahor: <Leaf className="h-5 w-5 text-green-500" />,
  Yoz: <Sun className="h-5 w-5 text-yellow-500" />,
  Kuz: <Wind className="h-5 w-5 text-orange-500" />,
}

const seasonColors = {
  Qish: "#93c5fd", // light blue
  Bahor: "#86efac", // light green
  Yoz: "#fde047", // light yellow
  Kuz: "#fdba74", // light orange
}

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884d8", "#82ca9d", "#ffc658", "#8dd1e1"]

// Helper function to load data from localStorage
const loadFromLocalStorage = <T,>(key: string, defaultValue: T): T => {
  if (typeof window === "undefined") return defaultValue
  try {
    const item = window.localStorage.getItem(key)
    return item ? JSON.parse(item) : defaultValue
  } catch (error) {
    console.error(`Error loading ${key} from localStorage:`, error)
    return defaultValue
  }
}

// Helper function to save data to localStorage
const saveToLocalStorage = <T,>(key: string, value: T): void => {
  if (typeof window === "undefined") return
  try {
    window.localStorage.setItem(key, JSON.stringify(value))
  } catch (error) {
    console.error(`Error saving ${key} to localStorage:`, error)
  }
}

// Initial date range
const initialEndDate = new Date()
const initialStartDate = subMonths(startOfMonth(new Date()), 3) // Use 3 months of data by default

export default function AnalyticsPage() {
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: initialStartDate,
    to: initialEndDate,
  })
  const [activeTab, setActiveTab] = useState("overview")

  // Load real data from localStorage
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [stockBatches, setStockBatches] = useState<StockBatch[]>([])
  const [sales, setSales] = useState<Sale[]>([])
  const [saleItems, setSaleItems] = useState<SaleItem[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [autoDecisions, setAutoDecisions] = useState<{
    lowStockProducts: Product[]
    expiringProducts: { product: Product; batch: StockBatch; daysLeft: number }[]
    seasonalRecommendations: { productId: string; name: string; quantity: number }[]
  }>({
    lowStockProducts: [],
    expiringProducts: [],
    seasonalRecommendations: [],
  })

  // Load data on component mount
  useEffect(() => {
    const loadData = () => {
      setIsLoading(true)

      // Load real data from localStorage
      const productsData = loadFromLocalStorage<Product[]>("products_list", [])
      const categoriesData = loadFromLocalStorage<Category[]>("product_categories", [])
      const batchesData = loadFromLocalStorage<StockBatch[]>("stock_batches", [])
      const salesData = loadFromLocalStorage<Sale[]>("sales", [])
      const saleItemsData = loadFromLocalStorage<SaleItem[]>("sale_items", [])

      setProducts(productsData)
      setCategories(categoriesData)
      setStockBatches(batchesData)
      setSales(salesData)
      setSaleItems(saleItemsData)

      setIsLoading(false)
    }

    loadData()

    // Set up a listener for storage changes
    const handleStorageChange = (e: StorageEvent) => {
      if (["products_list", "product_categories", "stock_batches", "sales", "sale_items"].includes(e.key || "")) {
        loadData()
      }
    }

    window.addEventListener("storage", handleStorageChange)
    return () => {
      window.removeEventListener("storage", handleStorageChange)
    }
  }, [])

  // Process sales data to create analytics
  const processedSalesData = useMemo(() => {
    if (sales.length === 0 || saleItems.length === 0 || products.length === 0) {
      return []
    }

    return saleItems
      .map((item) => {
        const sale = sales.find((s) => s.id === item.sale_id)
        const product = products.find((p) => p.id === item.product_id)

        if (!sale || !product) return null

        const category = categories.find((c) => c.id === product.category_id)

        return {
          id: item.id,
          saleId: sale.id,
          productId: product.id,
          productName: product.name,
          category: category?.name || "Noma'lum",
          quantity: item.quantity,
          unitPrice: item.unit_price,
          unitCost: product.cost || 0,
          totalAmount: item.total_price,
          totalCost: (product.cost || 0) * item.quantity,
          profit: item.total_price - (product.cost || 0) * item.quantity,
          date: sale.created_at,
        }
      })
      .filter(Boolean) as {
      id: string
      saleId: string
      productId: string
      productName: string
      category: string
      quantity: number
      unitPrice: number
      unitCost: number
      totalAmount: number
      totalCost: number
      profit: number
      date: string
    }[]
  }, [sales, saleItems, products, categories])

  // Filter sales data by date range
  const filteredSalesData = useMemo(() => {
    if (!dateRange?.from || !dateRange?.to) return processedSalesData

    return processedSalesData.filter((sale) => {
      try {
        const saleDate = new Date(sale.date)
        const fromDate = new Date(dateRange.from!)
        const toDate = new Date(dateRange.to!)

        // Set time to start/end of day for proper comparison
        fromDate.setHours(0, 0, 0, 0)
        toDate.setHours(23, 59, 59, 999)

        return saleDate >= fromDate && saleDate <= toDate
      } catch (error) {
        console.error("Date parsing error:", error)
        return false
      }
    })
  }, [processedSalesData, dateRange])

  // Calculate product performance metrics
  const productPerformance = useMemo(() => {
    const performance: {
      [key: string]: {
        id: string
        name: string
        totalQuantity: number
        totalRevenue: number
        totalProfit: number
        category: string
        averagePrice: number
      }
    } = {}

    filteredSalesData.forEach((sale) => {
      if (!performance[sale.productId]) {
        performance[sale.productId] = {
          id: sale.productId,
          name: sale.productName,
          totalQuantity: 0,
          totalRevenue: 0,
          totalProfit: 0,
          category: sale.category,
          averagePrice: 0,
        }
      }

      performance[sale.productId].totalQuantity += sale.quantity
      performance[sale.productId].totalRevenue += sale.totalAmount
      performance[sale.productId].totalProfit += sale.profit
    })

    // Calculate average price
    Object.values(performance).forEach((product) => {
      product.averagePrice = product.totalQuantity > 0 ? product.totalRevenue / product.totalQuantity : 0
    })

    return Object.values(performance)
  }, [filteredSalesData])

  // Top metrics
  const topSellingProduct = useMemo(() => {
    if (productPerformance.length === 0) return null
    return [...productPerformance].sort((a, b) => b.totalQuantity - a.totalQuantity)[0]
  }, [productPerformance])

  const topRevenueProduct = useMemo(() => {
    if (productPerformance.length === 0) return null
    return [...productPerformance].sort((a, b) => b.totalRevenue - a.totalRevenue)[0]
  }, [productPerformance])

  const topProfitProduct = useMemo(() => {
    if (productPerformance.length === 0) return null
    return [...productPerformance].sort((a, b) => b.totalProfit - a.totalProfit)[0]
  }, [productPerformance])

  const worstPerformingProduct = useMemo(() => {
    if (productPerformance.length === 0) return null
    return [...productPerformance].sort((a, b) => a.totalProfit - b.totalProfit)[0]
  }, [productPerformance])

  // Category performance
  const categoryPerformance = useMemo(() => {
    const performance: {
      [key: string]: { name: string; totalQuantity: number; totalRevenue: number; totalProfit: number }
    } = {}

    filteredSalesData.forEach((sale) => {
      if (!performance[sale.category]) {
        performance[sale.category] = {
          name: sale.category,
          totalQuantity: 0,
          totalRevenue: 0,
          totalProfit: 0,
        }
      }

      performance[sale.category].totalQuantity += sale.quantity
      performance[sale.category].totalRevenue += sale.totalAmount
      performance[sale.category].totalProfit += sale.profit
    })

    return Object.values(performance)
  }, [filteredSalesData])

  // Monthly sales data
  const monthlySales = useMemo(() => {
    const sales: { [key: string]: { month: string; totalSales: number; totalProfit: number } } = {}

    filteredSalesData.forEach((sale) => {
      const date = parseISO(sale.date)
      const monthKey = format(date, "yyyy-MM")
      const monthLabel = format(date, "MMM yyyy")

      if (!sales[monthKey]) {
        sales[monthKey] = {
          month: monthLabel,
          totalSales: 0,
          totalProfit: 0,
        }
      }

      sales[monthKey].totalSales += sale.totalAmount
      sales[monthKey].totalProfit += sale.profit
    })

    return Object.values(sales).sort((a, b) => {
      const dateA = new Date(a.month)
      const dateB = new Date(b.month)
      return dateA.getTime() - dateB.getTime()
    })
  }, [filteredSalesData])

  // Seasonal analysis
  const seasonalAnalysis = useMemo(() => {
    const seasonalSales: {
      [season: string]: {
        [productId: string]: {
          id: string
          name: string
          quantity: number
          revenue: number
          profit: number
          category: string
        }
      }
    } = {
      Qish: {},
      Bahor: {},
      Yoz: {},
      Kuz: {},
    }

    processedSalesData.forEach((sale) => {
      try {
        const saleDate = new Date(sale.date)
        const season = getSeason(saleDate)

        if (!seasonalSales[season][sale.productId]) {
          seasonalSales[season][sale.productId] = {
            id: sale.productId,
            name: sale.productName,
            quantity: 0,
            revenue: 0,
            profit: 0,
            category: sale.category,
          }
        }

        seasonalSales[season][sale.productId].quantity += sale.quantity
        seasonalSales[season][sale.productId].revenue += sale.totalAmount
        seasonalSales[season][sale.productId].profit += sale.profit
      } catch (error) {
        console.error("Date parsing error in seasonal analysis:", error)
      }
    })

    const topSeasonalProducts: {
      [season: string]: {
        id: string
        name: string
        quantity: number
        revenue: number
        profit: number
        category: string
      }[]
    } = {}

    for (const season in seasonalSales) {
      topSeasonalProducts[season] = Object.values(seasonalSales[season])
        .sort((a, b) => b.profit - a.profit)
        .slice(0, 10)
    }

    return topSeasonalProducts
  }, [processedSalesData])

  // Generate seasonal recommendations
  const seasonalRecommendations = useMemo(() => {
    const recommendations: {
      [season: string]: {
        id: string
        name: string
        reason: string
        category: string
        suggestedStock: number
      }[]
    } = {
      Qish: [],
      Bahor: [],
      Yoz: [],
      Kuz: [],
    }

    // For each season, get top products by profit and quantity
    for (const season in seasonalAnalysis) {
      const topProducts = [...seasonalAnalysis[season]].sort((a, b) => b.profit - a.profit).slice(0, 5)
      const topQuantityProducts = [...seasonalAnalysis[season]].sort((a, b) => b.quantity - a.quantity).slice(0, 5)

      // Combine both lists (profit and quantity based)
      const combinedProducts = [...topProducts]
      topQuantityProducts.forEach((product) => {
        if (!combinedProducts.some((p) => p.id === product.id)) {
          combinedProducts.push(product)
        }
      })

      // Add recommendations with reasons
      combinedProducts.slice(0, 7).forEach((product) => {
        const isTopProfit = topProducts.some((p) => p.id === product.id)
        const isTopQuantity = topQuantityProducts.some((p) => p.id === product.id)

        let reason = ""
        if (isTopProfit && isTopQuantity) {
          reason = "Yuqori foyda va sotilish miqdori"
        } else if (isTopProfit) {
          reason = "Yuqori foyda"
        } else {
          reason = "Yuqori sotilish miqdori"
        }

        // Calculate suggested stock based on average sales
        const avgQuantity = product.quantity / 3 // Assuming 3 months of data
        const suggestedStock = Math.ceil(avgQuantity * 1.5) // 1.5x safety factor

        recommendations[season].push({
          id: product.id,
          name: product.name,
          reason,
          category: product.category,
          suggestedStock,
        })
      })
    }

    return recommendations
  }, [seasonalAnalysis])

  // Current season and recommendations
  const currentSeason = getSeason(new Date())
  const currentRecommendations = seasonalRecommendations[currentSeason] || []

  // Stock analysis
  const stockAnalysis = useMemo(() => {
    if (products.length === 0 || stockBatches.length === 0) return { lowStock: [], expiring: [] }

    // Calculate current stock levels
    const stockLevels: { [productId: string]: number } = {}
    stockBatches.forEach((batch) => {
      if (!stockLevels[batch.product_id]) {
        stockLevels[batch.product_id] = 0
      }
      stockLevels[batch.product_id] += batch.quantity
    })

    // Find low stock products
    const lowStock = products.filter((product) => {
      const currentStock = stockLevels[product.id] || 0
      return currentStock <= product.min_stock_level
    })

    // Find expiring products
    const today = new Date()
    const expiring = stockBatches
      .filter((batch) => batch.expiration_date && batch.quantity > 0)
      .map((batch) => {
        const product = products.find((p) => p.id === batch.product_id)
        if (!product) return null

        const expirationDate = new Date(batch.expiration_date!)
        const daysLeft = differenceInDays(expirationDate, today)

        return { product, batch, daysLeft }
      })
      .filter(Boolean)
      .filter((item) => item!.daysLeft <= 30) as { product: Product; batch: StockBatch; daysLeft: number }[]

    return { lowStock, expiring }
  }, [products, stockBatches])

  // Auto-decision making based on analytics
  useEffect(() => {
    // Only run if we have data
    if (isLoading || products.length === 0) return

    // Get low stock products
    const lowStockProducts = stockAnalysis.lowStock

    // Get expiring products
    const expiringProducts = stockAnalysis.expiring

    // Get seasonal recommendations for current season
    const seasonalRecs = currentRecommendations
      .map((rec) => {
        const product = products.find((p) => p.id === rec.id)
        if (!product) return null

        // Calculate current stock
        const currentStock = stockBatches
          .filter((batch) => batch.product_id === product.id)
          .reduce((sum, batch) => sum + batch.quantity, 0)

        // Calculate how much more to order
        const additionalNeeded = Math.max(0, rec.suggestedStock - currentStock)

        return {
          productId: product.id,
          name: product.name,
          quantity: additionalNeeded,
        }
      })
      .filter(Boolean) as { productId: string; name: string; quantity: number }[]

    setAutoDecisions({
      lowStockProducts,
      expiringProducts,
      seasonalRecommendations: seasonalRecs,
    })
  }, [isLoading, products, stockBatches, stockAnalysis, currentRecommendations])

  // Export data to CSV
  const handleExportData = () => {
    // Create CSV content
    let csvContent = "Product Name,Category,Quantity,Revenue,Profit\n"

    productPerformance.forEach((product) => {
      csvContent += `"${product.name}","${product.category}",${product.totalQuantity},${product.totalRevenue},${product.totalProfit}\n`
    })

    // Create download link
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.setAttribute("href", url)
    link.setAttribute("download", `analytics_export_${format(new Date(), "yyyy-MM-dd")}.csv`)
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[70vh]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-lg">Ma'lumotlar yuklanmoqda...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold">Analitika</h1>
        <div className="flex items-center gap-2">
          <DatePickerWithRange date={dateRange} setDate={setDateRange} />
          <Button variant="outline" size="icon" onClick={handleExportData} title="Ma'lumotlarni eksport qilish">
            <Download className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Auto-decisions section */}
      {(autoDecisions.lowStockProducts.length > 0 ||
        autoDecisions.expiringProducts.length > 0 ||
        autoDecisions.seasonalRecommendations.length > 0) && (
        <Card className="border-l-4 border-l-amber-500">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-500" />
              Avtomatik Tavsiyalar
            </CardTitle>
            <CardDescription>
              Tizim tahlillari asosida quyidagi harakatlarni amalga oshirish tavsiya etiladi
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {autoDecisions.lowStockProducts.length > 0 && (
              <div>
                <h3 className="font-semibold mb-2">
                  Zaxirasi kam mahsulotlar ({autoDecisions.lowStockProducts.length})
                </h3>
                <ul className="space-y-1 ml-5 list-disc">
                  {autoDecisions.lowStockProducts.slice(0, 5).map((product) => (
                    <li key={product.id}>
                      <span className="font-medium">{product.name}</span> - minimal daraja: {product.min_stock_level}
                    </li>
                  ))}
                  {autoDecisions.lowStockProducts.length > 5 && (
                    <li>... va yana {autoDecisions.lowStockProducts.length - 5} ta mahsulot</li>
                  )}
                </ul>
              </div>
            )}

            {autoDecisions.expiringProducts.length > 0 && (
              <div>
                <h3 className="font-semibold mb-2">
                  Yaroqlilik muddati tugayotgan mahsulotlar ({autoDecisions.expiringProducts.length})
                </h3>
                <ul className="space-y-1 ml-5 list-disc">
                  {autoDecisions.expiringProducts.slice(0, 5).map((item) => (
                    <li key={item.batch.id}>
                      <span className="font-medium">{item.product.name}</span> - {item.daysLeft} kun qoldi
                    </li>
                  ))}
                  {autoDecisions.expiringProducts.length > 5 && (
                    <li>... va yana {autoDecisions.expiringProducts.length - 5} ta mahsulot</li>
                  )}
                </ul>
              </div>
            )}

            {autoDecisions.seasonalRecommendations.length > 0 && (
              <div>
                <h3 className="font-semibold mb-2">{currentSeason} fasli uchun tavsiya etilgan mahsulotlar</h3>
                <ul className="space-y-1 ml-5 list-disc">
                  {autoDecisions.seasonalRecommendations
                    .filter((rec) => rec.quantity > 0)
                    .slice(0, 5)
                    .map((rec) => (
                      <li key={rec.productId}>
                        <span className="font-medium">{rec.name}</span> - {rec.quantity} ta qo'shimcha zaxira tavsiya
                        etiladi
                      </li>
                    ))}
                </ul>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex justify-end">
            <Button variant="outline" size="sm" className="gap-1">
              Batafsil <ArrowRight className="h-4 w-4" />
            </Button>
          </CardFooter>
        </Card>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Umumiy Ko'rinish</TabsTrigger>
          <TabsTrigger value="seasonal">Fasllar bo'yicha</TabsTrigger>
          <TabsTrigger value="recommendations">Tavsiyalar</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {filteredSalesData.length === 0 ? (
            <Alert>
              <Info className="h-4 w-4" />
              <AlertTitle>Ma'lumotlar yetarli emas</AlertTitle>
              <AlertDescription>
                Tanlangan davr uchun sotuvlar ma'lumotlari mavjud emas. Iltimos, boshqa davr tanlang yoki sotuvlar
                bo'limida ma'lumotlar qo'shing.
              </AlertDescription>
            </Alert>
          ) : (
            <>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Eng Ko'p Sotilgan</CardTitle>
                    <ShoppingBag className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{topSellingProduct?.name || "N/A"}</div>
                    <p className="text-xs text-muted-foreground">
                      {topSellingProduct?.totalQuantity || 0} dona sotilgan
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Eng Daromadli</CardTitle>
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{topRevenueProduct?.name || "N/A"}</div>
                    <p className="text-xs text-muted-foreground">
                      {new Intl.NumberFormat("uz-UZ").format(topRevenueProduct?.totalRevenue || 0)} UZS
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Eng Foydali</CardTitle>
                    <TrendingUp className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{topProfitProduct?.name || "N/A"}</div>
                    <p className="text-xs text-muted-foreground">
                      {new Intl.NumberFormat("uz-UZ").format(topProfitProduct?.totalProfit || 0)} UZS foyda
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Eng Kam Foydali</CardTitle>
                    <TrendingDown className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{worstPerformingProduct?.name || "N/A"}</div>
                    <p className="text-xs text-muted-foreground">
                      {new Intl.NumberFormat("uz-UZ").format(worstPerformingProduct?.totalProfit || 0)} UZS foyda
                    </p>
                  </CardContent>
                </Card>
              </div>

              <div className="grid gap-6 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Oylik Sotuvlar Dinamikasi</CardTitle>
                    <CardDescription>Tanlangan davr uchun oylik sotuvlar va foyda dinamikasi</CardDescription>
                  </CardHeader>
                  <CardContent className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={monthlySales} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Line type="monotone" dataKey="totalSales" name="Sotuvlar" stroke="#8884d8" />
                        <Line type="monotone" dataKey="totalProfit" name="Foyda" stroke="#82ca9d" />
                      </LineChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Kategoriyalar bo'yicha Tahlil</CardTitle>
                    <CardDescription>Tanlangan davr uchun kategoriyalar bo'yicha sotuvlar</CardDescription>
                  </CardHeader>
                  <CardContent className="h-80">
                    {categoryPerformance.length > 0 ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={categoryPerformance}
                            dataKey="totalRevenue"
                            nameKey="name"
                            cx="50%"
                            cy="50%"
                            outerRadius={80}
                            label={(entry) => entry.name}
                          >
                            {categoryPerformance.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value) => new Intl.NumberFormat("uz-UZ").format(value as number)} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    ) : (
                      <div className="flex items-center justify-center h-full">
                        <p className="text-muted-foreground">Kategoriyalar bo'yicha ma'lumotlar mavjud emas</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Eng Yaxshi Mahsulotlar (Tanlangan Davr)</CardTitle>
                  <CardDescription>Tanlangan davr uchun sotuvlar bo'yicha eng yaxshi 10 mahsulot.</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>#</TableHead>
                        <TableHead>Mahsulot</TableHead>
                        <TableHead>Kategoriya</TableHead>
                        <TableHead className="text-right">Sotilgan Miqdor</TableHead>
                        <TableHead className="text-right">Jami Daromad</TableHead>
                        <TableHead className="text-right">Jami Foyda</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {productPerformance
                        .sort((a, b) => b.totalProfit - a.totalProfit)
                        .slice(0, 10)
                        .map((product, index) => (
                          <TableRow key={product.name}>
                            <TableCell>{index + 1}</TableCell>
                            <TableCell className="font-medium">{product.name}</TableCell>
                            <TableCell>{product.category}</TableCell>
                            <TableCell className="text-right">{product.totalQuantity} ta</TableCell>
                            <TableCell className="text-right">
                              {new Intl.NumberFormat("uz-UZ").format(product.totalRevenue)} UZS
                            </TableCell>
                            <TableCell className="text-right">
                              {new Intl.NumberFormat("uz-UZ").format(product.totalProfit)} UZS
                            </TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>

        <TabsContent value="seasonal" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            {Object.entries(seasonalAnalysis).map(([season, products]) => (
              <Card
                key={season}
                className={`border-l-4`}
                style={{ borderLeftColor: seasonColors[season as keyof typeof seasonColors] }}
              >
                <CardHeader className="flex flex-row items-center gap-2">
                  {seasonIcons[season as keyof typeof seasonIcons]}
                  <CardTitle>{season}</CardTitle>
                </CardHeader>
                <CardContent>
                  {products.length > 0 ? (
                    <>
                      <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={products.slice(0, 5)} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="name" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Bar
                              dataKey="quantity"
                              name="Miqdor"
                              fill={seasonColors[season as keyof typeof seasonColors]}
                            />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                      <div className="mt-4">
                        <h4 className="font-semibold mb-2">Eng ko'p sotilgan mahsulotlar:</h4>
                        <ul className="space-y-2 text-sm">
                          {products.slice(0, 5).map((p) => (
                            <li key={p.name} className="flex justify-between">
                              <span>{p.name}</span>
                              <Badge variant="secondary">{p.quantity} ta</Badge>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </>
                  ) : (
                    <div className="flex items-center justify-center h-64">
                      <p className="text-muted-foreground">Bu fasl uchun ma'lumotlar mavjud emas</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Fasllar bo'yicha Solishtirma Tahlil</CardTitle>
              <CardDescription>Har bir fasl uchun eng ko'p sotilgan mahsulotlar</CardDescription>
            </CardHeader>
            <CardContent className="h-96">
              {Object.values(seasonalAnalysis).some((products) => products.length > 0) ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={[
                      {
                        name: "Qish",
                        ...Object.fromEntries(seasonalAnalysis.Qish.slice(0, 3).map((p) => [p.name, p.quantity])),
                      },
                      {
                        name: "Bahor",
                        ...Object.fromEntries(seasonalAnalysis.Bahor.slice(0, 3).map((p) => [p.name, p.quantity])),
                      },
                      {
                        name: "Yoz",
                        ...Object.fromEntries(seasonalAnalysis.Yoz.slice(0, 3).map((p) => [p.name, p.quantity])),
                      },
                      {
                        name: "Kuz",
                        ...Object.fromEntries(seasonalAnalysis.Kuz.slice(0, 3).map((p) => [p.name, p.quantity])),
                      },
                    ]}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    {[
                      ...new Set([
                        ...seasonalAnalysis.Qish.slice(0, 3).map((p) => p.name),
                        ...seasonalAnalysis.Bahor.slice(0, 3).map((p) => p.name),
                        ...seasonalAnalysis.Yoz.slice(0, 3).map((p) => p.name),
                        ...seasonalAnalysis.Kuz.slice(0, 3).map((p) => p.name),
                      ]),
                    ].map((productName, index) => (
                      <Bar key={productName} dataKey={productName} fill={`hsl(${index * 40}, 70%, 60%)`} />
                    ))}
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex items-center justify-center h-full">
                  <p className="text-muted-foreground">Fasllar bo'yicha ma'lumotlar mavjud emas</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recommendations" className="space-y-6">
          <Card className="bg-primary-foreground/40 border-primary/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lightbulb className="h-5 w-5 text-yellow-400" />
                Joriy Fasl uchun Tavsiyalar ({currentSeason})
              </CardTitle>
              <CardDescription>
                O'tgan davrlardagi sotuvlarga asoslanib, ushbu mahsulotlar zaxirasini ko'paytirish tavsiya etiladi.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {currentRecommendations.length > 0 ? (
                <ul className="space-y-3">
                  {currentRecommendations.map((product) => (
                    <li key={product.id} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Package className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <span className="font-medium">{product.name}</span>
                          <p className="text-xs text-muted-foreground">{product.category}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">{product.reason}</Badge>
                        <Badge variant="secondary">Tavsiya: {product.suggestedStock} ta</Badge>
                      </div>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-muted-foreground">Joriy fasl uchun tavsiyalar mavjud emas</p>
              )}
            </CardContent>
          </Card>

          <div className="grid gap-6 md:grid-cols-2">
            {Object.entries(seasonalRecommendations)
              .filter(([season]) => season !== currentSeason)
              .map(([season, products]) => (
                <Card
                  key={season}
                  className={`border-l-4`}
                  style={{ borderLeftColor: seasonColors[season as keyof typeof seasonColors] }}
                >
                  <CardHeader className="flex flex-row items-center gap-2">
                    {seasonIcons[season as keyof typeof seasonIcons]}
                    <CardTitle>{season} uchun Tavsiyalar</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {products.length > 0 ? (
                      <ul className="space-y-2">
                        {products.map((product) => (
                          <li key={product.id} className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Package className="h-4 w-4 text-muted-foreground" />
                              <span className="font-medium">{product.name}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className="text-xs">
                                {product.reason}
                              </Badge>
                              <Badge variant="secondary" className="text-xs">
                                {product.suggestedStock} ta
                              </Badge>
                            </div>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-muted-foreground">Bu fasl uchun tavsiyalar mavjud emas</p>
                    )}
                  </CardContent>
                </Card>
              ))}
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Zaxira Boshqaruvi Tavsiyalari</CardTitle>
              <CardDescription>
                Analitika ma'lumotlari asosida quyidagi harakatlarni amalga oshirish tavsiya etiladi
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-4">
                {stockAnalysis.lowStock.length > 0 && (
                  <li className="flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-500 mt-0.5" />
                    <div>
                      <h4 className="font-semibold">Zaxirasi kam mahsulotlar ({stockAnalysis.lowStock.length})</h4>
                      <p className="text-sm text-muted-foreground">
                        Quyidagi mahsulotlar minimal zaxira darajasidan past yoki unga teng. Iltimos, bu mahsulotlarni
                        tezda to'ldiring.
                      </p>
                      <div className="mt-2 grid grid-cols-1 md:grid-cols-2 gap-2">
                        {stockAnalysis.lowStock.slice(0, 6).map((product) => (
                          <div key={product.id} className="flex items-center justify-between bg-muted p-2 rounded-md">
                            <span>{product.name}</span>
                            <Badge variant="outline">Min: {product.min_stock_level}</Badge>
                          </div>
                        ))}
                      </div>
                      {stockAnalysis.lowStock.length > 6 && (
                        <p className="text-xs text-muted-foreground mt-1">
                          ... va yana {stockAnalysis.lowStock.length - 6} ta mahsulot
                        </p>
                      )}
                    </div>
                  </li>
                )}

                {stockAnalysis.expiring.length > 0 && (
                  <li className="flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-red-500 mt-0.5" />
                    <div>
                      <h4 className="font-semibold">
                        Yaroqlilik muddati tugayotgan mahsulotlar ({stockAnalysis.expiring.length})
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        Quyidagi mahsulotlarning yaroqlilik muddati 30 kun ichida tugaydi. Ularni tezroq sotish uchun
                        chegirmalar qo'llashni o'ylab ko'ring.
                      </p>
                      <div className="mt-2 grid grid-cols-1 md:grid-cols-2 gap-2">
                        {stockAnalysis.expiring.slice(0, 6).map((item) => (
                          <div
                            key={item.batch.id}
                            className="flex items-center justify-between bg-muted p-2 rounded-md"
                          >
                            <span>{item.product.name}</span>
                            <Badge
                              variant={item.daysLeft <= 7 ? "destructive" : "outline"}
                              className={item.daysLeft <= 7 ? "" : "bg-amber-100 text-amber-800"}
                            >
                              {item.daysLeft} kun qoldi
                            </Badge>
                          </div>
                        ))}
                      </div>
                      {stockAnalysis.expiring.length > 6 && (
                        <p className="text-xs text-muted-foreground mt-1">
                          ... va yana {stockAnalysis.expiring.length - 6} ta mahsulot
                        </p>
                      )}
                    </div>
                  </li>
                )}

                <li className="flex items-start gap-3">
                  <BarChart3 className="h-5 w-5 text-primary mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Faslga mos mahsulotlar zaxirasini ko'paytiring</h4>
                    <p className="text-sm text-muted-foreground">
                      Har bir fasl uchun tavsiya etilgan mahsulotlar zaxirasini oldindan ko'paytirib qo'ying. Bu sizga
                      talab yuqori bo'lgan paytda yetarli miqdorda mahsulot bo'lishini ta'minlaydi.
                    </p>
                  </div>
                </li>

                <li className="flex items-start gap-3">
                  <TrendingUp className="h-5 w-5 text-primary mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Eng foydali mahsulotlarga e'tibor qarating</h4>
                    <p className="text-sm text-muted-foreground">
                      Eng yuqori foyda keltiradigan mahsulotlarni aniqlang va ularni ko'proq sotish uchun marketing
                      strategiyalarini ishlab chiqing.
                    </p>
                  </div>
                </li>

                <li className="flex items-start gap-3">
                  <TrendingDown className="h-5 w-5 text-primary mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Kam foydali mahsulotlarni qayta ko'rib chiqing</h4>
                    <p className="text-sm text-muted-foreground">
                      Kam foyda keltiradigan mahsulotlarni aniqlang va ularning narxlarini qayta ko'rib chiqing yoki
                      ularni yangi, ko'proq foyda keltiradigan mahsulotlar bilan almashtirish imkoniyatlarini o'rganing.
                    </p>
                  </div>
                </li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
