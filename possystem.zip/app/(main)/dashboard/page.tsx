"use client"

import { useState, useEffect, useMemo, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DollarSign,
  Users,
  ShoppingCart,
  AlertTriangle,
  TrendingUp,
  Package,
  BookmarkCheck,
  RefreshCw,
} from "lucide-react"
import Link from "next/link"

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat("uz-UZ", { style: "currency", currency: "UZS", minimumFractionDigits: 0 }).format(amount)
}

// localStorage dan ma'lumotlarni yuklash funksiyasi
const loadFromLocalStorage = <T,>(key: string, defaultValue: T): T => {
  if (typeof window === "undefined") return defaultValue
  try {
    const item = window.localStorage.getItem(key)
    return item ? JSON.parse(item) : defaultValue
  } catch (error) {
    console.error(`Error loading ${key} from localStorage:`, error)
    return defaultValue
  }
}

export default function DashboardPage() {
  const [sales, setSales] = useState<any[]>([])
  const [customers, setCustomers] = useState<any[]>([])
  const [products, setProducts] = useState<any[]>([])
  const [stockBatches, setStockBatches] = useState<any[]>([])
  const [expenses, setExpenses] = useState<any[]>([])
  const [debts, setDebts] = useState<any[]>([])
  const [employees, setEmployees] = useState<any[]>([])
  const [reservedOrders, setReservedOrders] = useState<any[]>([])
  const [cashRegisters, setCashRegisters] = useState<any[]>([])
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date())
  const [isRefreshing, setIsRefreshing] = useState(false)

  // Ma'lumotlarni yuklash funksiyasi
  const loadAllData = useCallback(() => {
    console.log("Loading all data...")
    setSales(loadFromLocalStorage("sales", []))
    setCustomers(loadFromLocalStorage("customers", []))
    setProducts(loadFromLocalStorage("products_list", []))
    setStockBatches(loadFromLocalStorage("stock_batches", []))
    setExpenses(loadFromLocalStorage("expenses", []))
    setDebts(loadFromLocalStorage("debts", []))
    setEmployees(loadFromLocalStorage("employees", []))
    setReservedOrders(loadFromLocalStorage("reserved_orders", []))
    setCashRegisters(loadFromLocalStorage("cash_registers", []))
    setLastUpdate(new Date())
  }, [])

  // Manual refresh funksiyasi
  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true)
    await new Promise((resolve) => setTimeout(resolve, 500)) // Loading animation uchun
    loadAllData()
    setIsRefreshing(false)
  }, [loadAllData])

  useEffect(() => {
    // Dastlabki yuklash
    loadAllData()

    // localStorage o'zgarishlarini kuzatish (boshqa tablardan)
    const handleStorageChange = (e: StorageEvent) => {
      if (
        e.key &&
        [
          "sales",
          "customers",
          "products_list",
          "stock_batches",
          "expenses",
          "debts",
          "employees",
          "reserved_orders",
          "cash_registers",
        ].includes(e.key)
      ) {
        console.log(`Storage changed: ${e.key}`)
        loadAllData()
      }
    }

    // Custom event listener (bir xil tabda o'zgarishlar uchun)
    const handleDataChange = (e: CustomEvent) => {
      console.log(`Data changed: ${e.detail.type}`)
      loadAllData()
    }

    // Focus event listener (tab ga qaytganda yangilash)
    const handleFocus = () => {
      console.log("Tab focused, refreshing data...")
      loadAllData()
    }

    // Event listenerlarni qo'shish
    window.addEventListener("storage", handleStorageChange)
    window.addEventListener("focus", handleFocus)
    document.addEventListener("dataChanged", handleDataChange as EventListener)

    // Avtomatik yangilanish (har 30 soniyada)
    const interval = setInterval(() => {
      console.log("Auto refresh...")
      loadAllData()
    }, 30000)

    return () => {
      window.removeEventListener("storage", handleStorageChange)
      window.removeEventListener("focus", handleFocus)
      document.removeEventListener("dataChanged", handleDataChange as EventListener)
      clearInterval(interval)
    }
  }, [loadAllData])

  // Bugungi statistikalar
  const todayStats = useMemo(() => {
    const today = new Date().toDateString()

    const todaySales = sales.filter((sale) => {
      try {
        return new Date(sale.created_at).toDateString() === today
      } catch {
        return false
      }
    })

    const todayRevenue = todaySales.reduce((sum, sale) => sum + (sale.total_amount || 0), 0)
    const todayOrders = todaySales.length

    const newCustomersToday = customers.filter((customer) => {
      try {
        return new Date(customer.created_at).toDateString() === today
      } catch {
        return false
      }
    }).length

    // Bugun band qilingan mahsulotlar
    const todayReservedOrders = reservedOrders.filter((order) => {
      try {
        return new Date(order.created_at).toDateString() === today
      } catch {
        return false
      }
    }).length

    return {
      revenue: todayRevenue,
      orders: todayOrders,
      newCustomers: newCustomersToday,
      reservedOrders: todayReservedOrders,
    }
  }, [sales, customers, reservedOrders])

  // Muddati yaqin mahsulotlar
  const expiringProducts = useMemo(() => {
    const today = new Date()
    const nextWeek = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000)

    return stockBatches
      .filter((batch) => {
        if (!batch.expiration_date) return false
        try {
          const expiryDate = new Date(batch.expiration_date)
          return expiryDate <= nextWeek && expiryDate >= today && batch.quantity > 0
        } catch {
          return false
        }
      })
      .sort((a, b) => {
        try {
          return new Date(a.expiration_date).getTime() - new Date(b.expiration_date).getTime()
        } catch {
          return 0
        }
      })
  }, [stockBatches])

  // So'nggi sotuvlar
  const recentSales = useMemo(() => {
    return sales
      .filter((sale) => sale.created_at) // Faqat sanasi bor sotuvlar
      .sort((a, b) => {
        try {
          return new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
        } catch {
          return 0
        }
      })
      .slice(0, 5)
      .map((sale) => {
        const customer = customers.find((c) => c.id === sale.customer_id)
        return {
          ...sale,
          customer_name: customer?.name || "Noma'lum mijoz",
        }
      })
  }, [sales, customers])

  // So'nggi band qilingan mahsulotlar
  const recentReservedOrders = useMemo(() => {
    return reservedOrders
      .filter((order) => order.created_at) // Faqat sanasi bor buyurtmalar
      .sort((a, b) => {
        try {
          return new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
        } catch {
          return 0
        }
      })
      .slice(0, 5)
      .map((order) => {
        const customer = customers.find((c) => c.id === order.customer_id)
        return {
          ...order,
          customer_name: customer?.name || order.customer_name || "Noma'lum mijoz",
          products_count: order.products?.length || 0,
          total_amount:
            order.total_amount ||
            order.products?.reduce((sum: number, item: any) => sum + (item.total_price || item.total || 0), 0) ||
            0,
        }
      })
  }, [reservedOrders, customers])

  // Ommabop mahsulotlar
  const popularProducts = useMemo(() => {
    const productSales: { [key: string]: { name: string; sales: number; revenue: number } } = {}

    sales.forEach((sale) => {
      if (!sale.items && !sale.products) return

      const items = sale.items || sale.products || []
      items.forEach((item: any) => {
        const product = products.find((p) => p.id === item.product_id || p.id === item.id)
        if (product) {
          if (!productSales[product.id]) {
            productSales[product.id] = { name: product.name, sales: 0, revenue: 0 }
          }
          productSales[product.id].sales += item.quantity || 1
          productSales[product.id].revenue += item.total_price || item.total || item.quantity * item.price || 0
        }
      })
    })

    return Object.values(productSales)
      .sort((a, b) => b.sales - a.sales)
      .slice(0, 5)
  }, [sales, products])

  // Jami statistikalar
  const totalStats = useMemo(() => {
    const totalRevenue = sales.reduce((sum, sale) => sum + (sale.total_amount || 0), 0)
    const totalCustomers = customers.length
    const totalProducts = products.length
    const activeEmployees = employees.filter((emp) => emp.is_active).length
    const totalDebts = debts.reduce((sum, debt) => sum + (debt.remaining_amount || debt.amount || 0), 0)
    const totalExpenses = expenses.reduce((sum, expense) => sum + (expense.amount || 0), 0)

    // Jami band qilingan mahsulotlar
    const totalReservedOrders = reservedOrders.length
    const activeReservedOrders = reservedOrders.filter(
      (order) => order.status === "pending" || order.status === "ready",
    ).length

    // Band qilingan mahsulotlar qiymati
    const reservedOrdersValue = reservedOrders.reduce((sum, order) => {
      const orderTotal =
        order.total_amount ||
        order.products?.reduce((itemSum: number, item: any) => itemSum + (item.total_price || item.total || 0), 0) ||
        0
      return sum + orderTotal
    }, 0)

    return {
      totalRevenue,
      totalCustomers,
      totalProducts,
      activeEmployees,
      totalDebts,
      totalExpenses,
      totalReservedOrders,
      activeReservedOrders,
      reservedOrdersValue,
    }
  }, [sales, customers, products, employees, debts, expenses, reservedOrders])

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Asosiy Panel</h1>
        <div className="flex items-center gap-4">
          <div className="text-sm text-muted-foreground">
            So'nggi yangilanish: {lastUpdate.toLocaleTimeString("uz-UZ")}
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="flex items-center gap-2"
          >
            <RefreshCw className={`h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
            Yangilash
          </Button>
          <div className="text-sm text-muted-foreground">
            {new Date().toLocaleDateString("uz-UZ", {
              weekday: "long",
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </div>
        </div>
      </div>

      {/* Bugungi statistikalar */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Bugungi Savdo</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(todayStats.revenue)}</div>
            <p className="text-xs text-muted-foreground">{todayStats.orders} ta buyurtma</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Yangi Mijozlar</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{todayStats.newCustomers}</div>
            <p className="text-xs text-muted-foreground">Jami {totalStats.totalCustomers} ta mijoz</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Buyurtmalar</CardTitle>
            <ShoppingCart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{todayStats.orders}</div>
            <p className="text-xs text-muted-foreground">Bugun uchun</p>
          </CardContent>
        </Card>

        {/* Band qilingan mahsulotlar kartasi */}
        <Card className="border-blue-100">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Band Qilingan</CardTitle>
            <BookmarkCheck className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{totalStats.activeReservedOrders}</div>
            <Link href="/delivery" className="text-xs text-muted-foreground hover:underline">
              Jami {totalStats.totalReservedOrders} ta band qilish
            </Link>
          </CardContent>
        </Card>

        {/* Kassadagi pul miqdori */}
        <Card className="border-green-100">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Kassadagi Pul</CardTitle>
            <DollarSign className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {(() => {
                const currentRegister = cashRegisters.find((r) => r.status === "open")
                if (currentRegister) {
                  // Load sales and expenses data
                  const today = new Date().toDateString()

                  // Calculate today's cash sales
                  const todayCashSales = sales
                    .filter((sale) => {
                      try {
                        return new Date(sale.created_at).toDateString() === today
                      } catch {
                        return false
                      }
                    })
                    .filter(
                      (sale) =>
                        sale.payment_method === "cash" || sale.payment_methods?.some((pm: any) => pm.type === "cash"),
                    )
                    .reduce((sum, sale) => {
                      if (sale.payment_methods) {
                        return (
                          sum +
                          sale.payment_methods
                            .filter((pm: any) => pm.type === "cash")
                            .reduce((cashSum: number, pm: any) => cashSum + (pm.amount || 0), 0)
                        )
                      }
                      return sum + (sale.payment_method === "cash" ? sale.total_amount || 0 : 0)
                    }, 0)

                  // Calculate today's cash expenses
                  const todayCashExpenses = expenses
                    .filter((expense) => {
                      try {
                        const expenseDate = new Date(expense.created_at).toDateString()
                        return (
                          expenseDate === today && expense.status === "approved" && expense.payment_method === "cash"
                        )
                      } catch {
                        return false
                      }
                    })
                    .reduce((sum, expense) => sum + (expense.amount || 0), 0)

                  // Calculate net balance
                  const currentCashBalance = (currentRegister.opening_balance || 0) + todayCashSales
                  const netBalance = currentCashBalance - todayCashExpenses

                  return formatCurrency(netBalance)
                }
                return formatCurrency(0)
              })()}
            </div>
            <Link href="/cash-register" className="text-xs text-muted-foreground hover:underline">
              {cashRegisters.find((r) => r.status === "open") ? "Sof balans (harajatlardan keyin)" : "Kassa yopiq"}
            </Link>
          </CardContent>
        </Card>

        <Card className={expiringProducts.length > 0 ? "border-yellow-500" : ""}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Muddati Yaqin</CardTitle>
            <AlertTriangle
              className={`h-4 w-4 ${expiringProducts.length > 0 ? "text-yellow-500" : "text-muted-foreground"}`}
            />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${expiringProducts.length > 0 ? "text-yellow-600" : ""}`}>
              {expiringProducts.length}
            </div>
            <Link href="/warehouse" className="text-xs text-muted-foreground hover:underline">
              Omborga o'tish
            </Link>
          </CardContent>
        </Card>
      </div>

      {/* Umumiy statistikalar */}
      <div className="grid gap-4 md:grid-cols-3 lg:grid-cols-7">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Jami Savdo</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-green-600">{formatCurrency(totalStats.totalRevenue)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Mahsulotlar</CardTitle>
            <Package className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-blue-600">{totalStats.totalProducts}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Xodimlar</CardTitle>
            <Users className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-purple-600">{totalStats.activeEmployees}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Mijozlar</CardTitle>
            <Users className="h-4 w-4 text-indigo-600" />
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-indigo-600">{totalStats.totalCustomers}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Qarzlar</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-red-600">{formatCurrency(totalStats.totalDebts)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Harajatlar</CardTitle>
            <DollarSign className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-orange-600">{formatCurrency(totalStats.totalExpenses)}</div>
          </CardContent>
        </Card>

        {/* Band qilingan mahsulotlar qiymati */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Band Qiymati</CardTitle>
            <BookmarkCheck className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-blue-600">{formatCurrency(totalStats.reservedOrdersValue)}</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* So'nggi sotuvlar */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              So'nggi Sotuvlar
              <Badge variant="secondary" className="text-xs">
                {recentSales.length} ta
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {recentSales.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Buyurtma ID</TableHead>
                    <TableHead>Mijoz</TableHead>
                    <TableHead>Summa</TableHead>
                    <TableHead>Vaqt</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentSales.map((sale) => (
                    <TableRow key={sale.id}>
                      <TableCell className="font-medium">#{sale.id.toString().slice(-6)}</TableCell>
                      <TableCell>{sale.customer_name}</TableCell>
                      <TableCell>{formatCurrency(sale.total_amount || 0)}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {sale.created_at
                          ? new Date(sale.created_at).toLocaleTimeString("uz-UZ", {
                              hour: "2-digit",
                              minute: "2-digit",
                            })
                          : "N/A"}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-8">Hozircha sotuvlar mavjud emas.</p>
            )}
          </CardContent>
        </Card>

        {/* So'nggi band qilingan mahsulotlar */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              So'nggi Band Qilingan Mahsulotlar
              <Badge variant="secondary" className="text-xs">
                {recentReservedOrders.length} ta
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {recentReservedOrders.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Mijoz</TableHead>
                    <TableHead>Mahsulotlar</TableHead>
                    <TableHead>Holati</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentReservedOrders.map((order) => (
                    <TableRow key={order.id}>
                      <TableCell className="font-medium">#{order.id.toString().slice(-6)}</TableCell>
                      <TableCell>{order.customer_name}</TableCell>
                      <TableCell>{order.products_count} ta</TableCell>
                      <TableCell>
                        <Badge
                          variant={order.status === "ready" ? "default" : "secondary"}
                          className={
                            order.status === "ready"
                              ? "bg-green-500"
                              : order.status === "pending"
                                ? "bg-yellow-500"
                                : order.status === "completed"
                                  ? "bg-blue-500"
                                  : ""
                          }
                        >
                          {order.status === "pending"
                            ? "Tayyorlanmoqda"
                            : order.status === "ready"
                              ? "Tayyor"
                              : order.status === "completed"
                                ? "Olib ketildi"
                                : order.status === "cancelled"
                                  ? "Bekor qilindi"
                                  : order.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-8">
                Hozircha band qilingan mahsulotlar mavjud emas.
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Ommabop mahsulotlar */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Ommabop Mahsulotlar
              <Badge variant="secondary" className="text-xs">
                Top {popularProducts.length}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {popularProducts.length > 0 ? (
              <div className="space-y-4">
                {popularProducts.map((product, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">{product.name}</p>
                      <p className="text-sm text-muted-foreground">{product.sales} ta sotilgan</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">{formatCurrency(product.revenue)}</p>
                      <Badge variant="secondary">#{index + 1}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-8">
                Hozircha ommabop mahsulotlar mavjud emas.
              </p>
            )}
          </CardContent>
        </Card>

        {/* Muddati yaqin mahsulotlar */}
        {expiringProducts.length > 0 ? (
          <Card className="border-yellow-500">
            <CardHeader>
              <CardTitle className="text-yellow-700 flex items-center justify-between">
                ⚠️ Muddati Yaqin Mahsulotlar
                <Badge variant="destructive" className="text-xs">
                  {expiringProducts.length} ta
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Mahsulot</TableHead>
                    <TableHead>Miqdor</TableHead>
                    <TableHead>Muddat</TableHead>
                    <TableHead>Qolgan kunlar</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {expiringProducts.slice(0, 5).map((batch) => {
                    const product = products.find((p) => p.id === batch.product_id)
                    let daysLeft = 0
                    try {
                      daysLeft = Math.ceil(
                        (new Date(batch.expiration_date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24),
                      )
                    } catch {
                      daysLeft = 0
                    }

                    return (
                      <TableRow key={batch.id}>
                        <TableCell className="font-medium">{product?.name || "Noma'lum mahsulot"}</TableCell>
                        <TableCell>{batch.quantity}</TableCell>
                        <TableCell>
                          {batch.expiration_date ? new Date(batch.expiration_date).toLocaleDateString("uz-UZ") : "N/A"}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={daysLeft <= 3 ? "destructive" : "secondary"}
                            className={daysLeft <= 3 ? "" : "bg-yellow-100 text-yellow-800"}
                          >
                            {daysLeft <= 0 ? "Tugagan" : `${daysLeft} kun`}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
              {expiringProducts.length > 5 && (
                <div className="mt-2 text-right">
                  <Link href="/warehouse" className="text-sm text-blue-600 hover:underline">
                    Yana {expiringProducts.length - 5} ta ko'rish...
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardHeader>
              <CardTitle>Muddati Yaqin Mahsulotlar</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground text-center py-8">
                Hozircha muddati yaqin mahsulotlar mavjud emas.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
