"use client"

import { useState, useMemo, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Plus, Clock, CheckCircle, XCircle, User, Package, ShoppingCart, Calendar } from "lucide-react"
import { toast } from "sonner"

interface Product {
  id: string
  name: string
  price: number
  quantity: number
  total: number
}

interface ReservedOrder {
  id: string
  customer_name: string
  customer_phone: string
  total_amount: number
  status: "pending" | "ready" | "completed" | "cancelled"
  created_at: string
  pickup_date?: string
  completed_at?: string
  notes?: string
  products: Product[]
}

// Mock products for selection
const availableProducts = [
  { id: "p1", name: "Non", price: 5000 },
  { id: "p2", name: "Sut", price: 12000 },
  { id: "p3", name: "Tuxum (10 dona)", price: 15000 },
  { id: "p4", name: "Guruch (1kg)", price: 18000 },
  { id: "p5", name: "Shakar (1kg)", price: 14000 },
  { id: "p6", name: "Yog' (1L)", price: 25000 },
  { id: "p7", name: "Go'sht (1kg)", price: 85000 },
  { id: "p8", name: "Kartoshka (1kg)", price: 8000 },
  { id: "p9", name: "Piyoz (1kg)", price: 6000 },
  { id: "p10", name: "Sabzi (1kg)", price: 7000 },
]

const initialOrders: ReservedOrder[] = []

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat("uz-UZ", { style: "currency", currency: "UZS", minimumFractionDigits: 0 }).format(amount)
}

const statusLabels = {
  pending: "Tayyorlanmoqda",
  ready: "Tayyor",
  completed: "Olib ketildi",
  cancelled: "Bekor qilindi",
}

export default function ReservedProductsPage() {
  const [orders, setOrders] = useState<ReservedOrder[]>(initialOrders)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedStatus, setSelectedStatus] = useState<string>("all")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isProductsDialogOpen, setIsProductsDialogOpen] = useState(false)
  const [selectedOrder, setSelectedOrder] = useState<ReservedOrder | null>(null)
  const [formData, setFormData] = useState({
    customer_name: "",
    customer_phone: "",
    pickup_date: "",
    notes: "",
  })
  const [selectedProducts, setSelectedProducts] = useState<Product[]>([])
  const [currentProduct, setCurrentProduct] = useState({
    id: "",
    quantity: 1,
  })

  // Load orders from localStorage if available
  useEffect(() => {
    try {
      const savedOrders = localStorage.getItem("reserved_orders")
      if (savedOrders) {
        setOrders(JSON.parse(savedOrders))
      }
    } catch (error) {
      console.error("Error loading orders from localStorage:", error)
    }
  }, [])

  // Save orders to localStorage when they change
  useEffect(() => {
    try {
      localStorage.setItem("reserved_orders", JSON.stringify(orders))
    } catch (error) {
      console.error("Error saving orders to localStorage:", error)
    }
  }, [orders])

  const filteredOrders = useMemo(() => {
    return orders.filter((order) => {
      const matchesSearch =
        order.customer_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.customer_phone.includes(searchTerm)
      const matchesStatus = selectedStatus === "all" || order.status === selectedStatus
      return matchesSearch && matchesStatus
    })
  }, [orders, searchTerm, selectedStatus])

  const openAddOrderDialog = () => {
    resetForm()
    setIsAddDialogOpen(true)
  }

  const handleAddOrder = () => {
    if (!formData.customer_name || !formData.customer_phone || !formData.pickup_date || selectedProducts.length === 0) {
      toast.error("Iltimos, barcha majburiy maydonlarni to'ldiring va kamida bitta mahsulot tanlang")
      return
    }

    const totalAmount = selectedProducts.reduce((sum, product) => sum + product.total, 0)

    const newOrder: ReservedOrder = {
      id: Date.now().toString(),
      customer_name: formData.customer_name,
      customer_phone: formData.customer_phone,
      total_amount: totalAmount,
      status: "pending",
      created_at: new Date().toISOString(),
      pickup_date: new Date(formData.pickup_date).toISOString(),
      notes: formData.notes || undefined,
      products: selectedProducts,
    }

    setOrders([newOrder, ...orders])
    resetForm()
    setIsAddDialogOpen(false)
    toast.success("Yangi band qilish muvaffaqiyatli qo'shildi")
  }

  const handleStatusChange = (orderId: string, newStatus: ReservedOrder["status"]) => {
    setOrders(
      orders.map((order) => {
        if (order.id === orderId) {
          const updatedOrder = { ...order, status: newStatus }
          if (newStatus === "completed") {
            updatedOrder.completed_at = new Date().toISOString()
          }
          return updatedOrder
        }
        return order
      }),
    )
  }

  const resetForm = () => {
    setFormData({
      customer_name: "",
      customer_phone: "",
      pickup_date: "",
      notes: "",
    })
    setSelectedProducts([])
  }

  const addProductToOrder = () => {
    if (!currentProduct.id || currentProduct.quantity <= 0) {
      toast.error("Iltimos, mahsulot tanlang va miqdorni kiriting")
      return
    }

    const product = availableProducts.find((p) => p.id === currentProduct.id)
    if (!product) return

    // Check if product already exists in the list
    const existingProductIndex = selectedProducts.findIndex((p) => p.id === currentProduct.id)

    if (existingProductIndex >= 0) {
      // Update existing product quantity
      const updatedProducts = [...selectedProducts]
      updatedProducts[existingProductIndex].quantity += currentProduct.quantity
      updatedProducts[existingProductIndex].total =
        updatedProducts[existingProductIndex].price * updatedProducts[existingProductIndex].quantity
      setSelectedProducts(updatedProducts)
    } else {
      // Add new product
      setSelectedProducts([
        ...selectedProducts,
        {
          id: product.id,
          name: product.name,
          price: product.price,
          quantity: currentProduct.quantity,
          total: product.price * currentProduct.quantity,
        },
      ])
    }

    // Reset current product selection
    setCurrentProduct({
      id: "",
      quantity: 1,
    })
  }

  const removeProductFromOrder = (productId: string) => {
    setSelectedProducts(selectedProducts.filter((p) => p.id !== productId))
  }

  const viewOrderProducts = (order: ReservedOrder) => {
    setSelectedOrder(order)
    setIsProductsDialogOpen(true)
  }

  const getStatusBadge = (status: ReservedOrder["status"]) => {
    const colors = {
      pending: "bg-yellow-100 text-yellow-800",
      ready: "bg-blue-100 text-blue-800",
      completed: "bg-green-100 text-green-800",
      cancelled: "bg-red-100 text-red-800",
    }
    return <Badge className={colors[status]}>{statusLabels[status]}</Badge>
  }

  const getStatusIcon = (status: ReservedOrder["status"]) => {
    switch (status) {
      case "pending":
        return <Clock className="h-4 w-4 text-yellow-600" />
      case "ready":
        return <CheckCircle className="h-4 w-4 text-blue-600" />
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case "cancelled":
        return <XCircle className="h-4 w-4 text-red-600" />
      default:
        return <Clock className="h-4 w-4" />
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString("uz-UZ", {
      year: "numeric",
      month: "numeric",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const totalOrders = orders.length
  const pendingOrders = orders.filter((o) => o.status === "pending").length
  const readyOrders = orders.filter((o) => o.status === "ready").length
  const completedToday = orders.filter((o) => {
    if (o.status !== "completed" || !o.completed_at) return false
    const today = new Date().toDateString()
    const completedDate = new Date(o.completed_at).toDateString()
    return today === completedDate
  }).length

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Band Qilingan Mahsulotlar</h1>
        <Button onClick={openAddOrderDialog}>
          <Plus className="mr-2 h-4 w-4" />
          Yangi Band Qilish
        </Button>
      </div>

      {/* Statistika kartalari */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Jami Band Qilishlar</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalOrders}</div>
            <p className="text-xs text-muted-foreground">Barcha vaqt</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tayyorlanmoqda</CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{pendingOrders}</div>
            <p className="text-xs text-muted-foreground">Jarayonda</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tayyor</CardTitle>
            <CheckCircle className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{readyOrders}</div>
            <p className="text-xs text-muted-foreground">Olib ketishga tayyor</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Bugun Olib Ketildi</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{completedToday}</div>
            <p className="text-xs text-muted-foreground">Muvaffaqiyatli</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList>
          <TabsTrigger value="all">Barcha Band Qilishlar</TabsTrigger>
          <TabsTrigger value="active">Faol</TabsTrigger>
          <TabsTrigger value="completed">Yakunlangan</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Band Qilingan Mahsulotlar</CardTitle>
              <div className="flex gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Mijoz nomi yoki telefon raqami bo'yicha qidirish..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Holat" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Barcha holatlar</SelectItem>
                    <SelectItem value="pending">Tayyorlanmoqda</SelectItem>
                    <SelectItem value="ready">Tayyor</SelectItem>
                    <SelectItem value="completed">Olib ketildi</SelectItem>
                    <SelectItem value="cancelled">Bekor qilindi</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              {filteredOrders.length === 0 ? (
                <div className="text-center py-10">
                  <Package className="h-10 w-10 mx-auto text-muted-foreground mb-3" />
                  <p className="text-muted-foreground">Band qilingan mahsulotlar mavjud emas</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Mijoz</TableHead>
                      <TableHead>Olib ketish vaqti</TableHead>
                      <TableHead>Summa</TableHead>
                      <TableHead>Holat</TableHead>
                      <TableHead>Mahsulotlar</TableHead>
                      <TableHead>Amallar</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredOrders.map((order) => (
                      <TableRow key={order.id}>
                        <TableCell>
                          <div>
                            <p className="font-medium">#{order.id}</p>
                            <p className="text-sm text-muted-foreground">
                              {new Date(order.created_at).toLocaleDateString("uz-UZ")}
                            </p>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <User className="h-4 w-4 text-muted-foreground" />
                            <div>
                              <p className="font-medium">{order.customer_name}</p>
                              <p className="text-sm text-muted-foreground">{order.customer_phone}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            <span>{order.pickup_date ? formatDate(order.pickup_date) : "Belgilanmagan"}</span>
                          </div>
                        </TableCell>
                        <TableCell className="font-medium">{formatCurrency(order.total_amount)}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {getStatusIcon(order.status)}
                            {getStatusBadge(order.status)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Button variant="outline" size="sm" onClick={() => viewOrderProducts(order)}>
                            <Package className="h-4 w-4 mr-1" />
                            <span className="hidden sm:inline">{order.products.length} ta mahsulot</span>
                            <span className="sm:hidden">{order.products.length}</span>
                          </Button>
                        </TableCell>
                        <TableCell>
                          <Select
                            value={order.status}
                            onValueChange={(value: any) => handleStatusChange(order.id, value)}
                          >
                            <SelectTrigger className="w-32">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="pending">Tayyorlanmoqda</SelectItem>
                              <SelectItem value="ready">Tayyor</SelectItem>
                              <SelectItem value="completed">Olib ketildi</SelectItem>
                              <SelectItem value="cancelled">Bekor qilindi</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="active" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Faol Band Qilishlar</CardTitle>
            </CardHeader>
            <CardContent>
              {orders.filter((o) => ["pending", "ready"].includes(o.status)).length === 0 ? (
                <div className="text-center py-10">
                  <Package className="h-10 w-10 mx-auto text-muted-foreground mb-3" />
                  <p className="text-muted-foreground">Faol band qilishlar mavjud emas</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Mijoz</TableHead>
                      <TableHead>Olib ketish vaqti</TableHead>
                      <TableHead>Holat</TableHead>
                      <TableHead>Mahsulotlar</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {orders
                      .filter((o) => ["pending", "ready"].includes(o.status))
                      .map((order) => (
                        <TableRow key={order.id}>
                          <TableCell>#{order.id}</TableCell>
                          <TableCell>{order.customer_name}</TableCell>
                          <TableCell>{order.pickup_date ? formatDate(order.pickup_date) : "Belgilanmagan"}</TableCell>
                          <TableCell>{getStatusBadge(order.status)}</TableCell>
                          <TableCell>
                            <Button variant="outline" size="sm" onClick={() => viewOrderProducts(order)}>
                              <Package className="h-4 w-4 mr-1" />
                              {order.products.length} ta
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="completed" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Yakunlangan Band Qilishlar</CardTitle>
            </CardHeader>
            <CardContent>
              {orders.filter((o) => o.status === "completed").length === 0 ? (
                <div className="text-center py-10">
                  <Package className="h-10 w-10 mx-auto text-muted-foreground mb-3" />
                  <p className="text-muted-foreground">Yakunlangan band qilishlar mavjud emas</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Mijoz</TableHead>
                      <TableHead>Summa</TableHead>
                      <TableHead>Mahsulotlar</TableHead>
                      <TableHead>Olib ketilgan vaqt</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {orders
                      .filter((o) => o.status === "completed")
                      .map((order) => (
                        <TableRow key={order.id}>
                          <TableCell>#{order.id}</TableCell>
                          <TableCell>{order.customer_name}</TableCell>
                          <TableCell>{formatCurrency(order.total_amount)}</TableCell>
                          <TableCell>
                            <Button variant="outline" size="sm" onClick={() => viewOrderProducts(order)}>
                              <Package className="h-4 w-4 mr-1" />
                              {order.products.length} ta
                            </Button>
                          </TableCell>
                          <TableCell>{order.completed_at && formatDate(order.completed_at)}</TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Yangi band qilish qo'shish dialogi */}
      {isAddDialogOpen && (
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Yangi Mahsulot Band Qilish</DialogTitle>
            </DialogHeader>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="customer_name">Mijoz ismi *</Label>
                  <Input
                    id="customer_name"
                    value={formData.customer_name}
                    onChange={(e) => setFormData({ ...formData, customer_name: e.target.value })}
                    placeholder="Mijoz ismini kiriting"
                  />
                </div>

                <div>
                  <Label htmlFor="customer_phone">Telefon raqami *</Label>
                  <Input
                    id="customer_phone"
                    value={formData.customer_phone}
                    onChange={(e) => setFormData({ ...formData, customer_phone: e.target.value })}
                    placeholder="+998901234567"
                  />
                </div>

                <div>
                  <Label htmlFor="pickup_date">Olib ketish vaqti *</Label>
                  <Input
                    id="pickup_date"
                    type="datetime-local"
                    value={formData.pickup_date}
                    onChange={(e) => setFormData({ ...formData, pickup_date: e.target.value })}
                  />
                </div>

                <div>
                  <Label htmlFor="notes">Qo'shimcha eslatma</Label>
                  <Textarea
                    id="notes"
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    placeholder="Maxsus talablar yoki eslatmalar"
                  />
                </div>
              </div>

              <div className="space-y-4">
                <div className="font-medium">Mahsulotlar *</div>
                <div className="flex gap-2">
                  <Select
                    value={currentProduct.id}
                    onValueChange={(value) => setCurrentProduct({ ...currentProduct, id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Mahsulot tanlang" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableProducts.map((product) => (
                        <SelectItem key={product.id} value={product.id}>
                          {product.name} - {formatCurrency(product.price)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Input
                    type="number"
                    min="1"
                    value={currentProduct.quantity}
                    onChange={(e) =>
                      setCurrentProduct({ ...currentProduct, quantity: Number.parseInt(e.target.value) || 1 })
                    }
                    className="w-20"
                  />
                  <Button type="button" onClick={addProductToOrder} size="sm">
                    Qo'shish
                  </Button>
                </div>

                <div className="border rounded-md">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Mahsulot</TableHead>
                        <TableHead>Narx</TableHead>
                        <TableHead>Soni</TableHead>
                        <TableHead>Jami</TableHead>
                        <TableHead></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {selectedProducts.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center text-muted-foreground">
                            <div className="flex flex-col items-center py-4">
                              <ShoppingCart className="h-8 w-8 mb-2" />
                              Mahsulotlar qo'shilmagan
                            </div>
                          </TableCell>
                        </TableRow>
                      ) : (
                        selectedProducts.map((product) => (
                          <TableRow key={product.id}>
                            <TableCell>{product.name}</TableCell>
                            <TableCell>{formatCurrency(product.price)}</TableCell>
                            <TableCell>{product.quantity}</TableCell>
                            <TableCell>{formatCurrency(product.total)}</TableCell>
                            <TableCell>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => removeProductFromOrder(product.id)}
                                className="h-8 w-8 p-0"
                              >
                                <XCircle className="h-4 w-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                      {selectedProducts.length > 0 && (
                        <TableRow>
                          <TableCell colSpan={3} className="text-right font-medium">
                            Jami:
                          </TableCell>
                          <TableCell className="font-bold">
                            {formatCurrency(selectedProducts.reduce((sum, p) => sum + p.total, 0))}
                          </TableCell>
                          <TableCell></TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Bekor qilish
              </Button>
              <Button onClick={handleAddOrder}>Saqlash</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Mahsulotlarni ko'rish dialogi */}
      {isProductsDialogOpen && selectedOrder && (
        <Dialog open={isProductsDialogOpen} onOpenChange={setIsProductsDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                Band qilish #{selectedOrder.id} - {selectedOrder.customer_name}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <span className="font-medium">Holat:</span> {getStatusBadge(selectedOrder.status)}
                </div>
                <div>
                  <span className="font-medium">Sana:</span>{" "}
                  {new Date(selectedOrder.created_at).toLocaleDateString("uz-UZ")}
                </div>
              </div>

              <div>
                <span className="font-medium">Olib ketish vaqti:</span>{" "}
                {selectedOrder.pickup_date ? formatDate(selectedOrder.pickup_date) : "Belgilanmagan"}
              </div>

              <div className="border rounded-md">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Mahsulot</TableHead>
                      <TableHead>Narx</TableHead>
                      <TableHead>Soni</TableHead>
                      <TableHead>Jami</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedOrder.products.map((product) => (
                      <TableRow key={product.id}>
                        <TableCell>{product.name}</TableCell>
                        <TableCell>{formatCurrency(product.price)}</TableCell>
                        <TableCell>{product.quantity}</TableCell>
                        <TableCell>{formatCurrency(product.total)}</TableCell>
                      </TableRow>
                    ))}
                    <TableRow>
                      <TableCell colSpan={3} className="text-right font-medium">
                        Jami:
                      </TableCell>
                      <TableCell className="font-bold">{formatCurrency(selectedOrder.total_amount)}</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>

              {selectedOrder.notes && (
                <div>
                  <span className="font-medium">Eslatma:</span> {selectedOrder.notes}
                </div>
              )}
            </div>
            <DialogFooter>
              <Button onClick={() => setIsProductsDialogOpen(false)}>Yopish</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}
