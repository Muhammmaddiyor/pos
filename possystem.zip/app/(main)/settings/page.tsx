"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { Settings, Building, Printer, ShieldCheck, Bell, Keyboard } from "lucide-react" // Keyboard ikonkasini qo'shdim

export default function SettingsPage() {
  const [companySettings, setCompanySettings] = useState({
    name: "POS Pro Market",
    address: "Toshkent sh., Yunusobod t., 5-uy",
    phone: "+998712345678",
    email: "info@pospro.uz",
    website: "www.pospro.uz",
    tax_number: "123456789",
    currency: "UZS",
    language: "uz",
    timezone: "Asia/Tashkent",
  })

  const [receiptSettings, setReceiptSettings] = useState({
    header_text: "POS Pro Market",
    footer_text: "Xaridingiz uchun rahmat!",
    show_logo: true,
    show_barcode: true,
    paper_width: "80mm",
    auto_print: true,
  })

  const [taxSettings, setTaxSettings] = useState({
    default_tax_rate: "12",
    tax_inclusive: false,
    tax_number_required: true,
  })

  const [systemSettings, setSystemSettings] = useState({
    auto_backup: true,
    backup_frequency: "daily",
    low_stock_alert: true,
    low_stock_threshold: "10",
    session_timeout: "30",
    useVirtualKeyboard: false, // Add this line
  })

  const [notificationSettings, setNotificationSettings] = useState({
    email_notifications: true,
    sms_notifications: false,
    low_stock_alerts: true,
    daily_reports: true,
    new_customer_alerts: false,
  })

  const handleSaveCompanySettings = () => {
    // Bu yerda kompaniya sozlamalarini saqlash logikasi bo'ladi
    alert("Kompaniya sozlamalari saqlandi!")
  }

  const handleSaveReceiptSettings = () => {
    // Bu yerda chek sozlamalarini saqlash logikasi bo'ladi
    alert("Chek sozlamalari saqlandi!")
  }

  const handleSaveTaxSettings = () => {
    // Bu yerda soliq sozlamalarini saqlash logikasi bo'ladi
    alert("Soliq sozlamalari saqlandi!")
  }

  const handleSaveSystemSettings = () => {
    // Bu yerda tizim sozlamalarini saqlash logikasi bo'ladi
    alert("Tizim sozlamalari saqlandi!")
  }

  const handleSaveNotificationSettings = () => {
    // Bu yerda bildirishnoma sozlamalarini saqlash logikasi bo'ladi
    alert("Bildirishnoma sozlamalari saqlandi!")
  }

  const handleBackupNow = () => {
    alert("Zaxira nusxa yaratilmoqda...")
  }

  const handleRestoreBackup = () => {
    if (confirm("Zaxira nusxani tiklashni xohlaysizmi? Bu joriy ma'lumotlarni o'chiradi.")) {
      alert("Zaxira nusxa tiklanmoqda...")
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Settings className="h-8 w-8" />
        <h1 className="text-3xl font-bold">Sozlamalar</h1>
      </div>

      <Tabs defaultValue="company" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="company">Kompaniya</TabsTrigger>
          <TabsTrigger value="receipt">Chek</TabsTrigger>
          <TabsTrigger value="tax">Soliq</TabsTrigger>
          <TabsTrigger value="system">Tizim</TabsTrigger>
          <TabsTrigger value="notifications">Bildirishnomalar</TabsTrigger>
        </TabsList>

        <TabsContent value="company" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building className="h-5 w-5" />
                Kompaniya Ma'lumotlari
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="company_name">Kompaniya nomi *</Label>
                  <Input
                    id="company_name"
                    value={companySettings.name}
                    onChange={(e) => setCompanySettings({ ...companySettings, name: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="tax_number">Soliq raqami</Label>
                  <Input
                    id="tax_number"
                    value={companySettings.tax_number}
                    onChange={(e) => setCompanySettings({ ...companySettings, tax_number: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="address">Manzil</Label>
                <Textarea
                  id="address"
                  value={companySettings.address}
                  onChange={(e) => setCompanySettings({ ...companySettings, address: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="phone">Telefon</Label>
                  <Input
                    id="phone"
                    value={companySettings.phone}
                    onChange={(e) => setCompanySettings({ ...companySettings, phone: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={companySettings.email}
                    onChange={(e) => setCompanySettings({ ...companySettings, email: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="currency">Valyuta</Label>
                  <Select
                    value={companySettings.currency}
                    onValueChange={(value) => setCompanySettings({ ...companySettings, currency: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="UZS">O'zbek so'mi (UZS)</SelectItem>
                      <SelectItem value="USD">Dollar (USD)</SelectItem>
                      <SelectItem value="EUR">Evro (EUR)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="language">Til</Label>
                  <Select
                    value={companySettings.language}
                    onValueChange={(value) => setCompanySettings({ ...companySettings, language: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="uz">O'zbekcha</SelectItem>
                      <SelectItem value="ru">Русский</SelectItem>
                      <SelectItem value="en">English</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="timezone">Vaqt zonasi</Label>
                  <Select
                    value={companySettings.timezone}
                    onValueChange={(value) => setCompanySettings({ ...companySettings, timezone: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Asia/Tashkent">Toshkent</SelectItem>
                      <SelectItem value="Asia/Samarkand">Samarqand</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button onClick={handleSaveCompanySettings} className="w-full">
                Saqlash
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="receipt" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Printer className="h-5 w-5" />
                Chek Sozlamalari
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="header_text">Chek sarlavhasi</Label>
                  <Input
                    id="header_text"
                    value={receiptSettings.header_text}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, header_text: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="paper_width">Qog'oz kengligi</Label>
                  <Select
                    value={receiptSettings.paper_width}
                    onValueChange={(value) => setReceiptSettings({ ...receiptSettings, paper_width: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="58mm">58mm</SelectItem>
                      <SelectItem value="80mm">80mm</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="footer_text">Chek oxiri matni</Label>
                <Textarea
                  id="footer_text"
                  value={receiptSettings.footer_text}
                  onChange={(e) => setReceiptSettings({ ...receiptSettings, footer_text: e.target.value })}
                />
              </div>

              <Separator />

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="show_logo">Logotipni ko'rsatish</Label>
                  <Switch
                    id="show_logo"
                    checked={receiptSettings.show_logo}
                    onCheckedChange={(checked) => setReceiptSettings({ ...receiptSettings, show_logo: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="show_barcode">Barkodni ko'rsatish</Label>
                  <Switch
                    id="show_barcode"
                    checked={receiptSettings.show_barcode}
                    onCheckedChange={(checked) => setReceiptSettings({ ...receiptSettings, show_barcode: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="auto_print">Avtomatik chop etish</Label>
                  <Switch
                    id="auto_print"
                    checked={receiptSettings.auto_print}
                    onCheckedChange={(checked) => setReceiptSettings({ ...receiptSettings, auto_print: checked })}
                  />
                </div>
              </div>

              <Button onClick={handleSaveReceiptSettings} className="w-full">
                Saqlash
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tax" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShieldCheck className="h-5 w-5" />
                Soliq Sozlamalari
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="default_tax_rate">Standart soliq stavkasi (%)</Label>
                  <Input
                    id="default_tax_rate"
                    type="number"
                    value={taxSettings.default_tax_rate}
                    onChange={(e) => setTaxSettings({ ...taxSettings, default_tax_rate: e.target.value })}
                  />
                </div>
                <div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="tax_inclusive">Narx soliqni o'z ichiga oladi</Label>
                    <Switch
                      id="tax_inclusive"
                      checked={taxSettings.tax_inclusive}
                      onCheckedChange={(checked) => setTaxSettings({ ...taxSettings, tax_inclusive: checked })}
                    />
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="tax_number_required">Soliq raqami majburiy</Label>
                <Switch
                  id="tax_number_required"
                  checked={taxSettings.tax_number_required}
                  onCheckedChange={(checked) => setTaxSettings({ ...taxSettings, tax_number_required: checked })}
                />
              </div>

              <Button onClick={handleSaveTaxSettings} className="w-full">
                Saqlash
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="system" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Tizim Sozlamalari
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="auto_backup">Avtomatik zaxira</Label>
                <Switch
                  id="auto_backup"
                  checked={systemSettings.auto_backup}
                  onCheckedChange={(checked) => setSystemSettings({ ...systemSettings, auto_backup: checked })}
                />
              </div>

              <div>
                <Label htmlFor="backup_frequency">Zaxira nusxa olish chastotasi</Label>
                <Select
                  value={systemSettings.backup_frequency}
                  onValueChange={(value) => setSystemSettings({ ...systemSettings, backup_frequency: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Har kuni</SelectItem>
                    <SelectItem value="weekly">Har hafta</SelectItem>
                    <SelectItem value="monthly">Har oyda</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="low_stock_alert">Kam zaxira ogohlantirishlari</Label>
                <Switch
                  id="low_stock_alert"
                  checked={systemSettings.low_stock_alert}
                  onCheckedChange={(checked) => setSystemSettings({ ...systemSettings, low_stock_alert: checked })}
                />
              </div>

              <div>
                <Label htmlFor="low_stock_threshold">Kam zaxira chegarasi</Label>
                <Input
                  id="low_stock_threshold"
                  type="number"
                  value={systemSettings.low_stock_threshold}
                  onChange={(e) => setSystemSettings({ ...systemSettings, low_stock_threshold: e.target.value })}
                />
              </div>

              <div>
                <Label htmlFor="session_timeout">Sessiya vaqti tugashi (daqiqalarda)</Label>
                <Input
                  id="session_timeout"
                  type="number"
                  value={systemSettings.session_timeout}
                  onChange={(e) => setSystemSettings({ ...systemSettings, session_timeout: e.target.value })}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="use_virtual_keyboard" className="flex items-center gap-2">
                  <Keyboard className="h-4 w-4" />
                  Virtual klaviaturani ishlatish
                </Label>
                <Switch
                  id="use_virtual_keyboard"
                  checked={systemSettings.useVirtualKeyboard}
                  onCheckedChange={(checked) => setSystemSettings({ ...systemSettings, useVirtualKeyboard: checked })}
                />
              </div>

              <div className="flex justify-between">
                <Button onClick={handleBackupNow} variant="outline">
                  Zaxira nusxani hozir yaratish
                </Button>
                <Button onClick={handleRestoreBackup} variant="destructive">
                  Zaxira nusxani tiklash
                </Button>
              </div>

              <Button onClick={handleSaveSystemSettings} className="w-full">
                Saqlash
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5" />
                Bildirishnoma Sozlamalari
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="email_notifications">Email orqali bildirishnomalar</Label>
                <Switch
                  id="email_notifications"
                  checked={notificationSettings.email_notifications}
                  onCheckedChange={(checked) =>
                    setNotificationSettings({ ...notificationSettings, email_notifications: checked })
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="sms_notifications">SMS orqali bildirishnomalar</Label>
                <Switch
                  id="sms_notifications"
                  checked={notificationSettings.sms_notifications}
                  onCheckedChange={(checked) =>
                    setNotificationSettings({ ...notificationSettings, sms_notifications: checked })
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="low_stock_alerts">Kam zaxira ogohlantirishlari</Label>
                <Switch
                  id="low_stock_alerts"
                  checked={notificationSettings.low_stock_alerts}
                  onCheckedChange={(checked) =>
                    setNotificationSettings({ ...notificationSettings, low_stock_alerts: checked })
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="daily_reports">Kunlik hisobotlar</Label>
                <Switch
                  id="daily_reports"
                  checked={notificationSettings.daily_reports}
                  onCheckedChange={(checked) =>
                    setNotificationSettings({ ...notificationSettings, daily_reports: checked })
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="new_customer_alerts">Yangi mijoz ogohlantirishlari</Label>
                <Switch
                  id="new_customer_alerts"
                  checked={notificationSettings.new_customer_alerts}
                  onCheckedChange={(checked) =>
                    setNotificationSettings({ ...notificationSettings, new_customer_alerts: checked })
                  }
                />
              </div>

              <Button onClick={handleSaveNotificationSettings} className="w-full">
                Saqlash
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
