"use client"

import { ScrollArea } from "@/components/ui/scroll-area"
import { TooltipProvider } from "@/components/ui/tooltip"
import { useState, useMemo, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Line,
  LineChart,
  Pie,
  PieChart,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip as RechartsTooltip,
  BarChart,
  Bar,
} from "recharts"
import { Download, TrendingUp, ShoppingCart, DollarSign, Package, Percent, BarChart3, FileText } from "lucide-react"
import type { DateRange } from "react-day-picker"
import { addDays, format as formatDateFn, parseISO, startOfMonth, subMonths } from "date-fns"

// Helper Functions & Types
const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat("uz-UZ", { style: "currency", currency: "UZS", minimumFractionDigits: 0 }).format(amount)
}

// localStorage dan ma'lumotlarni yuklash funksiyasi
const loadFromLocalStorage = <T,>(key: string, defaultValue: T): T => {
  if (typeof window === "undefined") return defaultValue
  try {
    const item = window.localStorage.getItem(key)
    return item ? JSON.parse(item) : defaultValue
  } catch (error) {
    console.error(`Error loading ${key} from localStorage:`, error)
    return defaultValue
  }
}

interface ReportSaleItem {
  id: string
  productId: string
  productName: string
  category: string
  quantity: number
  unitPrice: number
  unitCost: number
  totalAmount: number
  totalCost: number
  profit: number
  customerId?: string
  employeeId?: string
  date: string
}

// Custom tooltip component for charts
const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-background border rounded-lg shadow-lg p-3">
        <p className="font-medium text-sm mb-1">{label}</p>
        {payload.map((entry: any, index: number) => (
          <div key={`item-${index}`} className="flex items-center gap-2 text-sm">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }} />
            <span className="text-muted-foreground">{entry.name}:</span>
            <span className="font-medium">
              {entry.name.toLowerCase().includes("foyda") || entry.name.toLowerCase().includes("sotuv")
                ? formatCurrency(entry.value)
                : entry.value}
            </span>
          </div>
        ))}
      </div>
    )
  }
  return null
}

// Custom tooltip for pie chart
const CustomPieTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-background border rounded-lg shadow-lg p-3">
        <p className="font-medium text-sm mb-1">{payload[0].name}</p>
        <div className="flex items-center gap-2 text-sm">
          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: payload[0].color }} />
          <span className="text-muted-foreground">Summa:</span>
          <span className="font-medium">{formatCurrency(payload[0].value)}</span>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <div className="w-3 h-3 rounded-full opacity-0" />
          <span className="text-muted-foreground">Ulushi:</span>
          <span className="font-medium">{`${(payload[0].percent * 100).toFixed(1)}%`}</span>
        </div>
      </div>
    )
  }
  return null
}

const PIE_COLORS = [
  "#0088FE",
  "#00C49F",
  "#FFBB28",
  "#FF8042",
  "#8884d8",
  "#82ca9d",
  "#ffc658",
  "#8dd1e1",
  "#a4de6c",
  "#d0ed57",
  "#83a6ed",
  "#8884d8",
  "#82ca9d",
  "#ffc658",
  "#8dd1e1",
  "#a4de6c",
]

export default function ReportsPage() {
  const initialEndDate = new Date()
  const initialStartDate = subMonths(startOfMonth(new Date()), 6)

  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: initialStartDate,
    to: initialEndDate,
  })
  const [timeGrouping, setTimeGrouping] = useState<"daily" | "monthly">("monthly")
  const [activeTab, setActiveTab] = useState("overview")
  const [salesData, setSalesData] = useState<any[]>([])
  const [products, setProducts] = useState<any[]>([])
  const [customers, setCustomers] = useState<any[]>([])
  const [employees, setEmployees] = useState<any[]>([])
  const [expenses, setExpenses] = useState<any[]>([])

  useEffect(() => {
    // Ma'lumotlarni localStorage dan yuklash
    setSalesData(loadFromLocalStorage("sales", []))
    setProducts(loadFromLocalStorage("products_list", []))
    setCustomers(loadFromLocalStorage("customers", []))
    setEmployees(loadFromLocalStorage("employees", []))
    setExpenses(loadFromLocalStorage("expenses", []))

    // localStorage o'zgarishlarini kuzatish
    const handleStorageChange = () => {
      setSalesData(loadFromLocalStorage("sales", []))
      setProducts(loadFromLocalStorage("products_list", []))
      setCustomers(loadFromLocalStorage("customers", []))
      setEmployees(loadFromLocalStorage("employees", []))
      setExpenses(loadFromLocalStorage("expenses", []))
    }

    window.addEventListener("storage", handleStorageChange)
    return () => window.removeEventListener("storage", handleStorageChange)
  }, [])

  // Sotuvlarni hisobot formatiga o'tkazish
  const allSalesData: ReportSaleItem[] = useMemo(() => {
    const reportItems: ReportSaleItem[] = []

    salesData.forEach((sale) => {
      sale.items?.forEach((item: any) => {
        const product = products.find((p) => p.id === item.product_id)
        if (product) {
          reportItems.push({
            id: `${sale.id}-${item.product_id}`,
            productId: item.product_id,
            productName: product.name,
            category: product.category || "Boshqa",
            quantity: item.quantity,
            unitPrice: item.unit_price,
            unitCost: product.cost || item.unit_price * 0.7, // Agar tannarx yo'q bo'lsa, 70% deb hisoblaymiz
            totalAmount: item.total_price,
            totalCost: (product.cost || item.unit_price * 0.7) * item.quantity,
            profit: item.total_price - (product.cost || item.unit_price * 0.7) * item.quantity,
            customerId: sale.customer_id,
            employeeId: sale.employee_id,
            date: sale.created_at,
          })
        }
      })
    })

    return reportItems
  }, [salesData, products])

  const filteredSalesData = useMemo(() => {
    if (!dateRange?.from || !dateRange?.to) return allSalesData
    return allSalesData.filter((sale) => {
      if (!sale.date) return false // Add this check
      try {
        const saleDate = parseISO(sale.date)
        return saleDate >= dateRange.from! && saleDate <= addDays(dateRange.to!, 1)
      } catch (error) {
        console.error("Error parsing sale date:", sale.date, error)
        return false
      }
    })
  }, [dateRange, allSalesData])

  const aggregatedDataByTime = useMemo(() => {
    const grouped: { [key: string]: { revenue: number; profit: number; transactions: number; itemsSold: number } } = {}
    filteredSalesData.forEach((sale) => {
      if (!sale.date) return // Add this check
      try {
        const saleDate = parseISO(sale.date)
        let key: string
        if (timeGrouping === "monthly") {
          key = formatDateFn(saleDate, "yyyy-MM (MMM)")
        } else {
          key = formatDateFn(saleDate, "yyyy-MM-dd")
        }
        if (!grouped[key]) {
          grouped[key] = { revenue: 0, profit: 0, transactions: 0, itemsSold: 0 }
        }
        grouped[key].revenue += sale.totalAmount
        grouped[key].profit += sale.profit
        grouped[key].itemsSold += sale.quantity
      } catch (error) {
        console.error("Error parsing sale date in aggregation:", sale.date, error)
      }
    })

    const transactionsPerPeriod: { [key: string]: number } = {}
    const uniqueTransactions = new Set()
    filteredSalesData.forEach((sale) => {
      if (!sale.date) return // Add this check
      try {
        const saleDate = parseISO(sale.date)
        let key: string
        if (timeGrouping === "monthly") {
          key = formatDateFn(saleDate, "yyyy-MM (MMM)")
        } else {
          key = formatDateFn(saleDate, "yyyy-MM-dd")
        }
        const transactionKey = `${key}-${sale.id.split("-")[0]}`
        if (!uniqueTransactions.has(transactionKey)) {
          if (!transactionsPerPeriod[key]) transactionsPerPeriod[key] = 0
          transactionsPerPeriod[key]++
          uniqueTransactions.add(transactionKey)
        }
      } catch (error) {
        console.error("Error parsing sale date in transactions:", sale.date, error)
      }
    })

    return Object.entries(grouped)
      .map(([timePeriod, data]) => ({
        timePeriod,
        revenue: data.revenue,
        profit: data.profit,
        transactions: transactionsPerPeriod[timePeriod] || 0,
        itemsSold: data.itemsSold,
        avgTransactionValue:
          (transactionsPerPeriod[timePeriod] || 0) > 0 ? data.revenue / (transactionsPerPeriod[timePeriod] || 1) : 0,
      }))
      .sort((a, b) => a.timePeriod.localeCompare(b.timePeriod))
  }, [filteredSalesData, timeGrouping])

  const topSellingProducts = useMemo(() => {
    const productSales: { [key: string]: { name: string; quantity: number; revenue: number; profit: number } } = {}
    filteredSalesData.forEach((sale) => {
      if (!productSales[sale.productId]) {
        productSales[sale.productId] = { name: sale.productName, quantity: 0, revenue: 0, profit: 0 }
      }
      productSales[sale.productId].quantity += sale.quantity
      productSales[sale.productId].revenue += sale.totalAmount
      productSales[sale.productId].profit += sale.profit
    })
    return Object.values(productSales)
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 10)
  }, [filteredSalesData])

  const salesByCategory = useMemo(() => {
    const categorySales: { [key: string]: { name: string; revenue: number; profit: number } } = {}
    filteredSalesData.forEach((sale) => {
      if (!categorySales[sale.category]) {
        categorySales[sale.category] = { name: sale.category, revenue: 0, profit: 0 }
      }
      categorySales[sale.category].revenue += sale.totalAmount
      categorySales[sale.category].profit += sale.profit
    })
    return Object.values(categorySales).sort((a, b) => b.revenue - a.revenue)
  }, [filteredSalesData])

  // Employee performance data
  const employeePerformance = useMemo(() => {
    const performance: {
      [key: string]: {
        id: string
        name: string
        totalSales: number
        totalProfit: number
        transactionCount: number
        avgTransactionValue: number
      }
    } = {}

    // Group sales by employee
    filteredSalesData.forEach((sale) => {
      if (!sale.employeeId) return

      if (!performance[sale.employeeId]) {
        const employee = employees.find((e) => e.id === sale.employeeId)
        performance[sale.employeeId] = {
          id: sale.employeeId,
          name: employee ? `${employee.first_name} ${employee.last_name}` : `Xodim #${sale.employeeId}`,
          totalSales: 0,
          totalProfit: 0,
          transactionCount: 0,
          avgTransactionValue: 0,
        }
      }

      performance[sale.employeeId].totalSales += sale.totalAmount
      performance[sale.employeeId].totalProfit += sale.profit
    })

    // Calculate transaction counts
    const uniqueTransactions = new Set()
    filteredSalesData.forEach((sale) => {
      if (!sale.employeeId) return
      const transactionKey = `${sale.employeeId}-${sale.id.split("-")[0]}`
      if (!uniqueTransactions.has(transactionKey)) {
        performance[sale.employeeId].transactionCount++
        uniqueTransactions.add(transactionKey)
      }
    })

    // Calculate average transaction value
    Object.values(performance).forEach((emp) => {
      emp.avgTransactionValue = emp.transactionCount > 0 ? emp.totalSales / emp.transactionCount : 0
    })

    return Object.values(performance).sort((a, b) => b.totalSales - a.totalSales)
  }, [filteredSalesData, employees])

  // Daily sales distribution
  const dailySalesDistribution = useMemo(() => {
    const days = ["Yakshanba", "Dushanba", "Seshanba", "Chorshanba", "Payshanba", "Juma", "Shanba"]
    const distribution = days.map((day) => ({ name: day, sales: 0, transactions: 0 }))

    // Count sales by day of week
    const transactionsByDay = new Map()
    filteredSalesData.forEach((sale) => {
      if (!sale.date) return // Add this check
      try {
        const saleDate = parseISO(sale.date)
        const dayOfWeek = saleDate.getDay() // 0 = Sunday, 1 = Monday, etc.

        distribution[dayOfWeek].sales += sale.totalAmount

        // Count unique transactions
        const transactionKey = `${dayOfWeek}-${sale.id.split("-")[0]}`
        if (!transactionsByDay.has(transactionKey)) {
          distribution[dayOfWeek].transactions++
          transactionsByDay.set(transactionKey, true)
        }
      } catch (error) {
        console.error("Error parsing sale date in daily distribution:", sale.date, error)
      }
    })

    return distribution
  }, [filteredSalesData])

  const totalStats = useMemo(() => {
    const totalRevenue = filteredSalesData.reduce((sum, s) => sum + s.totalAmount, 0)
    const totalProfit = filteredSalesData.reduce((sum, s) => sum + s.profit, 0)
    const uniqueTransactions = new Set(filteredSalesData.map((s) => s.id.split("-")[0])).size
    const totalItemsSold = filteredSalesData.reduce((sum, s) => sum + s.quantity, 0)

    // Calculate total expenses for the period
    const filteredExpenses = expenses.filter((expense) => {
      if (!dateRange?.from || !dateRange?.to || !expense.date) return false
      try {
        const expenseDate = parseISO(expense.date)
        return expenseDate >= dateRange.from && expenseDate <= addDays(dateRange.to, 1)
      } catch (error) {
        console.error("Error parsing expense date:", expense.date, error)
        return false
      }
    })
    const totalExpenses = filteredExpenses.reduce((sum, e) => sum + e.amount, 0)

    return {
      totalRevenue,
      totalProfit,
      totalTransactions: uniqueTransactions,
      totalItemsSold,
      avgTransactionValue: uniqueTransactions > 0 ? totalRevenue / uniqueTransactions : 0,
      profitMargin: totalRevenue > 0 ? (totalProfit / totalRevenue) * 100 : 0,
      totalExpenses,
      netProfit: totalProfit - totalExpenses,
    }
  }, [filteredSalesData, expenses, dateRange])

  const exportToCSV = (data: any[], filename: string) => {
    if (data.length === 0) {
      alert("Eksport uchun ma'lumot yo'q.")
      return
    }
    const headers = Object.keys(data[0]).join(",")
    const rows = data.map((row) => Object.values(row).join(",")).join("\n")
    const csvContent = `data:text/csv;charset=utf-8,${headers}\n${rows}`
    const encodedUri = encodeURI(csvContent)
    const link = document.createElement("a")
    link.setAttribute("href", encodedUri)
    link.setAttribute("download", `${filename}.csv`)
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const printReport = () => {
    window.print()
  }

  return (
    <TooltipProvider>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
          <h1 className="text-3xl font-bold">Hisobotlar</h1>
          <div className="flex gap-2 items-center">
            <Select value={timeGrouping} onValueChange={(value: "daily" | "monthly") => setTimeGrouping(value)}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Guruhlash" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="monthly">Oylik</SelectItem>
                <SelectItem value="daily">Kunlik</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() =>
                  setDateRange({
                    from: new Date(),
                    to: new Date(),
                  })
                }
              >
                Bugun
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() =>
                  setDateRange({
                    from: addDays(new Date(), -7),
                    to: new Date(),
                  })
                }
              >
                7 kun
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() =>
                  setDateRange({
                    from: addDays(new Date(), -30),
                    to: new Date(),
                  })
                }
              >
                30 kun
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() =>
                  setDateRange({
                    from: subMonths(new Date(), 3),
                    to: new Date(),
                  })
                }
              >
                3 oy
              </Button>
            </div>

            <div className="text-sm text-muted-foreground">
              {dateRange?.from && dateRange?.to ? (
                <>
                  {formatDateFn(dateRange.from, "dd/MM/yyyy")} - {formatDateFn(dateRange.to, "dd/MM/yyyy")}
                </>
              ) : (
                "Barcha sanalar"
              )}
            </div>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Umumiy</TabsTrigger>
            <TabsTrigger value="sales">Sotuvlar</TabsTrigger>
            <TabsTrigger value="employees">Xodimlar</TabsTrigger>
            <TabsTrigger value="financial">Moliyaviy</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Jami Sotuv</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{formatCurrency(totalStats.totalRevenue)}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Jami Foyda</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{formatCurrency(totalStats.totalProfit)}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Foyda Marjasi</CardTitle>
                  <Percent className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{totalStats.profitMargin.toFixed(1)}%</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Tranzaksiyalar</CardTitle>
                  <ShoppingCart className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{totalStats.totalTransactions}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">O'rtacha Chek</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{formatCurrency(totalStats.avgTransactionValue)}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Sotilgan Mahs.</CardTitle>
                  <Package className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{totalStats.totalItemsSold}</div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Sotuvlar va Foyda Dinamikasi</CardTitle>
                <CardDescription>Tanlangan davr uchun sotuvlar va foyda o'zgarishi.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[350px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={aggregatedDataByTime} margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="timePeriod" tickLine={false} axisLine={false} tickMargin={8} />
                      <YAxis
                        yAxisId="left"
                        orientation="left"
                        stroke="#8884d8"
                        tickFormatter={(value) => formatCurrency(value).replace("UZS", "")}
                      />
                      <YAxis
                        yAxisId="right"
                        orientation="right"
                        stroke="#82ca9d"
                        tickFormatter={(value) => formatCurrency(value).replace("UZS", "")}
                      />
                      <RechartsTooltip content={<CustomTooltip />} />
                      <Legend />
                      <Line
                        yAxisId="left"
                        type="monotone"
                        dataKey="revenue"
                        stroke="#8884d8"
                        strokeWidth={2}
                        dot={true}
                        name="Sotuvlar"
                        isAnimationActive={true}
                        animationDuration={800}
                        activeDot={{ r: 6, strokeWidth: 2, fill: "#fff", stroke: "#8884d8" }}
                      />
                      <Line
                        yAxisId="right"
                        type="monotone"
                        dataKey="profit"
                        stroke="#82ca9d"
                        strokeWidth={2}
                        dot={true}
                        name="Foyda"
                        isAnimationActive={true}
                        animationDuration={800}
                        activeDot={{ r: 6, strokeWidth: 2, fill: "#fff", stroke: "#82ca9d" }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle>Eng Ko'p Sotilgan Mahsulotlar</CardTitle>
                    <CardDescription>Tanlangan davrda eng ko'p daromad keltirgan mahsulotlar.</CardDescription>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => exportToCSV(topSellingProducts, "top_selling_products")}
                  >
                    <Download className="mr-2 h-4 w-4" /> CSV
                  </Button>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Mahsulot</TableHead>
                        <TableHead className="text-right">Sotilgan Miqdor</TableHead>
                        <TableHead className="text-right">Jami Summa</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {topSellingProducts.length > 0 ? (
                        topSellingProducts.map((product) => (
                          <TableRow key={product.name}>
                            <TableCell className="font-medium">{product.name}</TableCell>
                            <TableCell className="text-right">{product.quantity} ta</TableCell>
                            <TableCell className="text-right">{formatCurrency(product.revenue)}</TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={3} className="text-center py-4">
                            Ma'lumot mavjud emas
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle>Kategoriyalar Bo'yicha Sotuvlar</CardTitle>
                    <CardDescription>Har bir kategoriya uchun umumiy sotuvlar.</CardDescription>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      exportToCSV(
                        salesByCategory.map((c) => ({ kategoriya: c.name, summa: c.revenue })),
                        "sales_by_category",
                      )
                    }
                  >
                    <Download className="mr-2 h-4 w-4" /> CSV
                  </Button>
                </CardHeader>
                <CardContent>
                  {salesByCategory.length > 0 ? (
                    <div className="h-[300px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={salesByCategory}
                            dataKey="revenue"
                            nameKey="name"
                            cx="50%"
                            cy="50%"
                            outerRadius={100}
                            labelLine={false}
                            label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                            isAnimationActive={true}
                            animationDuration={800}
                          >
                            {salesByCategory.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                            ))}
                          </Pie>
                          <RechartsTooltip content={<CustomPieTooltip />} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  ) : (
                    <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                      Ma'lumot mavjud emas
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="sales" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Hafta Kunlari Bo'yicha Sotuvlar</CardTitle>
                <CardDescription>Hafta kunlari bo'yicha sotuvlar va tranzaksiyalar soni.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[350px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={dailySalesDistribution} margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="name" />
                      <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
                      <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
                      <RechartsTooltip content={<CustomTooltip />} />
                      <Legend />
                      <Bar yAxisId="left" dataKey="sales" name="Sotuvlar" fill="#8884d8" radius={[4, 4, 0, 0]} />
                      <Bar
                        yAxisId="right"
                        dataKey="transactions"
                        name="Tranzaksiyalar"
                        fill="#82ca9d"
                        radius={[4, 4, 0, 0]}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Batafsil Sotuvlar Ro'yxati</CardTitle>
                  <CardDescription>Tanlangan davr uchun barcha sotuv operatsiyalari.</CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      exportToCSV(
                        filteredSalesData.map((s) => ({
                          sana: formatDateFn(parseISO(s.date), "yyyy-MM-dd HH:mm"),
                          mahsulot: s.productName,
                          kategoriya: s.category,
                          miqdori: s.quantity,
                          narxi: s.unitPrice,
                          tannarxi: s.unitCost,
                          jami_summa: s.totalAmount,
                          foyda: s.profit,
                        })),
                        "detailed_sales_report",
                      )
                    }
                  >
                    <Download className="mr-2 h-4 w-4" /> CSV
                  </Button>
                  <Button variant="outline" size="sm" onClick={printReport}>
                    <FileText className="mr-2 h-4 w-4" /> Chop etish
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Sana</TableHead>
                        <TableHead>Mahsulot</TableHead>
                        <TableHead>Miqdori</TableHead>
                        <TableHead className="text-right">Narxi</TableHead>
                        <TableHead className="text-right">Jami Summa</TableHead>
                        <TableHead className="text-right">Foyda</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredSalesData.length > 0 ? (
                        filteredSalesData.slice(0, 50).map((sale) => (
                          <TableRow key={sale.id}>
                            <TableCell>
                              {sale.date ? formatDateFn(parseISO(sale.date), "dd/MM/yy HH:mm") : "N/A"}
                            </TableCell>
                            <TableCell>
                              <div className="font-medium">{sale.productName}</div>
                              <div className="text-xs text-muted-foreground">{sale.category}</div>
                            </TableCell>
                            <TableCell>{sale.quantity}</TableCell>
                            <TableCell className="text-right">{formatCurrency(sale.unitPrice)}</TableCell>
                            <TableCell className="text-right">{formatCurrency(sale.totalAmount)}</TableCell>
                            <TableCell className="text-right">{formatCurrency(sale.profit)}</TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center py-4">
                            Ma'lumot mavjud emas
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="employees" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Xodimlar Samaradorligi</CardTitle>
                <CardDescription>Tanlangan davr uchun xodimlar samaradorligi ko'rsatkichlari.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[350px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={employeePerformance}
                      margin={{ top: 5, right: 20, left: 20, bottom: 5 }}
                      layout="vertical"
                    >
                      <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
                      <XAxis type="number" tickFormatter={(value) => formatCurrency(value).replace("UZS", "")} />
                      <YAxis dataKey="name" type="category" width={150} />
                      <RechartsTooltip content={<CustomTooltip />} />
                      <Legend />
                      <Bar dataKey="totalSales" name="Sotuvlar" fill="#8884d8" radius={[0, 4, 4, 0]} />
                      <Bar dataKey="totalProfit" name="Foyda" fill="#82ca9d" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Xodimlar Bo'yicha Batafsil Ma'lumot</CardTitle>
                  <CardDescription>Har bir xodim bo'yicha sotuvlar va samaradorlik ko'rsatkichlari.</CardDescription>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() =>
                    exportToCSV(
                      employeePerformance.map((e) => ({
                        xodim: e.name,
                        sotuvlar: e.totalSales,
                        foyda: e.totalProfit,
                        tranzaksiyalar: e.transactionCount,
                        ortacha_chek: e.avgTransactionValue,
                      })),
                      "employee_performance",
                    )
                  }
                >
                  <Download className="mr-2 h-4 w-4" /> CSV
                </Button>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Xodim</TableHead>
                      <TableHead className="text-right">Sotuvlar</TableHead>
                      <TableHead className="text-right">Foyda</TableHead>
                      <TableHead className="text-right">Tranzaksiyalar</TableHead>
                      <TableHead className="text-right">O'rtacha Chek</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {employeePerformance.length > 0 ? (
                      employeePerformance.map((employee) => (
                        <TableRow key={employee.id}>
                          <TableCell className="font-medium">{employee.name}</TableCell>
                          <TableCell className="text-right">{formatCurrency(employee.totalSales)}</TableCell>
                          <TableCell className="text-right">{formatCurrency(employee.totalProfit)}</TableCell>
                          <TableCell className="text-right">{employee.transactionCount}</TableCell>
                          <TableCell className="text-right">{formatCurrency(employee.avgTransactionValue)}</TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-4">
                          Ma'lumot mavjud emas
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="financial" className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Jami Daromad</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{formatCurrency(totalStats.totalRevenue)}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Jami Xarajatlar</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{formatCurrency(totalStats.totalExpenses)}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Sof Foyda</CardTitle>
                  <BarChart3 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{formatCurrency(totalStats.netProfit)}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Rentabellik</CardTitle>
                  <Percent className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {totalStats.totalRevenue > 0
                      ? ((totalStats.netProfit / totalStats.totalRevenue) * 100).toFixed(1)
                      : "0.0"}
                    %
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Daromad va Xarajatlar Taqqoslash</CardTitle>
                <CardDescription>Tanlangan davr uchun daromad va xarajatlar nisbati.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[350px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={[
                        {
                          name: "Moliyaviy Ko'rsatkichlar",
                          daromad: totalStats.totalRevenue,
                          xarajat: totalStats.totalExpenses,
                          foyda: totalStats.netProfit,
                        },
                      ]}
                      margin={{ top: 5, right: 20, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="name" />
                      <YAxis tickFormatter={(value) => formatCurrency(value).replace("UZS", "")} />
                      <RechartsTooltip content={<CustomTooltip />} />
                      <Legend />
                      <Bar dataKey="daromad" name="Daromad" fill="#8884d8" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="xarajat" name="Xarajat" fill="#ff8042" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="foyda" name="Sof Foyda" fill="#82ca9d" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Xarajatlar Ro'yxati</CardTitle>
                  <CardDescription>Tanlangan davr uchun barcha xarajatlar.</CardDescription>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() =>
                    exportToCSV(
                      expenses
                        .filter((expense) => {
                          if (!dateRange?.from || !dateRange?.to) return true
                          const expenseDate = parseISO(expense.date)
                          return expenseDate >= dateRange.from && expenseDate <= addDays(dateRange.to, 1)
                        })
                        .map((e) => ({
                          sana: formatDateFn(parseISO(e.date), "yyyy-MM-dd"),
                          kategoriya: e.category,
                          summa: e.amount,
                          izoh: e.description,
                          tolov_usuli: e.payment_method,
                        })),
                      "expenses_report",
                    )
                  }
                >
                  <Download className="mr-2 h-4 w-4" /> CSV
                </Button>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[300px]">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Sana</TableHead>
                        <TableHead>Kategoriya</TableHead>
                        <TableHead>Izoh</TableHead>
                        <TableHead>To'lov Usuli</TableHead>
                        <TableHead className="text-right">Summa</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {expenses.length > 0 ? (
                        expenses
                          .filter((expense) => {
                            if (!dateRange?.from || !dateRange?.to || !expense.date) return false
                            try {
                              const expenseDate = parseISO(expense.date)
                              return expenseDate >= dateRange.from && expenseDate <= addDays(dateRange.to, 1)
                            } catch (error) {
                              console.error("Error parsing expense date:", expense.date, error)
                              return false
                            }
                          })
                          .map((expense) => (
                            <TableRow key={expense.id}>
                              <TableCell>
                                {expense.date ? formatDateFn(parseISO(expense.date), "dd/MM/yy") : "N/A"}
                              </TableCell>
                              <TableCell>{expense.category}</TableCell>
                              <TableCell>{expense.description}</TableCell>
                              <TableCell>{expense.payment_method}</TableCell>
                              <TableCell className="text-right">{formatCurrency(expense.amount)}</TableCell>
                            </TableRow>
                          ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center py-4">
                            Ma'lumot mavjud emas
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </TooltipProvider>
  )
}
