import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function PosPagePlaceholder() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Sotuv Nuqtasi</h1>
      <Card>
        <CardHeader>
          <CardTitle>Sotuv Amaliyoti</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            Bu yerda avvalgi yaratganimiz kabi sotuv interfeysi bo'ladi. Mahsulotlarni tanlab, savatga qo'shib, to'lovni
            amalga oshirish mumkin bo'ladi.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
