"use client"

import { useState, useEffect, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DollarSign, Clock, TrendingUp, Play, Square, FileText, TrendingDown, AlertTriangle } from "lucide-react"
import type { CashRegister } from "@/lib/types"
import { toast } from "sonner"

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat("uz-UZ", { style: "currency", currency: "UZS", minimumFractionDigits: 0 }).format(amount)
}

// Helper function to load data from localStorage
const loadFromLocalStorage = <T,>(key: string, defaultValue: T): T => {
  if (typeof window === "undefined") return defaultValue
  try {
    const item = window.localStorage.getItem(key)
    return item ? JSON.parse(item) : defaultValue
  } catch (error) {
    console.error(`Error loading ${key} from localStorage:`, error)
    return defaultValue
  }
}

const initialCashRegisters: CashRegister[] = [
  {
    id: "1",
    employee_id: "emp1",
    opening_balance: 500000,
    closing_balance: 1250000,
    total_sales: 2500000,
    total_cash: 1500000,
    total_card: 1000000,
    status: "closed",
    opened_at: "2024-01-15T08:00:00Z",
    closed_at: "2024-01-15T20:00:00Z",
  },
  {
    id: "2",
    employee_id: "emp2",
    opening_balance: 600000,
    total_sales: 1800000,
    total_cash: 1200000,
    total_card: 600000,
    status: "open",
    opened_at: "2024-01-16T08:30:00Z",
  },
]

export default function CashRegisterPage() {
  const [cashRegisters, setCashRegisters] = useState<CashRegister[]>([])
  const [sales, setSales] = useState<any[]>([])
  const [expenses, setExpenses] = useState<any[]>([])
  const [isOpenDialogOpen, setIsOpenDialogOpen] = useState(false)
  const [isCloseDialogOpen, setIsCloseDialogOpen] = useState(false)
  const [openingBalance, setOpeningBalance] = useState("")
  const [closingBalance, setClosingBalance] = useState("")
  const [openingBalanceError, setOpeningBalanceError] = useState("")
  const [closingBalanceError, setClosingBalanceError] = useState("")
  const [isLoading, setIsLoading] = useState(true)

  // Ma'lumotlarni yuklash
  useEffect(() => {
    try {
      const savedRegisters = localStorage.getItem("cash_registers")
      const salesData = loadFromLocalStorage("sales", [])
      const expensesData = loadFromLocalStorage("expenses", [])

      if (savedRegisters) {
        setCashRegisters(JSON.parse(savedRegisters))
      } else {
        setCashRegisters(initialCashRegisters)
        localStorage.setItem("cash_registers", JSON.stringify(initialCashRegisters))
      }

      setSales(salesData)
      setExpenses(expensesData)
    } catch (error) {
      console.error("Kassa ma'lumotlarini yuklashda xatolik:", error)
      setCashRegisters(initialCashRegisters)
    } finally {
      setIsLoading(false)
    }
  }, [])

  // Ma'lumotlarni saqlash
  const saveCashRegisters = (registers: CashRegister[]) => {
    try {
      localStorage.setItem("cash_registers", JSON.stringify(registers))
      setCashRegisters(registers)
    } catch (error) {
      console.error("Kassa ma'lumotlarini saqlashda xatolik:", error)
      toast.error("Ma'lumotlarni saqlashda xatolik yuz berdi")
    }
  }

  const currentRegister = cashRegisters.find((r) => r.status === "open")

  // Sotuvlar va harajatlar statistikasi
  const salesAndExpensesStats = useMemo(() => {
    const today = new Date().toDateString()

    // Bugungi sotuvlar
    const todaySales = sales.filter((sale) => new Date(sale.created_at).toDateString() === today)
    const todayCashSales = todaySales
      .filter((sale) => sale.payment_method === "cash" || sale.payment_methods?.some((pm: any) => pm.type === "cash"))
      .reduce((sum, sale) => {
        if (sale.payment_methods) {
          // Aralash to'lov
          return (
            sum +
            sale.payment_methods
              .filter((pm: any) => pm.type === "cash")
              .reduce((cashSum: number, pm: any) => cashSum + pm.amount, 0)
          )
        }
        // Oddiy naqd to'lov
        return sum + (sale.payment_method === "cash" ? sale.total_amount : 0)
      }, 0)

    const todayCardSales = todaySales
      .filter((sale) => sale.payment_method === "card" || sale.payment_methods?.some((pm: any) => pm.type === "card"))
      .reduce((sum, sale) => {
        if (sale.payment_methods) {
          // Aralash to'lov
          return (
            sum +
            sale.payment_methods
              .filter((pm: any) => pm.type === "card")
              .reduce((cardSum: number, pm: any) => cardSum + pm.amount, 0)
          )
        }
        // Oddiy karta to'lov
        return sum + (sale.payment_method === "card" ? sale.total_amount : 0)
      }, 0)

    const totalTodaySales = todaySales.reduce((sum, sale) => sum + sale.total_amount, 0)

    // Bugungi harajatlar
    const todayExpenses = expenses.filter((expense) => {
      const expenseDate = new Date(expense.created_at).toDateString()
      return expenseDate === today && expense.status === "approved"
    })

    const todayCashExpenses = todayExpenses
      .filter((expense) => expense.payment_method === "cash")
      .reduce((sum, expense) => sum + expense.amount, 0)

    const totalTodayExpenses = todayExpenses.reduce((sum, expense) => sum + expense.amount, 0)

    // Jami statistikalar
    const totalCashSales = sales
      .filter((sale) => sale.payment_method === "cash" || sale.payment_methods?.some((pm: any) => pm.type === "cash"))
      .reduce((sum, sale) => {
        if (sale.payment_methods) {
          return (
            sum +
            sale.payment_methods
              .filter((pm: any) => pm.type === "cash")
              .reduce((cashSum: number, pm: any) => cashSum + pm.amount, 0)
          )
        }
        return sum + (sale.payment_method === "cash" ? sale.total_amount : 0)
      }, 0)

    const totalCashExpenses = expenses
      .filter((expense) => expense.payment_method === "cash" && expense.status === "approved")
      .reduce((sum, expense) => sum + expense.amount, 0)

    return {
      todayCashSales,
      todayCardSales,
      totalTodaySales,
      todayCashExpenses,
      totalTodayExpenses,
      totalCashSales,
      totalCashExpenses,
    }
  }, [sales, expenses])

  // Kassadagi haqiqiy pul miqdori
  const cashBalanceStats = useMemo(() => {
    if (!currentRegister) {
      return {
        currentCashBalance: 0,
        cashAfterExpenses: 0,
        netCashFlow: 0,
      }
    }

    const currentCashBalance = currentRegister.opening_balance + salesAndExpensesStats.todayCashSales
    const cashAfterExpenses = currentCashBalance - salesAndExpensesStats.todayCashExpenses
    const netCashFlow = salesAndExpensesStats.todayCashSales - salesAndExpensesStats.todayCashExpenses

    return {
      currentCashBalance,
      cashAfterExpenses,
      netCashFlow,
    }
  }, [currentRegister, salesAndExpensesStats])

  const resetOpenForm = () => {
    setOpeningBalance("")
    setOpeningBalanceError("")
  }

  const resetCloseForm = () => {
    setClosingBalance("")
    setClosingBalanceError("")
  }

  const openCashRegisterDialog = () => {
    if (currentRegister) {
      toast.error("Kassa allaqachon ochiq!")
      return
    }
    resetOpenForm()
    setIsOpenDialogOpen(true)
  }

  const openCloseCashRegisterDialog = () => {
    if (!currentRegister) {
      toast.error("Yopiladigan kassa topilmadi!")
      return
    }
    resetCloseForm()
    // Kutilayotgan balansni avtomatik to'ldirish
    const expectedBalance = cashBalanceStats.cashAfterExpenses
    setClosingBalance(String(expectedBalance))
    setIsCloseDialogOpen(true)
  }

  const handleOpenRegister = () => {
    // Validatsiya
    const balance = Number.parseFloat(openingBalance)
    if (!openingBalance || isNaN(balance) || balance <= 0) {
      setOpeningBalanceError("Boshlang'ich balans 0 dan katta bo'lishi kerak")
      return
    }

    const newRegister: CashRegister = {
      id: Date.now().toString(),
      employee_id: "current_user",
      opening_balance: balance,
      total_sales: 0,
      total_cash: 0,
      total_card: 0,
      status: "open",
      opened_at: new Date().toISOString(),
    }

    const updatedRegisters = [newRegister, ...cashRegisters]
    saveCashRegisters(updatedRegisters)
    resetOpenForm()
    setIsOpenDialogOpen(false)
    toast.success("Kassa muvaffaqiyatli ochildi")
  }

  const handleCloseRegister = () => {
    if (!currentRegister) {
      toast.error("Yopiladigan kassa topilmadi!")
      return
    }

    // Validatsiya
    const balance = Number.parseFloat(closingBalance)
    if (!closingBalance || isNaN(balance) || balance < 0) {
      setClosingBalanceError("Yakuniy balans 0 dan kichik bo'lmasligi kerak")
      return
    }

    const updatedRegister: CashRegister = {
      ...currentRegister,
      closing_balance: balance,
      total_sales: salesAndExpensesStats.totalTodaySales,
      total_cash: salesAndExpensesStats.todayCashSales,
      total_card: salesAndExpensesStats.todayCardSales,
      status: "closed",
      closed_at: new Date().toISOString(),
    }

    const updatedRegisters = cashRegisters.map((r) => (r.id === currentRegister.id ? updatedRegister : r))

    saveCashRegisters(updatedRegisters)
    resetCloseForm()
    setIsCloseDialogOpen(false)

    const expectedBalance = cashBalanceStats.cashAfterExpenses
    const difference = balance - expectedBalance
    if (Math.abs(difference) < 100) {
      toast.success("Kassa muvaffaqiyatli yopildi. Balans to'g'ri!")
    } else {
      toast.success(`Kassa yopildi. Farq: ${formatCurrency(difference)}`)
    }
  }

  const generateZReport = () => {
    if (!currentRegister) {
      toast.error("Ochiq kassa topilmadi!")
      return
    }

    const reportData = {
      date: new Date().toLocaleDateString("uz-UZ"),
      time: new Date().toLocaleTimeString("uz-UZ"),
      opening_balance: currentRegister.opening_balance,
      cash_sales: salesAndExpensesStats.todayCashSales,
      card_sales: salesAndExpensesStats.todayCardSales,
      total_sales: salesAndExpensesStats.totalTodaySales,
      cash_expenses: salesAndExpensesStats.todayCashExpenses,
      total_expenses: salesAndExpensesStats.totalTodayExpenses,
      current_cash_balance: cashBalanceStats.currentCashBalance,
      cash_after_expenses: cashBalanceStats.cashAfterExpenses,
      net_cash_flow: cashBalanceStats.netCashFlow,
    }

    const reportText = `Z-HISOBOT

Sana: ${reportData.date}
Vaqt: ${reportData.time}

KASSA MA'LUMOTLARI:
Boshlang'ich balans: ${formatCurrency(reportData.opening_balance)}

SOTUVLAR:
Naqd sotuvlar: ${formatCurrency(reportData.cash_sales)}
Karta sotuvlar: ${formatCurrency(reportData.card_sales)}
Jami sotuvlar: ${formatCurrency(reportData.total_sales)}

HARAJATLAR:
Naqd harajatlar: ${formatCurrency(reportData.cash_expenses)}
Jami harajatlar: ${formatCurrency(reportData.total_expenses)}

KASSA BALANSI:
Joriy naqd balans: ${formatCurrency(reportData.current_cash_balance)}
Harajatlardan keyin: ${formatCurrency(reportData.cash_after_expenses)}
Sof naqd oqim: ${formatCurrency(reportData.net_cash_flow)}`

    // Hisobotni yangi oynada ko'rsatish
    const newWindow = window.open("", "_blank")
    if (newWindow) {
      newWindow.document.write(`<pre>${reportText}</pre>`)
      newWindow.document.title = "Z-Hisobot"
    } else {
      alert(reportText)
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-lg">Yuklanmoqda...</div>
      </div>
    )
  }

  const todayRegisters = cashRegisters.filter((r) => {
    const today = new Date().toDateString()
    const registerDate = new Date(r.opened_at).toDateString()
    return today === registerDate
  })

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Kassa Boshqaruvi</h1>
        <div className="flex gap-2">
          {!currentRegister ? (
            <Button className="bg-green-600 hover:bg-green-700" onClick={openCashRegisterDialog}>
              <Play className="mr-2 h-4 w-4" />
              Kassani Ochish
            </Button>
          ) : (
            <>
              <Button onClick={generateZReport} variant="outline">
                <FileText className="mr-2 h-4 w-4" />
                Z-Hisobot
              </Button>
              <Button variant="destructive" onClick={openCloseCashRegisterDialog}>
                <Square className="mr-2 h-4 w-4" />
                Kassani Yopish
              </Button>
            </>
          )}
        </div>
      </div>

      {/* Asosiy statistika kartalari */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Bugungi Naqd Sotuvlar</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {formatCurrency(salesAndExpensesStats.todayCashSales)}
            </div>
            <p className="text-xs text-muted-foreground">Kassaga tushgan pul</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Bugungi Harajatlar</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {formatCurrency(salesAndExpensesStats.todayCashExpenses)}
            </div>
            <p className="text-xs text-muted-foreground">Kassadan chiqgan pul</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Kassadagi Pul</CardTitle>
            <DollarSign className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {formatCurrency(cashBalanceStats.currentCashBalance)}
            </div>
            <p className="text-xs text-muted-foreground">Harajatlarsiz</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Sof Kassa Balansi</CardTitle>
            <AlertTriangle className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">
              {formatCurrency(cashBalanceStats.cashAfterExpenses)}
            </div>
            <p className="text-xs text-muted-foreground">Harajatlardan keyin</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Kassa Holati</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {currentRegister ? (
                <Badge className="bg-green-100 text-green-800">Ochiq</Badge>
              ) : (
                <Badge variant="secondary">Yopiq</Badge>
              )}
            </div>
            <p className="text-xs text-muted-foreground">{currentRegister ? "Ishlamoqda" : "Ishlamayapti"}</p>
          </CardContent>
        </Card>
      </div>

      {/* Kassa oqimi tahlili */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Bugungi Kassa Oqimi</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-green-800">Naqd Sotuvlar</p>
                  <p className="text-xs text-green-600">Kassaga kirgan pul</p>
                </div>
                <p className="text-lg font-bold text-green-600">
                  +{formatCurrency(salesAndExpensesStats.todayCashSales)}
                </p>
              </div>

              <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-red-800">Naqd Harajatlar</p>
                  <p className="text-xs text-red-600">Kassadan chiqgan pul</p>
                </div>
                <p className="text-lg font-bold text-red-600">
                  -{formatCurrency(salesAndExpensesStats.todayCashExpenses)}
                </p>
              </div>

              <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg border-2 border-blue-200">
                <div>
                  <p className="text-sm font-medium text-blue-800">Sof Oqim</p>
                  <p className="text-xs text-blue-600">Bugungi natija</p>
                </div>
                <p
                  className={`text-lg font-bold ${cashBalanceStats.netCashFlow >= 0 ? "text-green-600" : "text-red-600"}`}
                >
                  {cashBalanceStats.netCashFlow >= 0 ? "+" : ""}
                  {formatCurrency(cashBalanceStats.netCashFlow)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Kassa Balans Tahlili</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {currentRegister && (
                <>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Boshlang'ich balans:</span>
                    <span className="font-medium">{formatCurrency(currentRegister.opening_balance)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Bugungi naqd sotuvlar:</span>
                    <span className="font-medium text-green-600">
                      +{formatCurrency(salesAndExpensesStats.todayCashSales)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Bugungi naqd harajatlar:</span>
                    <span className="font-medium text-red-600">
                      -{formatCurrency(salesAndExpensesStats.todayCashExpenses)}
                    </span>
                  </div>
                  <hr />
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Harajatlarsiz balans:</span>
                    <span className="font-bold text-blue-600">
                      {formatCurrency(cashBalanceStats.currentCashBalance)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Harajatlardan keyin:</span>
                    <span className="font-bold text-purple-600">
                      {formatCurrency(cashBalanceStats.cashAfterExpenses)}
                    </span>
                  </div>
                </>
              )}
              {!currentRegister && <p className="text-center text-muted-foreground py-8">Kassa ochilmagan</p>}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Joriy kassa ma'lumotlari */}
      {currentRegister && (
        <Card>
          <CardHeader>
            <CardTitle>Joriy Kassa Sessiyasi</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-4">
              <div>
                <p className="text-sm text-muted-foreground">Ochilgan vaqt</p>
                <p className="text-lg font-medium">{new Date(currentRegister.opened_at).toLocaleString("uz-UZ")}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Boshlang'ich balans</p>
                <p className="text-lg font-medium">{formatCurrency(currentRegister.opening_balance)}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Bugungi sotuvlar</p>
                <p className="text-lg font-medium text-green-600">
                  {formatCurrency(salesAndExpensesStats.totalTodaySales)}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Bugungi harajatlar</p>
                <p className="text-lg font-medium text-red-600">
                  {formatCurrency(salesAndExpensesStats.totalTodayExpenses)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="today" className="space-y-4">
        <TabsList>
          <TabsTrigger value="today">Bugungi Sessiyalar</TabsTrigger>
          <TabsTrigger value="history">Tarix</TabsTrigger>
        </TabsList>

        <TabsContent value="today" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Bugungi Kassa Sessiyalari</CardTitle>
            </CardHeader>
            <CardContent>
              {todayRegisters.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">Bugun kassa sessiyalari mavjud emas</div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Ochilgan</TableHead>
                      <TableHead>Yopilgan</TableHead>
                      <TableHead>Boshlang'ich</TableHead>
                      <TableHead>Sotuvlar</TableHead>
                      <TableHead>Naqd</TableHead>
                      <TableHead>Karta</TableHead>
                      <TableHead>Holat</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {todayRegisters.map((register) => (
                      <TableRow key={register.id}>
                        <TableCell>{new Date(register.opened_at).toLocaleTimeString("uz-UZ")}</TableCell>
                        <TableCell>
                          {register.closed_at ? new Date(register.closed_at).toLocaleTimeString("uz-UZ") : "-"}
                        </TableCell>
                        <TableCell>{formatCurrency(register.opening_balance)}</TableCell>
                        <TableCell>{formatCurrency(register.total_sales)}</TableCell>
                        <TableCell>{formatCurrency(register.total_cash)}</TableCell>
                        <TableCell>{formatCurrency(register.total_card)}</TableCell>
                        <TableCell>
                          {register.status === "open" ? (
                            <Badge className="bg-green-100 text-green-800">Ochiq</Badge>
                          ) : (
                            <Badge variant="secondary">Yopiq</Badge>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Kassa Tarixi</CardTitle>
            </CardHeader>
            <CardContent>
              {cashRegisters.filter((r) => r.status === "closed").length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">Yopilgan kassa sessiyalari mavjud emas</div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Sana</TableHead>
                      <TableHead>Vaqt</TableHead>
                      <TableHead>Sotuvlar</TableHead>
                      <TableHead>Naqd</TableHead>
                      <TableHead>Karta</TableHead>
                      <TableHead>Farq</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {cashRegisters
                      .filter((r) => r.status === "closed")
                      .map((register) => (
                        <TableRow key={register.id}>
                          <TableCell>{new Date(register.opened_at).toLocaleDateString("uz-UZ")}</TableCell>
                          <TableCell>
                            {new Date(register.opened_at).toLocaleTimeString("uz-UZ")} -{" "}
                            {register.closed_at && new Date(register.closed_at).toLocaleTimeString("uz-UZ")}
                          </TableCell>
                          <TableCell>{formatCurrency(register.total_sales)}</TableCell>
                          <TableCell>{formatCurrency(register.total_cash)}</TableCell>
                          <TableCell>{formatCurrency(register.total_card)}</TableCell>
                          <TableCell>
                            {register.closing_balance !== undefined ? (
                              <span
                                className={
                                  register.closing_balance === register.opening_balance + register.total_cash
                                    ? "text-green-600"
                                    : "text-red-600"
                                }
                              >
                                {formatCurrency(
                                  register.closing_balance - (register.opening_balance + register.total_cash),
                                )}
                              </span>
                            ) : (
                              "-"
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Kassani ochish dialog */}
      <Dialog open={isOpenDialogOpen} onOpenChange={setIsOpenDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Kassani Ochish</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="opening_balance">Boshlang'ich pul miqdori *</Label>
              <Input
                id="opening_balance"
                type="number"
                value={openingBalance}
                onChange={(e) => {
                  setOpeningBalance(e.target.value)
                  setOpeningBalanceError("")
                }}
                placeholder="500000"
                className={openingBalanceError ? "border-red-500" : ""}
              />
              {openingBalanceError && <p className="text-sm text-red-500 mt-1">{openingBalanceError}</p>}
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setIsOpenDialogOpen(false)} className="flex-1">
                Bekor qilish
              </Button>
              <Button onClick={handleOpenRegister} className="flex-1 bg-green-600 hover:bg-green-700">
                Kassani Ochish
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Kassani yopish dialog */}
      <Dialog open={isCloseDialogOpen} onOpenChange={setIsCloseDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Kassani Yopish</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-muted p-4 rounded-lg">
              <h3 className="font-medium mb-2">Joriy Kassa Ma'lumotlari:</h3>
              <p>Boshlang'ich: {currentRegister ? formatCurrency(currentRegister.opening_balance) : "-"}</p>
              <p>Bugungi naqd sotuvlar: {formatCurrency(salesAndExpensesStats.todayCashSales)}</p>
              <p>Bugungi naqd harajatlar: {formatCurrency(salesAndExpensesStats.todayCashExpenses)}</p>
              <p>Jami sotuvlar: {formatCurrency(salesAndExpensesStats.totalTodaySales)}</p>
              <p className="font-medium text-blue-600">
                Harajatlarsiz balans: {formatCurrency(cashBalanceStats.currentCashBalance)}
              </p>
              <p className="font-medium text-purple-600">
                Kutilayotgan balans (harajatlardan keyin): {formatCurrency(cashBalanceStats.cashAfterExpenses)}
              </p>
            </div>
            <div>
              <Label htmlFor="closing_balance">Haqiqiy pul miqdori *</Label>
              <Input
                id="closing_balance"
                type="number"
                value={closingBalance}
                onChange={(e) => {
                  setClosingBalance(e.target.value)
                  setClosingBalanceError("")
                }}
                placeholder={String(cashBalanceStats.cashAfterExpenses)}
                className={closingBalanceError ? "border-red-500" : ""}
              />
              {closingBalanceError && <p className="text-sm text-red-500 mt-1">{closingBalanceError}</p>}
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setIsCloseDialogOpen(false)} className="flex-1">
                Bekor qilish
              </Button>
              <Button onClick={handleCloseRegister} variant="destructive" className="flex-1">
                Kassani Yopish
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
