"use client"

import type React from "react"

import { useState, useMemo, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, AlertTriangle } from "lucide-react"
import type { Product, StockBatch, Supplier } from "@/lib/types"
import { differenceInDays, format, addDays } from "date-fns"

// Load products and suppliers from localStorage
const loadProducts = (): Product[] => {
  if (typeof window === "undefined") return []
  try {
    const saved = window.localStorage.getItem("products_list")
    return saved ? JSON.parse(saved) : []
  } catch (error) {
    console.error("Error loading products:", error)
    return []
  }
}

const loadSuppliers = (): Supplier[] => {
  if (typeof window === "undefined") return []
  try {
    const saved = window.localStorage.getItem("suppliers")
    return saved ? JSON.parse(saved) : []
  } catch (error) {
    console.error("Error loading suppliers:", error)
    return []
  }
}

const loadBatches = (): StockBatch[] => {
  if (typeof window === "undefined") return []
  try {
    const saved = window.localStorage.getItem("stock_batches")
    return saved ? JSON.parse(saved) : []
  } catch (error) {
    console.error("Error loading batches:", error)
    return []
  }
}

const loadReservedOrders = (): any[] => {
  if (typeof window === "undefined") return []
  try {
    const saved = window.localStorage.getItem("reserved_orders")
    return saved ? JSON.parse(saved) : []
  } catch (error) {
    console.error("Error loading reserved orders:", error)
    return []
  }
}

// Helper function to calculate reserved quantities
const calculateReservedQuantities = (reservedOrders: any[]) => {
  const reservedQuantities = new Map<string, number>()

  reservedOrders
    .filter((order) => order.status === "pending" || order.status === "ready")
    .forEach((order) => {
      order.products?.forEach((product: any) => {
        const currentReserved = reservedQuantities.get(product.id) || 0
        reservedQuantities.set(product.id, currentReserved + product.quantity)
      })
    })

  return reservedQuantities
}

export default function WarehousePage() {
  const [products, setProducts] = useState<Product[]>([])
  const [suppliers, setSuppliers] = useState<Supplier[]>([])
  const [reservedOrders, setReservedOrders] = useState<any[]>([])

  useEffect(() => {
    setProducts(loadProducts())
    setSuppliers(loadSuppliers())
    setReservedOrders(loadReservedOrders())
  }, [])

  const [batches, setBatches] = useState<StockBatch[]>(loadBatches)
  const [isReceiveBatchOpen, setIsReceiveBatchOpen] = useState(false)
  const [batchForm, setBatchForm] = useState({
    product_id: "",
    supplier_id: "",
    quantity: "",
    cost_price: "",
    expiration_date: "",
  })
  const [manualExpirationDate, setManualExpirationDate] = useState(false)

  useEffect(() => {
    if (typeof window !== "undefined") {
      try {
        window.localStorage.setItem("stock_batches", JSON.stringify(batches))
      } catch (error) {
        console.error("Error saving batches:", error)
      }
    }
  }, [batches])

  useEffect(() => {
    if (batchForm.product_id && !manualExpirationDate) {
      const selectedProduct = products.find((p) => p.id === batchForm.product_id)
      if (selectedProduct && selectedProduct.shelf_life_days) {
        const today = new Date()
        const expiration = addDays(today, selectedProduct.shelf_life_days)
        setBatchForm((prev) => ({ ...prev, expiration_date: format(expiration, "yyyy-MM-dd") }))
      } else {
        // If product has no shelf life, clear the auto-filled date
        setBatchForm((prev) => ({ ...prev, expiration_date: "" }))
      }
    }
  }, [batchForm.product_id, products, manualExpirationDate])

  const handleExpirationDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setBatchForm({ ...batchForm, expiration_date: e.target.value })
    setManualExpirationDate(true) // User manually changed the date
  }

  const openReceiveBatchDialog = () => {
    setManualExpirationDate(false) // Reset manual flag when dialog opens
    setBatchForm({ product_id: "", supplier_id: "", quantity: "", cost_price: "", expiration_date: "" })
    setIsReceiveBatchOpen(true)
  }

  const productStocks = useMemo(() => {
    const stockMap = new Map<
      string,
      { product: Product; total_quantity: number; reserved_quantity: number; available_quantity: number }
    >()
    const reservedQuantities = calculateReservedQuantities(reservedOrders)

    products.forEach((p) => {
      const reservedQty = reservedQuantities.get(p.id) || 0
      stockMap.set(p.id, {
        product: p,
        total_quantity: 0,
        reserved_quantity: reservedQty,
        available_quantity: 0,
      })
    })

    batches.forEach((batch) => {
      if (stockMap.has(batch.product_id)) {
        const entry = stockMap.get(batch.product_id)!
        entry.total_quantity += batch.quantity
        entry.available_quantity = Math.max(0, entry.total_quantity - entry.reserved_quantity)
      }
    })

    return Array.from(stockMap.values())
  }, [products, batches, reservedOrders])

  const handleReceiveBatch = () => {
    const newBatch: StockBatch = {
      id: `b${Date.now()}`,
      product_id: batchForm.product_id,
      supplier_id: batchForm.supplier_id,
      quantity: Number.parseInt(batchForm.quantity),
      cost_price: Number.parseFloat(batchForm.cost_price),
      received_at: new Date().toISOString(),
      expiration_date: batchForm.expiration_date ? new Date(batchForm.expiration_date).toISOString() : undefined,
    }

    setBatches([newBatch, ...batches])
    setBatchForm({ product_id: "", supplier_id: "", quantity: "", cost_price: "", expiration_date: "" })
    setManualExpirationDate(false)
    setIsReceiveBatchOpen(false)
  }

  const getProductName = (productId: string) => {
    return products.find((p) => p.id === productId)?.name || "Noma'lum mahsulot"
  }

  const getSupplierName = (supplierId: string) => {
    return suppliers.find((s) => s.id === supplierId)?.name || "Noma'lum ta'minotchi"
  }

  const expiringProducts = useMemo(() => {
    const today = new Date()
    return batches
      .filter((batch) => batch.expiration_date && batch.quantity > 0)
      .map((batch) => {
        const expirationDate = new Date(batch.expiration_date!)
        const daysLeft = differenceInDays(expirationDate, today)
        return { ...batch, daysLeft }
      })
      .filter((batch) => batch.daysLeft <= 30)
      .sort((a, b) => a.daysLeft - b.daysLeft)
  }, [batches])

  const getExpirationStatus = (daysLeft: number) => {
    if (daysLeft < 0) {
      return <Badge variant="destructive">Muddati o'tgan</Badge>
    } else if (daysLeft <= 7) {
      return <Badge className="bg-red-100 text-red-800">Juda oz qoldi</Badge>
    } else if (daysLeft <= 30) {
      return <Badge className="bg-yellow-100 text-yellow-800">Yaqinlashmoqda</Badge>
    }
    return null
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Ombor Boshqaruvi</h1>
        <Dialog open={isReceiveBatchOpen} onOpenChange={setIsReceiveBatchOpen}>
          <DialogTrigger asChild>
            <Button onClick={openReceiveBatchDialog}>
              <Plus className="mr-2 h-4 w-4" />
              Partiya Qabul Qilish
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Yangi Partiya Qabul Qilish</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="product">Mahsulot *</Label>
                <Select
                  value={batchForm.product_id}
                  onValueChange={(value) => {
                    setBatchForm({ ...batchForm, product_id: value })
                    setManualExpirationDate(false) // Reset manual flag on product change
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Mahsulotni tanlang" />
                  </SelectTrigger>
                  <SelectContent>
                    {products.map((product) => (
                      <SelectItem key={product.id} value={product.id}>
                        {product.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="supplier">Ta'minotchi *</Label>
                <Select
                  value={batchForm.supplier_id}
                  onValueChange={(value) => setBatchForm({ ...batchForm, supplier_id: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Ta'minotchini tanlang" />
                  </SelectTrigger>
                  <SelectContent>
                    {suppliers.map((supplier) => (
                      <SelectItem key={supplier.id} value={supplier.id}>
                        {supplier.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="quantity">Miqdor *</Label>
                  <Input
                    id="quantity"
                    type="number"
                    value={batchForm.quantity}
                    onChange={(e) => setBatchForm({ ...batchForm, quantity: e.target.value })}
                    placeholder="0"
                  />
                </div>
                <div>
                  <Label htmlFor="cost_price">Tannarx (1 dona uchun) *</Label>
                  <Input
                    id="cost_price"
                    type="number"
                    value={batchForm.cost_price}
                    onChange={(e) => setBatchForm({ ...batchForm, cost_price: e.target.value })}
                    placeholder="0"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="expiration_date">Yaroqlilik muddati (Tugash sanasi)</Label>
                <Input
                  id="expiration_date"
                  type="date"
                  value={batchForm.expiration_date}
                  onChange={handleExpirationDateChange}
                />
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setIsReceiveBatchOpen(false)} className="flex-1">
                  Bekor qilish
                </Button>
                <Button onClick={handleReceiveBatch} className="flex-1">
                  Saqlash
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="stock" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="stock">Qoldiqlar</TabsTrigger>
          <TabsTrigger value="batches">Partiyalar</TabsTrigger>
          <TabsTrigger value="expiring">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4" />
              Muddati o'tganlar
              {expiringProducts.length > 0 && (
                <Badge variant="destructive" className="ml-2">
                  {expiringProducts.length}
                </Badge>
              )}
            </div>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="stock" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Mahsulotlar Qoldig'i</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Mahsulot</TableHead>
                    <TableHead>Jami Qoldiq</TableHead>
                    <TableHead>Band Qilingan</TableHead>
                    <TableHead>Mavjud</TableHead>
                    <TableHead>Minimal Daraja</TableHead>
                    <TableHead>Holat</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {productStocks.map(({ product, total_quantity, reserved_quantity, available_quantity }) => (
                    <TableRow key={product.id}>
                      <TableCell className="font-medium">{product.name}</TableCell>
                      <TableCell>{total_quantity}</TableCell>
                      <TableCell>
                        {reserved_quantity > 0 ? (
                          <Badge variant="secondary">{reserved_quantity}</Badge>
                        ) : (
                          <span className="text-muted-foreground">0</span>
                        )}
                      </TableCell>
                      <TableCell className="font-medium">{available_quantity}</TableCell>
                      <TableCell>{product.min_stock_level}</TableCell>
                      <TableCell>
                        {available_quantity === 0 ? (
                          <Badge variant="destructive">Tugagan</Badge>
                        ) : available_quantity <= product.min_stock_level ? (
                          <Badge className="bg-yellow-100 text-yellow-800">Kam</Badge>
                        ) : (
                          <Badge className="bg-green-100 text-green-800">Yetarli</Badge>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="batches" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Mahsulot Partiyalari</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Mahsulot</TableHead>
                    <TableHead>Ta'minotchi</TableHead>
                    <TableHead>Miqdor</TableHead>
                    <TableHead>Tannarx</TableHead>
                    <TableHead>Qabul qilingan</TableHead>
                    <TableHead>Tugash sanasi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {batches.map((batch) => (
                    <TableRow key={batch.id}>
                      <TableCell className="font-medium">{getProductName(batch.product_id)}</TableCell>
                      <TableCell>{getSupplierName(batch.supplier_id)}</TableCell>
                      <TableCell>{batch.quantity}</TableCell>
                      <TableCell>{batch.cost_price}</TableCell>
                      <TableCell>{format(new Date(batch.received_at), "dd.MM.yyyy")}</TableCell>
                      <TableCell>
                        {batch.expiration_date ? format(new Date(batch.expiration_date), "dd.MM.yyyy") : "-"}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="expiring" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Yaroqlilik Muddati Tugayotgan Mahsulotlar</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Mahsulot</TableHead>
                    <TableHead>Partiya Miqdori</TableHead>
                    <TableHead>Tugash Sanasi</TableHead>
                    <TableHead>Qolgan Kun</TableHead>
                    <TableHead>Holat</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {expiringProducts.length > 0 ? (
                    expiringProducts.map((batch) => (
                      <TableRow key={batch.id} className={batch.daysLeft < 0 ? "bg-red-50" : ""}>
                        <TableCell className="font-medium">{getProductName(batch.product_id)}</TableCell>
                        <TableCell>{batch.quantity}</TableCell>
                        <TableCell>{format(new Date(batch.expiration_date!), "dd.MM.yyyy")}</TableCell>
                        <TableCell className="font-medium">
                          {batch.daysLeft < 0 ? `${Math.abs(batch.daysLeft)} kun o'tdi` : `${batch.daysLeft} kun`}
                        </TableCell>
                        <TableCell>{getExpirationStatus(batch.daysLeft)}</TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center h-24">
                        Yaroqlilik muddati yaqin mahsulotlar yo'q.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
