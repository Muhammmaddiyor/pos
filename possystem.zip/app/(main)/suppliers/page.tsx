"use client"

import { useState, useMemo, useEffect } from "react"
import { PlusCircle, Edit, DollarSignIcon } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import type { Supplier, SupplierTransaction } from "@/lib/types" // Ensure SupplierTransaction is imported if used directly here

// Load data from localStorage or use empty arrays if not available
const loadFromLocalStorage = <T,>(key: string, defaultValue: T): T => {
  if (typeof window === "undefined") return defaultValue
  try {
    const item = window.localStorage.getItem(key)
    return item ? JSON.parse(item) : defaultValue
  } catch (error) {
    console.error(`Error loading ${key} from localStorage:`, error)
    return defaultValue
  }
}

// Save data to localStorage
const saveToLocalStorage = <T,>(key: string, value: T): void => {
  if (typeof window === "undefined") return
  try {
    window.localStorage.setItem(key, JSON.stringify(value))
  } catch (error) {
    console.error(`Error saving ${key} to localStorage:`, error)
  }
}

export default function SuppliersPage() {
  const [suppliers, setSuppliers] = useState<Supplier[]>(() => loadFromLocalStorage<Supplier[]>("suppliers", []))

  const [transactions, setTransactions] = useState<SupplierTransaction[]>(() =>
    loadFromLocalStorage<SupplierTransaction[]>("supplierTransactions", []),
  )

  const [searchTerm, setSearchTerm] = useState("")
  const [isAddSupplierDialogOpen, setIsAddSupplierDialogOpen] = useState(false)
  const [isEditSupplierDialogOpen, setIsEditSupplierDialogOpen] = useState(false)
  const [isTransactionDialogOpen, setIsTransactionDialogOpen] = useState(false)
  const [selectedSupplier, setSelectedSupplier] = useState<Supplier | null>(null)
  const [currentSupplier, setCurrentSupplier] = useState<Partial<Supplier>>({})

  const [transactionForm, setTransactionForm] = useState<Partial<SupplierTransaction>>({
    type: "payment_made",
    transaction_date: new Date().toISOString().split("T")[0],
  })

  // Save suppliers to localStorage whenever they change
  useEffect(() => {
    saveToLocalStorage("suppliers", suppliers)
  }, [suppliers])

  // Save transactions to localStorage whenever they change
  useEffect(() => {
    saveToLocalStorage("supplierTransactions", transactions)
  }, [transactions])

  const filteredSuppliers = useMemo(() => {
    return suppliers.filter(
      (supplier) =>
        supplier.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (supplier.contact_person && supplier.contact_person.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (supplier.phone && supplier.phone.includes(searchTerm)) ||
        (supplier.brand_represented && supplier.brand_represented.toLowerCase().includes(searchTerm.toLowerCase())),
    )
  }, [suppliers, searchTerm])

  const handleAddOrUpdateSupplier = () => {
    if (currentSupplier.id) {
      // Update
      setSuppliers(suppliers.map((s) => (s.id === currentSupplier.id ? ({ ...s, ...currentSupplier } as Supplier) : s)))
    } else {
      // Add
      const newSupplier: Supplier = {
        id: `sup${Date.now()}`,
        name: currentSupplier.name || "Noma'lum Ta'minotchi",
        our_debt_to_them: Number(currentSupplier.our_debt_to_them) || 0,
        their_debt_to_us: Number(currentSupplier.their_debt_to_us) || 0,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        ...currentSupplier,
      }
      setSuppliers([...suppliers, newSupplier])
    }
    setIsAddSupplierDialogOpen(false)
    setIsEditSupplierDialogOpen(false)
    setCurrentSupplier({})
  }

  const openAddSupplierDialog = () => {
    setCurrentSupplier({ our_debt_to_them: 0, their_debt_to_us: 0 }) // Reset form for new supplier
    setIsAddSupplierDialogOpen(true)
  }

  const openEditSupplierDialog = (supplier: Supplier) => {
    setCurrentSupplier(supplier)
    setIsEditSupplierDialogOpen(true)
  }

  const openTransactionDialog = (supplier: Supplier) => {
    setSelectedSupplier(supplier)
    setTransactionForm({
      supplier_id: supplier.id,
      type: "payment_made",
      amount: 0,
      transaction_date: new Date().toISOString().split("T")[0],
      description: "",
    })
    setIsTransactionDialogOpen(true)
  }

  const handleAddTransaction = () => {
    if (!selectedSupplier || !transactionForm.type || !transactionForm.amount) return

    const newTransaction: SupplierTransaction = {
      id: `txn${Date.now()}`,
      supplier_id: selectedSupplier.id,
      type: transactionForm.type,
      amount: Number(transactionForm.amount),
      description: transactionForm.description,
      transaction_date: new Date(transactionForm.transaction_date || Date.now()).toISOString(),
      created_at: new Date().toISOString(),
    }
    setTransactions([...transactions, newTransaction])

    // Update supplier's debt based on transaction
    setSuppliers((prevSuppliers) =>
      prevSuppliers.map((sup) => {
        if (sup.id === selectedSupplier.id) {
          let newOurDebt = sup.our_debt_to_them
          let newTheirDebt = sup.their_debt_to_us

          if (newTransaction.type === "goods_received") {
            newOurDebt += newTransaction.amount
          } else if (newTransaction.type === "payment_made") {
            newOurDebt -= newTransaction.amount
          } else if (newTransaction.type === "goods_returned") {
            // Assuming return reduces our debt or increases their debt if we already paid
            // This logic might need refinement based on specific accounting practices
            newOurDebt -= newTransaction.amount
          } else if (newTransaction.type === "payment_received") {
            newTheirDebt -= newTransaction.amount
          }
          // Add other transaction type effects if necessary
          return { ...sup, our_debt_to_them: newOurDebt, their_debt_to_us: newTheirDebt }
        }
        return sup
      }),
    )

    setIsTransactionDialogOpen(false)
    setSelectedSupplier(null)
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("uz-UZ", { style: "currency", currency: "UZS" }).format(amount)
  }

  return (
    <div className="flex flex-col gap-6 p-4 md:p-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Ta'minotchilar</CardTitle>
          <Button onClick={openAddSupplierDialog} size="sm">
            <PlusCircle className="mr-2 h-4 w-4" /> Yangi Ta'minotchi
          </Button>
        </CardHeader>
        <CardContent>
          <Input
            type="text"
            placeholder="Ta'minotchilarni qidirish..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="mb-4"
          />
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nomi</TableHead>
                  <TableHead>Telefon</TableHead>
                  <TableHead>Brend</TableHead>
                  <TableHead className="text-right">Bizning Qarzimiz</TableHead>
                  <TableHead className="text-right">Ularning Qarzi</TableHead>
                  <TableHead className="text-center">Amallar</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredSuppliers.length > 0 ? (
                  filteredSuppliers.map((supplier) => (
                    <TableRow key={supplier.id}>
                      <TableCell>
                        <div className="font-medium">{supplier.name}</div>
                        {supplier.contact_person && (
                          <div className="text-xs text-muted-foreground">{supplier.contact_person}</div>
                        )}
                      </TableCell>
                      <TableCell>{supplier.phone || "-"}</TableCell>
                      <TableCell>{supplier.brand_represented || "-"}</TableCell>
                      <TableCell className="text-right">
                        <Badge variant={supplier.our_debt_to_them > 0 ? "destructive" : "secondary"}>
                          {formatCurrency(supplier.our_debt_to_them)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Badge variant={supplier.their_debt_to_us > 0 ? "warning" : "secondary"}>
                          {formatCurrency(supplier.their_debt_to_us)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center space-x-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => openTransactionDialog(supplier)}
                          title="Tranzaksiya Qo'shish"
                        >
                          <DollarSignIcon className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => openEditSupplierDialog(supplier)}
                          title="Tahrirlash"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        {/* <Button variant="ghost" size="icon" onClick={() => {}} title="Tarix">
                                                  <FileText className="h-4 w-4" />
                                                </Button> */}
                        {/* <Button variant="ghost" size="icon" onClick={() => {}} title="O'chirish">
                                                  <Trash2 className="h-4 w-4 text-red-500" />
                                                </Button> */}
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center">
                      Ta'minotchilar topilmadi.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Add/Edit Supplier Dialog */}
      <Dialog
        open={isAddSupplierDialogOpen || isEditSupplierDialogOpen}
        onOpenChange={isAddSupplierDialogOpen ? setIsAddSupplierDialogOpen : setIsEditSupplierDialogOpen}
      >
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {currentSupplier.id ? "Ta'minotchi ma'lumotlarini tahrirlash" : "Yangi ta'minotchi qo'shish"}
            </DialogTitle>
            <DialogDescription>
              {currentSupplier.id
                ? "Ta'minotchi ma'lumotlarini o'zgartiring."
                : "Yangi ta'minotchi uchun kerakli ma'lumotlarni kiriting."}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="name" className="text-right">
                Nomi
              </Label>
              <Input
                id="name"
                value={currentSupplier.name || ""}
                onChange={(e) => setCurrentSupplier({ ...currentSupplier, name: e.target.value })}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="contact_person" className="text-right">
                Aloqa uchun shaxs
              </Label>
              <Input
                id="contact_person"
                value={currentSupplier.contact_person || ""}
                onChange={(e) => setCurrentSupplier({ ...currentSupplier, contact_person: e.target.value })}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="phone" className="text-right">
                Telefon
              </Label>
              <Input
                id="phone"
                value={currentSupplier.phone || ""}
                onChange={(e) => setCurrentSupplier({ ...currentSupplier, phone: e.target.value })}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="email" className="text-right">
                Email
              </Label>
              <Input
                id="email"
                type="email"
                value={currentSupplier.email || ""}
                onChange={(e) => setCurrentSupplier({ ...currentSupplier, email: e.target.value })}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="brand_represented" className="text-right">
                Brend
              </Label>
              <Input
                id="brand_represented"
                value={currentSupplier.brand_represented || ""}
                onChange={(e) => setCurrentSupplier({ ...currentSupplier, brand_represented: e.target.value })}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="our_debt_to_them" className="text-right">
                Bizning qarzimiz
              </Label>
              <Input
                id="our_debt_to_them"
                type="number"
                value={currentSupplier.our_debt_to_them || 0}
                onChange={(e) =>
                  setCurrentSupplier({ ...currentSupplier, our_debt_to_them: Number.parseFloat(e.target.value) })
                }
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="their_debt_to_us" className="text-right">
                Ularning qarzi
              </Label>
              <Input
                id="their_debt_to_us"
                type="number"
                value={currentSupplier.their_debt_to_us || 0}
                onChange={(e) =>
                  setCurrentSupplier({ ...currentSupplier, their_debt_to_us: Number.parseFloat(e.target.value) })
                }
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="notes" className="text-right">
                Izohlar
              </Label>
              <Input
                id="notes"
                value={currentSupplier.notes || ""}
                onChange={(e) => setCurrentSupplier({ ...currentSupplier, notes: e.target.value })}
                className="col-span-3"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setIsAddSupplierDialogOpen(false)
                setIsEditSupplierDialogOpen(false)
                setCurrentSupplier({})
              }}
            >
              Bekor qilish
            </Button>
            <Button type="submit" onClick={handleAddOrUpdateSupplier}>
              {currentSupplier.id ? "Saqlash" : "Qo'shish"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Transaction Dialog */}
      <Dialog open={isTransactionDialogOpen} onOpenChange={setIsTransactionDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Tranzaksiya qo'shish: {selectedSupplier?.name}</DialogTitle>
            <DialogDescription>Ta'minotchi bilan bog'liq moliyaviy operatsiyani kiriting.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="transaction_type" className="text-right">
                Turi
              </Label>
              <select
                id="transaction_type"
                value={transactionForm.type}
                onChange={(e) =>
                  setTransactionForm({ ...transactionForm, type: e.target.value as SupplierTransaction["type"] })
                }
                className="col-span-3 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border"
              >
                <option value="goods_received">Mahsulot keldi</option>
                <option value="payment_made">To'lov qilindi</option>
                <option value="goods_returned">Mahsulot qaytarildi</option>
                <option value="payment_received">To'lov keldi (ulardan)</option>
                <option value="debt_adjustment">Qarzni to'g'rilash</option>
              </select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="transaction_amount" className="text-right">
                Summa
              </Label>
              <Input
                id="transaction_amount"
                type="number"
                value={transactionForm.amount || ""}
                onChange={(e) => setTransactionForm({ ...transactionForm, amount: Number.parseFloat(e.target.value) })}
                className="col-span-3"
                placeholder="0"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="transaction_date" className="text-right">
                Sana
              </Label>
              <Input
                id="transaction_date"
                type="date"
                value={
                  transactionForm.transaction_date
                    ? new Date(transactionForm.transaction_date).toISOString().split("T")[0]
                    : ""
                }
                onChange={(e) => setTransactionForm({ ...transactionForm, transaction_date: e.target.value })}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="transaction_description" className="text-right">
                Izoh
              </Label>
              <Input
                id="transaction_description"
                value={transactionForm.description || ""}
                onChange={(e) => setTransactionForm({ ...transactionForm, description: e.target.value })}
                className="col-span-3"
                placeholder="Masalan, Nakladnoy #123"
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsTransactionDialogOpen(false)}>
              Bekor qilish
            </Button>
            <Button type="submit" onClick={handleAddTransaction}>
              Qo'shish
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
