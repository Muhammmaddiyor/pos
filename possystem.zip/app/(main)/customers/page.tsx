"use client"

import { useState, useMemo, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Plus, Users, CreditCard, Gift, Edit, Trash2 } from "lucide-react"
import type { Customer } from "@/lib/types"

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat("uz-UZ", { style: "currency", currency: "UZS", minimumFractionDigits: 0 }).format(amount)
}

export default function CustomersPage() {
  const [customers, setCustomers] = useState<Customer[]>(() => {
    if (typeof window === "undefined") return []
    try {
      const savedCustomers = window.localStorage.getItem("customers")
      return savedCustomers ? JSON.parse(savedCustomers) : []
    } catch (error) {
      console.error("Error parsing customers from localStorage:", error)
      return []
    }
  })

  useEffect(() => {
    try {
      window.localStorage.setItem("customers", JSON.stringify(customers))
      console.log("Customers saved to localStorage:", customers)
    } catch (error) {
      console.error("Error saving customers to localStorage:", error)
    }
  }, [customers])

  const [searchTerm, setSearchTerm] = useState("")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
    bonus_points: "0",
  })

  const filteredCustomers = useMemo(() => {
    return customers.filter(
      (customer) =>
        customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        customer.phone.includes(searchTerm) ||
        customer.email?.toLowerCase().includes(searchTerm.toLowerCase()),
    )
  }, [customers, searchTerm])

  const handleAddCustomer = () => {
    console.log("Adding customer with data:", formData)

    const newCustomer: Customer = {
      id: Date.now().toString(),
      name: formData.name,
      phone: formData.phone,
      email: formData.email || undefined,
      address: formData.address || undefined,
      bonus_points: Number.parseInt(formData.bonus_points) || 0,
      total_purchases: 0,
      debt_amount: 0,
      created_at: new Date().toISOString(),
    }

    setCustomers((prev) => {
      const updated = [...prev, newCustomer]
      console.log("Updated customers:", updated)
      return updated
    })

    resetForm()
    setIsAddDialogOpen(false)
  }

  const handleEditCustomer = () => {
    if (!editingCustomer) return

    const updatedCustomer: Customer = {
      ...editingCustomer,
      name: formData.name,
      phone: formData.phone,
      email: formData.email || undefined,
      address: formData.address || undefined,
      bonus_points: Number.parseInt(formData.bonus_points) || 0,
    }

    setCustomers(customers.map((c) => (c.id === editingCustomer.id ? updatedCustomer : c)))
    resetForm()
    setIsEditDialogOpen(false)
    setEditingCustomer(null)
  }

  const handleDeleteCustomer = (customerId: string) => {
    if (confirm("Bu mijozni o'chirishni xohlaysizmi?")) {
      setCustomers(customers.filter((c) => c.id !== customerId))
    }
  }

  const openEditDialog = (customer: Customer) => {
    setEditingCustomer(customer)
    setFormData({
      name: customer.name,
      phone: customer.phone || "",
      email: customer.email || "",
      address: customer.address || "",
      bonus_points: customer.bonus_points.toString(),
    })
    setIsEditDialogOpen(true)
  }

  const resetForm = () => {
    setFormData({
      name: "",
      phone: "",
      email: "",
      address: "",
      bonus_points: "0",
    })
  }

  const totalCustomers = customers.length
  const totalBonusPoints = customers.reduce((sum, c) => sum + c.bonus_points, 0)
  const totalDebt = customers.reduce((sum, c) => sum + c.debt_amount, 0)
  const customersWithDebt = customers.filter((c) => c.debt_amount > 0).length

  console.log("Rendering customers page with", customers.length, "customers")

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Mijozlar (CRM)</h1>
        <Button
          onClick={() => {
            console.log("Add customer button clicked")
            resetForm()
            setIsAddDialogOpen(true)
          }}
        >
          <Plus className="mr-2 h-4 w-4" />
          Yangi Mijoz
        </Button>
      </div>

      {/* Statistika kartalari */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Jami Mijozlar</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalCustomers}</div>
            <p className="text-xs text-muted-foreground">Ro'yxatdan o'tgan</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Jami Bonus</CardTitle>
            <Gift className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalBonusPoints}</div>
            <p className="text-xs text-muted-foreground">Ball</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Jami Qarz</CardTitle>
            <CreditCard className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{formatCurrency(totalDebt)}</div>
            <p className="text-xs text-muted-foreground">{customersWithDebt} ta mijoz</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">O'rtacha Xarid</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(customers.reduce((sum, c) => sum + c.total_purchases, 0) / totalCustomers || 0)}
            </div>
            <p className="text-xs text-muted-foreground">Har bir mijoz uchun</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList>
          <TabsTrigger value="all">Barcha Mijozlar</TabsTrigger>
          <TabsTrigger value="vip">VIP Mijozlar</TabsTrigger>
          <TabsTrigger value="debt">Qarzdorlar</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Mijozlar Ro'yxati</CardTitle>
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Mijozlarni qidirish..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Mijoz</TableHead>
                    <TableHead>Telefon</TableHead>
                    <TableHead>Bonus</TableHead>
                    <TableHead>Jami Xarid</TableHead>
                    <TableHead>Qarz</TableHead>
                    <TableHead>Holat</TableHead>
                    <TableHead>Amallar</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredCustomers.length > 0 ? (
                    filteredCustomers.map((customer) => (
                      <TableRow key={customer.id}>
                        <TableCell>
                          <div>
                            <p className="font-medium">{customer.name}</p>
                            {customer.email && <p className="text-sm text-muted-foreground">{customer.email}</p>}
                          </div>
                        </TableCell>
                        <TableCell>{customer.phone}</TableCell>
                        <TableCell>
                          <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                            {customer.bonus_points} ball
                          </Badge>
                        </TableCell>
                        <TableCell>{formatCurrency(customer.total_purchases)}</TableCell>
                        <TableCell>
                          {customer.debt_amount > 0 ? (
                            <span className="text-red-600 font-medium">{formatCurrency(customer.debt_amount)}</span>
                          ) : (
                            <span className="text-green-600">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {customer.total_purchases > 1000000 ? (
                            <Badge className="bg-purple-100 text-purple-800">VIP</Badge>
                          ) : customer.debt_amount > 0 ? (
                            <Badge variant="destructive">Qarzdor</Badge>
                          ) : (
                            <Badge className="bg-green-100 text-green-800">Faol</Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm" onClick={() => openEditDialog(customer)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDeleteCustomer(customer.id)}
                              className="text-destructive hover:text-destructive"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center h-24">
                        Mijozlar topilmadi.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="vip" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>VIP Mijozlar</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Mijoz</TableHead>
                    <TableHead>Jami Xarid</TableHead>
                    <TableHead>Bonus</TableHead>
                    <TableHead>Ro'yxatdan o'tgan</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {customers
                    .filter((c) => c.total_purchases > 1000000)
                    .map((customer) => (
                      <TableRow key={customer.id}>
                        <TableCell>
                          <div>
                            <p className="font-medium">{customer.name}</p>
                            <p className="text-sm text-muted-foreground">{customer.phone}</p>
                          </div>
                        </TableCell>
                        <TableCell className="font-medium text-green-600">
                          {formatCurrency(customer.total_purchases)}
                        </TableCell>
                        <TableCell>{customer.bonus_points} ball</TableCell>
                        <TableCell>{new Date(customer.created_at).toLocaleDateString("uz-UZ")}</TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="debt" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Qarzdor Mijozlar</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Mijoz</TableHead>
                    <TableHead>Telefon</TableHead>
                    <TableHead>Qarz Miqdori</TableHead>
                    <TableHead>Amallar</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {customers
                    .filter((c) => c.debt_amount > 0)
                    .map((customer) => (
                      <TableRow key={customer.id}>
                        <TableCell className="font-medium">{customer.name}</TableCell>
                        <TableCell>{customer.phone}</TableCell>
                        <TableCell className="font-medium text-red-600">
                          {formatCurrency(customer.debt_amount)}
                        </TableCell>
                        <TableCell>
                          <Button variant="outline" size="sm">
                            Qarzni To'lash
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Add Customer Dialog */}
      <Dialog
        open={isAddDialogOpen}
        onOpenChange={(open) => {
          console.log("Dialog open state changed to:", open)
          setIsAddDialogOpen(open)
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Yangi Mijoz Qo'shish</DialogTitle>
          </DialogHeader>
          <CustomerForm
            formData={formData}
            setFormData={setFormData}
            onSubmit={handleAddCustomer}
            onCancel={() => setIsAddDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Mijozni Tahrirlash</DialogTitle>
          </DialogHeader>
          <CustomerForm
            formData={formData}
            setFormData={setFormData}
            onSubmit={handleEditCustomer}
            onCancel={() => setIsEditDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  )
}

function CustomerForm({
  formData,
  setFormData,
  onSubmit,
  onCancel,
}: {
  formData: any
  setFormData: any
  onSubmit: () => void
  onCancel: () => void
}) {
  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="name">Ism-familiya *</Label>
        <Input
          id="name"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          placeholder="Mijoz ismini kiriting"
        />
      </div>

      <div>
        <Label htmlFor="phone">Telefon raqami *</Label>
        <Input
          id="phone"
          value={formData.phone}
          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
          placeholder="+998901234567"
        />
      </div>

      <div>
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          type="email"
          value={formData.email}
          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          placeholder="email@example.com"
        />
      </div>

      <div>
        <Label htmlFor="address">Manzil</Label>
        <Input
          id="address"
          value={formData.address}
          onChange={(e) => setFormData({ ...formData, address: e.target.value })}
          placeholder="Mijoz manzilini kiriting"
        />
      </div>

      <div>
        <Label htmlFor="bonus_points">Bonus ballari</Label>
        <Input
          id="bonus_points"
          type="number"
          value={formData.bonus_points}
          onChange={(e) => setFormData({ ...formData, bonus_points: e.target.value })}
          placeholder="0"
        />
      </div>

      <div className="flex gap-2 pt-4">
        <Button variant="outline" onClick={onCancel} className="flex-1">
          Bekor qilish
        </Button>
        <Button onClick={onSubmit} className="flex-1">
          Saqlash
        </Button>
      </div>
    </div>
  )
}
