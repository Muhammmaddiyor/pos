"use client"

import React from "react"

import { useState, useMemo, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Plus, CreditCard, AlertTriangle, DollarSign, Calendar, FileText, Phone, Trash2 } from "lucide-react"
import type { Customer } from "@/lib/types"

interface DebtRecord {
  id: string
  customer_id: string
  amount: number
  description: string
  due_date: string
  status: "active" | "overdue" | "paid" | "partial"
  created_at: string
  paid_amount: number
  remaining_amount: number
  payment_history: PaymentRecord[]
}

interface PaymentRecord {
  id: string
  debt_id: string
  amount: number
  payment_date: string
  payment_method: "cash" | "card" | "transfer"
  notes?: string
  employee_id: string
}

// Helper functions for localStorage
const loadFromLocalStorage = <T,>(key: string, defaultValue: T): T => {
  if (typeof window === "undefined") return defaultValue
  try {
    const item = window.localStorage.getItem(key)
    return item ? JSON.parse(item) : defaultValue
  } catch (error) {
    console.error(`Error loading ${key} from localStorage:`, error)
    return defaultValue
  }
}

const saveToLocalStorage = <T,>(key: string, value: T): void => {
  if (typeof window === "undefined") return
  try {
    window.localStorage.setItem(key, JSON.stringify(value))
  } catch (error) {
    console.error(`Error saving ${key} to localStorage:`, error)
  }
}

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat("uz-UZ", { style: "currency", currency: "UZS", minimumFractionDigits: 0 }).format(amount)
}

const statusLabels = {
  active: "Faol",
  overdue: "Muddati o'tgan",
  paid: "To'langan",
  partial: "Qisman to'langan",
}

const paymentMethodLabels = {
  cash: "Naqd",
  card: "Karta",
  transfer: "O'tkazma",
}

export default function DebtorsPage() {
  // Load ONLY customers from localStorage - NO DEFAULT CUSTOMERS
  const [customers, setCustomers] = useState<Customer[]>(() => {
    const storedCustomers = loadFromLocalStorage<Customer[]>("customers", [])
    console.log("Loaded customers from localStorage:", storedCustomers)

    // Filter out invalid customers
    const validCustomers = storedCustomers.filter(
      (customer) => customer && customer.id && customer.name && customer.name.trim() !== "",
    )

    console.log("Valid customers after filtering:", validCustomers)
    return validCustomers
  })

  const [debts, setDebts] = useState<DebtRecord[]>(() => loadFromLocalStorage<DebtRecord[]>("debts", []))
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedStatus, setSelectedStatus] = useState<string>("all")
  const [isAddDebtOpen, setIsAddDebtOpen] = useState(false)
  const [isPaymentOpen, setIsPaymentOpen] = useState(false)
  const [selectedDebt, setSelectedDebt] = useState<DebtRecord | null>(null)
  const [debtForm, setDebtForm] = useState({
    customer_id: "",
    amount: "",
    description: "",
    due_date: "",
  })
  const [paymentForm, setPaymentForm] = useState({
    amount: "",
    payment_method: "cash" as PaymentRecord["payment_method"],
    notes: "",
  })

  // Save data to localStorage when it changes
  useEffect(() => {
    saveToLocalStorage("debts", debts)
  }, [debts])

  // Listen for changes in localStorage (when customers are added in other tabs/sections)
  useEffect(() => {
    const handleStorageChange = () => {
      const storedCustomers = loadFromLocalStorage<Customer[]>("customers", [])
      console.log("Storage changed - reloading customers:", storedCustomers)

      const validCustomers = storedCustomers.filter(
        (customer) => customer && customer.id && customer.name && customer.name.trim() !== "",
      )

      console.log("Valid customers after storage change:", validCustomers)
      setCustomers(validCustomers)
    }

    // Listen for storage events
    window.addEventListener("storage", handleStorageChange)

    // Also check periodically for changes (in case of same-tab updates)
    const interval = setInterval(() => {
      const currentCustomers = loadFromLocalStorage<Customer[]>("customers", [])
      if (JSON.stringify(currentCustomers) !== JSON.stringify(customers)) {
        handleStorageChange()
      }
    }, 1000)

    return () => {
      window.removeEventListener("storage", handleStorageChange)
      clearInterval(interval)
    }
  }, [customers])

  const filteredDebts = useMemo(() => {
    return debts.filter((debt) => {
      const customer = customers.find((c) => c.id === debt.customer_id)
      const matchesSearch =
        customer?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        customer?.phone.includes(searchTerm) ||
        debt.description.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesStatus = selectedStatus === "all" || debt.status === selectedStatus
      return matchesSearch && matchesStatus
    })
  }, [debts, customers, searchTerm, selectedStatus])

  const handleAddDebt = () => {
    console.log("Adding debt with data:", debtForm)
    console.log("Available customers:", customers)

    if (!debtForm.customer_id) {
      console.log("No customer selected")
      alert("Iltimos, mijozni tanlang.")
      return
    }

    // Verify that the selected customer actually exists
    const selectedCustomer = customers.find((c) => c.id === debtForm.customer_id)
    if (!selectedCustomer) {
      console.log("Selected customer not found in current customers list")
      alert("Tanlangan mijoz topilmadi. Iltimos, boshqa mijoz tanlang.")
      return
    }

    if (!debtForm.amount || Number.parseFloat(debtForm.amount) <= 0) {
      console.log("Invalid amount:", debtForm.amount)
      alert("Qarz miqdori to'g'ri kiritilmagan.")
      return
    }

    if (!debtForm.description.trim()) {
      console.log("No description provided")
      alert("Tavsif kiritilmagan.")
      return
    }

    if (!debtForm.due_date) {
      console.log("No due date provided")
      alert("To'lov muddati kiritilmagan.")
      return
    }

    try {
      const newDebt: DebtRecord = {
        id: Date.now().toString(),
        customer_id: debtForm.customer_id,
        amount: Number.parseFloat(debtForm.amount),
        description: debtForm.description.trim(),
        due_date: debtForm.due_date,
        status: "active",
        created_at: new Date().toISOString(),
        paid_amount: 0,
        remaining_amount: Number.parseFloat(debtForm.amount),
        payment_history: [],
      }

      console.log("Creating new debt:", newDebt)
      setDebts([newDebt, ...debts])
      console.log("Debt added successfully")

      resetDebtForm()
      closeAddDebtDialog()
      alert("Qarz muvaffaqiyatli qo'shildi!")
    } catch (error) {
      console.error("Error adding debt:", error)
      alert("Xatolik yuz berdi: " + error.message)
    }
  }

  const handleAddPayment = () => {
    if (!selectedDebt) return
    const paymentAmount = Number.parseFloat(paymentForm.amount)
    if (paymentAmount <= 0 || paymentAmount > selectedDebt.remaining_amount) {
      alert("To'lov miqdori noto'g'ri kiritilgan yoki qoldiqdan ko'p.")
      return
    }

    const newPayment: PaymentRecord = {
      id: Date.now().toString(),
      debt_id: selectedDebt.id,
      amount: paymentAmount,
      payment_date: new Date().toISOString(),
      payment_method: paymentForm.payment_method,
      notes: paymentForm.notes,
      employee_id: "current_user",
    }

    const updatedDebt: DebtRecord = {
      ...selectedDebt,
      paid_amount: selectedDebt.paid_amount + paymentAmount,
      remaining_amount: selectedDebt.remaining_amount - paymentAmount,
      payment_history: [newPayment, ...selectedDebt.payment_history],
    }

    if (updatedDebt.remaining_amount <= 0) {
      updatedDebt.status = "paid"
      updatedDebt.remaining_amount = 0
    } else if (updatedDebt.paid_amount > 0) {
      updatedDebt.status = "partial"
    }

    setDebts(debts.map((debt) => (debt.id === selectedDebt.id ? updatedDebt : debt)))
    resetPaymentForm()
    closePaymentDialog()
  }

  const handleDeleteDebt = (debtId: string) => {
    if (confirm("Bu qarzni o'chirishni xohlaysizmi? Bu amalni qaytarib bo'lmaydi.")) {
      setDebts(debts.filter((d) => d.id !== debtId))
    }
  }

  const resetDebtForm = () => {
    setDebtForm({
      customer_id: "",
      amount: "",
      description: "",
      due_date: "",
    })
  }

  const resetPaymentForm = () => {
    setPaymentForm({
      amount: "",
      payment_method: "cash",
      notes: "",
    })
  }

  const getCustomerName = (customerId: string) => {
    const customer = customers.find((c) => c.id === customerId)
    return customer?.name || "Noma'lum mijoz"
  }

  const getCustomerPhone = (customerId: string) => {
    const customer = customers.find((c) => c.id === customerId)
    return customer?.phone || ""
  }

  const getStatusBadge = (status: DebtRecord["status"]) => {
    const colors = {
      active: "bg-blue-100 text-blue-800",
      overdue: "bg-red-100 text-red-800",
      paid: "bg-green-100 text-green-800",
      partial: "bg-yellow-100 text-yellow-800",
    }
    return <Badge className={`${colors[status]} hover:${colors[status]}`}>{statusLabels[status]}</Badge>
  }

  const getStatusIcon = (status: DebtRecord["status"]) => {
    switch (status) {
      case "active":
        return <CreditCard className="h-4 w-4 text-blue-600" />
      case "overdue":
        return <AlertTriangle className="h-4 w-4 text-red-600" />
      case "paid":
        return <DollarSign className="h-4 w-4 text-green-600" />
      case "partial":
        return <Calendar className="h-4 w-4 text-yellow-600" />
      default:
        return <CreditCard className="h-4 w-4" />
    }
  }

  const isOverdue = (dueDate: string) => {
    if (!dueDate) return false
    return new Date(dueDate) < new Date() && new Date(dueDate).toDateString() !== new Date(0).toDateString()
  }

  // Check for overdue debts and update their status
  useEffect(() => {
    const updatedDebts = debts.map((debt) => {
      if ((debt.status === "active" || debt.status === "partial") && isOverdue(debt.due_date)) {
        return { ...debt, status: "overdue" as const }
      }
      return debt
    })

    if (JSON.stringify(updatedDebts) !== JSON.stringify(debts)) {
      setDebts(updatedDebts)
    }
  }, [debts])

  const totalDebts = debts.length
  const activeDebts = debts.filter((d) => d.status === "active" || d.status === "partial").length
  const overdueDebts = debts.filter((d) => d.status === "overdue").length
  const totalDebtAmount = debts.reduce((sum, d) => sum + d.remaining_amount, 0)

  const generateReport = () => {
    if (debts.length === 0) {
      alert("Hisobot uchun ma'lumotlar mavjud emas.")
      return
    }
    const reportData = {
      date: new Date().toLocaleDateString("uz-UZ"),
      total: totalDebts,
      active: activeDebts,
      overdue: overdueDebts,
      totalAmount: totalDebtAmount,
    }

    alert(
      `QARZDORLAR HISOBOTI\n\nSana: ${reportData.date}\n\nJami qarzlar: ${reportData.total}\nFaol qarzlar: ${reportData.active}\nMuddati o'tgan: ${reportData.overdue}\n\nJami qarz miqdori: ${formatCurrency(reportData.totalAmount)}`,
    )
  }

  // Dialog references
  const addDebtDialogRef = React.useRef<HTMLDialogElement>(null)
  const paymentDialogRef = React.useRef<HTMLDialogElement>(null)

  // Open/close dialog functions
  const openAddDebtDialog = () => {
    console.log("Opening add debt dialog")
    console.log("Current customers available:", customers)
    resetDebtForm()
    if (addDebtDialogRef.current) {
      addDebtDialogRef.current.showModal()
      setIsAddDebtOpen(true)
    }
  }

  const closeAddDebtDialog = () => {
    if (addDebtDialogRef.current) {
      addDebtDialogRef.current.close()
      setIsAddDebtOpen(false)
    }
  }

  const openPaymentDialogModal = (debt: DebtRecord) => {
    setSelectedDebt(debt)
    setPaymentForm({
      amount: debt.remaining_amount.toString(),
      payment_method: "cash",
      notes: "",
    })
    if (paymentDialogRef.current) {
      paymentDialogRef.current.showModal()
      setIsPaymentOpen(true)
    }
  }

  const closePaymentDialog = () => {
    if (paymentDialogRef.current) {
      paymentDialogRef.current.close()
      setIsPaymentOpen(false)
      setSelectedDebt(null)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Qarzdorlar</h1>
        <div className="flex gap-2">
          <Button variant="outline" onClick={generateReport} disabled={debts.length === 0}>
            <FileText className="mr-2 h-4 w-4" />
            Hisobot
          </Button>
          <Button onClick={openAddDebtDialog}>
            <Plus className="mr-2 h-4 w-4" />
            Yangi Qarz
          </Button>
        </div>
      </div>

      {/* Show message if no customers */}
      {customers.length === 0 && (
        <Card className="border-yellow-200 bg-yellow-50">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-yellow-800">
              <AlertTriangle className="h-5 w-5" />
              <p>
                Hozircha mijozlar mavjud emas. Qarz qo'shish uchun avval <strong>"Mijozlar"</strong> bo'limida mijoz
                qo'shing.
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Jami Qarzlar</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalDebts}</div>
            <p className="text-xs text-muted-foreground">Barcha qarzlar</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Faol Qarzlar</CardTitle>
            <Calendar className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{activeDebts}</div>
            <p className="text-xs text-muted-foreground">Muddatida</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Muddati O'tgan</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{overdueDebts}</div>
            <p className="text-xs text-muted-foreground">Kechikkan</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Jami Miqdor</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalDebtAmount)}</div>
            <p className="text-xs text-muted-foreground">Qolgan qarz</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList>
          <TabsTrigger value="all">Barcha Qarzlar</TabsTrigger>
          <TabsTrigger value="active">Faol</TabsTrigger>
          <TabsTrigger value="overdue">Muddati O'tgan</TabsTrigger>
          <TabsTrigger value="payments">To'lovlar Tarixi</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Qarzdorlar Ro'yxati</CardTitle>
              <div className="flex gap-4 pt-2">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Mijoz, telefon yoki tavsif bo'yicha qidirish..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <select
                  className="border rounded-md px-3 py-2 w-auto md:w-48"
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value)}
                >
                  <option value="all">Barcha holatlar</option>
                  <option value="active">Faol</option>
                  <option value="overdue">Muddati o'tgan</option>
                  <option value="partial">Qisman to'langan</option>
                  <option value="paid">To'langan</option>
                </select>
              </div>
            </CardHeader>
            <CardContent>
              {filteredDebts.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Mijoz</TableHead>
                      <TableHead className="hidden md:table-cell">Qarz Miqdori</TableHead>
                      <TableHead className="hidden md:table-cell">To'langan</TableHead>
                      <TableHead>Qolgan</TableHead>
                      <TableHead>Muddat</TableHead>
                      <TableHead>Holat</TableHead>
                      <TableHead>Amallar</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredDebts.map((debt) => (
                      <TableRow
                        key={debt.id}
                        className={debt.status === "overdue" ? "bg-red-50 dark:bg-red-900/30" : ""}
                      >
                        <TableCell>
                          <div>
                            <p className="font-medium">{getCustomerName(debt.customer_id)}</p>
                            <p className="text-sm text-muted-foreground flex items-center gap-1">
                              <Phone className="h-3 w-3" />
                              {getCustomerPhone(debt.customer_id) || "-"}
                            </p>
                          </div>
                        </TableCell>
                        <TableCell className="font-medium hidden md:table-cell">
                          {formatCurrency(debt.amount)}
                        </TableCell>
                        <TableCell className="text-green-600 hidden md:table-cell">
                          {formatCurrency(debt.paid_amount)}
                        </TableCell>
                        <TableCell className="font-medium text-red-600">
                          {formatCurrency(debt.remaining_amount)}
                        </TableCell>
                        <TableCell>
                          <div>
                            <p
                              className={
                                isOverdue(debt.due_date) && debt.status !== "paid" ? "text-red-600 font-medium" : ""
                              }
                            >
                              {debt.due_date ? new Date(debt.due_date).toLocaleDateString("uz-UZ") : "-"}
                            </p>
                            {isOverdue(debt.due_date) && debt.status !== "paid" && (
                              <p className="text-xs text-red-600">
                                {Math.floor((Date.now() - new Date(debt.due_date).getTime()) / (1000 * 60 * 60 * 24))}{" "}
                                kun kechikkan
                              </p>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {getStatusIcon(debt.status)}
                            {getStatusBadge(debt.status)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            {debt.status !== "paid" && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => openPaymentDialogModal(debt)}
                                className="text-green-600 hover:text-green-700 border-green-600 hover:bg-green-50"
                                title="To'lov qilish"
                              >
                                <DollarSign className="h-4 w-4" />
                              </Button>
                            )}
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDeleteDebt(debt.id)}
                              className="text-red-600 hover:text-red-700 border-red-600 hover:bg-red-50"
                              title="Qarzni o'chirish"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <p className="text-sm text-muted-foreground p-4 text-center">
                  Hozircha qarzlar mavjud emas yoki qidiruvga mos kelmadi.
                </p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="active" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Faol Qarzlar</CardTitle>
            </CardHeader>
            <CardContent>
              {debts.filter((d) => d.status === "active" || d.status === "partial").length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Mijoz</TableHead>
                      <TableHead>Qolgan Miqdor</TableHead>
                      <TableHead>Muddat</TableHead>
                      <TableHead>Amallar</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {debts
                      .filter((d) => d.status === "active" || d.status === "partial")
                      .map((debt) => (
                        <TableRow key={debt.id}>
                          <TableCell className="font-medium">{getCustomerName(debt.customer_id)}</TableCell>
                          <TableCell className="font-medium text-red-600">
                            {formatCurrency(debt.remaining_amount)}
                          </TableCell>
                          <TableCell>
                            {debt.due_date ? new Date(debt.due_date).toLocaleDateString("uz-UZ") : "-"}
                          </TableCell>
                          <TableCell>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => openPaymentDialogModal(debt)}
                              className="text-green-600 hover:text-green-700 border-green-600 hover:bg-green-50"
                            >
                              To'lov Qabul Qilish
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              ) : (
                <p className="text-sm text-muted-foreground p-4 text-center">Faol qarzlar mavjud emas.</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="overdue" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Muddati O'tgan Qarzlar</CardTitle>
            </CardHeader>
            <CardContent>
              {debts.filter((d) => d.status === "overdue").length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Mijoz</TableHead>
                      <TableHead>Qarz Miqdori</TableHead>
                      <TableHead>Kechikish</TableHead>
                      <TableHead>Amallar</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {debts
                      .filter((d) => d.status === "overdue")
                      .map((debt) => (
                        <TableRow key={debt.id} className="bg-red-50 dark:bg-red-900/30">
                          <TableCell>
                            <div>
                              <p className="font-medium">{getCustomerName(debt.customer_id)}</p>
                              <p className="text-sm text-muted-foreground">
                                {getCustomerPhone(debt.customer_id) || "-"}
                              </p>
                            </div>
                          </TableCell>
                          <TableCell className="font-medium text-red-600">
                            {formatCurrency(debt.remaining_amount)}
                          </TableCell>
                          <TableCell className="text-red-600">
                            {debt.due_date
                              ? `${Math.floor((Date.now() - new Date(debt.due_date).getTime()) / (1000 * 60 * 60 * 24))} kun`
                              : "-"}
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-1">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => openPaymentDialogModal(debt)}
                                className="text-green-600 hover:text-green-700 border-green-600 hover:bg-green-50"
                              >
                                To'lov
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-blue-600 hover:text-blue-700 border-blue-600 hover:bg-blue-50"
                                title="Mijozga qo'ng'iroq qilish"
                              >
                                <Phone className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              ) : (
                <p className="text-sm text-muted-foreground p-4 text-center">Muddati o'tgan qarzlar mavjud emas.</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payments" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>To'lovlar Tarixi</CardTitle>
            </CardHeader>
            <CardContent>
              {debts.flatMap((d) => d.payment_history).length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Sana</TableHead>
                      <TableHead>Mijoz</TableHead>
                      <TableHead>Miqdor</TableHead>
                      <TableHead>Usul</TableHead>
                      <TableHead className="hidden md:table-cell">Eslatma</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {debts
                      .flatMap((debt) =>
                        debt.payment_history.map((payment) => ({
                          ...payment,
                          customer_name: getCustomerName(debt.customer_id),
                        })),
                      )
                      .sort((a, b) => new Date(b.payment_date).getTime() - new Date(a.payment_date).getTime())
                      .map((payment) => (
                        <TableRow key={payment.id}>
                          <TableCell>{new Date(payment.payment_date).toLocaleDateString("uz-UZ")}</TableCell>
                          <TableCell className="font-medium">{payment.customer_name}</TableCell>
                          <TableCell className="font-medium text-green-600">{formatCurrency(payment.amount)}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{paymentMethodLabels[payment.payment_method]}</Badge>
                          </TableCell>
                          <TableCell className="hidden md:table-cell">{payment.notes || "-"}</TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              ) : (
                <p className="text-sm text-muted-foreground p-4 text-center">To'lovlar tarixi mavjud emas.</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Add Debt Dialog */}
      <dialog ref={addDebtDialogRef} className="w-full max-w-md p-6 rounded-lg shadow-lg bg-white">
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Yangi Qarz Qo'shish</h3>
            <button onClick={closeAddDebtDialog} className="rounded-full p-1 hover:bg-gray-100" aria-label="Close">
              ✕
            </button>
          </div>

          <div className="space-y-4 py-2">
            <div>
              <Label htmlFor="customer">Mijoz *</Label>
              <select
                id="customer"
                className="w-full border rounded-md px-3 py-2 mt-1"
                value={debtForm.customer_id}
                onChange={(e) => {
                  console.log("Customer selected:", e.target.value)
                  setDebtForm({ ...debtForm, customer_id: e.target.value })
                }}
              >
                <option value="">Mijozni tanlang</option>
                {customers.length > 0 ? (
                  customers.map((customer) => (
                    <option key={customer.id} value={customer.id}>
                      {customer.name} ({customer.phone || "Telefon yo'q"})
                    </option>
                  ))
                ) : (
                  <option value="" disabled>
                    Mijozlar mavjud emas. Avval "Mijozlar" sahifasida qo'shing.
                  </option>
                )}
              </select>
              {customers.length === 0 && (
                <p className="text-sm text-yellow-600 mt-1">
                  ⚠️ Mijozlar mavjud emas. Avval "Mijozlar" bo'limida mijoz qo'shing.
                </p>
              )}
            </div>

            <div>
              <Label htmlFor="amount">Qarz miqdori *</Label>
              <Input
                id="amount"
                type="number"
                value={debtForm.amount}
                onChange={(e) => setDebtForm({ ...debtForm, amount: e.target.value })}
                placeholder="0"
              />
            </div>

            <div>
              <Label htmlFor="description">Tavsif *</Label>
              <Textarea
                id="description"
                value={debtForm.description}
                onChange={(e) => setDebtForm({ ...debtForm, description: e.target.value })}
                placeholder="Qarz sababi yoki mahsulot tavsifi"
              />
            </div>

            <div>
              <Label htmlFor="due_date">To'lov muddati *</Label>
              <Input
                id="due_date"
                type="date"
                value={debtForm.due_date}
                onChange={(e) => setDebtForm({ ...debtForm, due_date: e.target.value })}
              />
            </div>

            <div className="flex gap-2 pt-4">
              <Button variant="outline" onClick={closeAddDebtDialog} className="flex-1">
                Bekor qilish
              </Button>
              <Button onClick={handleAddDebt} className="flex-1" disabled={customers.length === 0}>
                Saqlash
              </Button>
            </div>
          </div>
        </div>
      </dialog>

      {/* Payment Dialog */}
      <dialog ref={paymentDialogRef} className="w-full max-w-md p-6 rounded-lg shadow-lg bg-white">
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">To'lov Qabul Qilish</h3>
            <button onClick={closePaymentDialog} className="rounded-full p-1 hover:bg-gray-100" aria-label="Close">
              ✕
            </button>
          </div>

          {selectedDebt && (
            <div className="space-y-4 py-2">
              <div className="bg-muted p-4 rounded-lg">
                <h3 className="font-medium mb-2">Qarz Ma'lumotlari:</h3>
                <p>
                  <span className="font-semibold">Mijoz:</span> {getCustomerName(selectedDebt.customer_id)}
                </p>
                <p>
                  <span className="font-semibold">Jami qarz:</span> {formatCurrency(selectedDebt.amount)}
                </p>
                <p>
                  <span className="font-semibold">To'langan:</span> {formatCurrency(selectedDebt.paid_amount)}
                </p>
                <p className="font-semibold text-lg">Qolgan: {formatCurrency(selectedDebt.remaining_amount)}</p>
              </div>

              <div>
                <Label htmlFor="payment_amount">To'lov miqdori *</Label>
                <Input
                  id="payment_amount"
                  type="number"
                  value={paymentForm.amount}
                  onChange={(e) => setPaymentForm({ ...paymentForm, amount: e.target.value })}
                  placeholder="0"
                  max={selectedDebt.remaining_amount}
                  min="0"
                />
              </div>

              <div>
                <Label htmlFor="payment_method">To'lov usuli *</Label>
                <select
                  id="payment_method"
                  className="w-full border rounded-md px-3 py-2 mt-1"
                  value={paymentForm.payment_method}
                  onChange={(e) => setPaymentForm({ ...paymentForm, payment_method: e.target.value as any })}
                >
                  <option value="cash">Naqd</option>
                  <option value="card">Karta</option>
                  <option value="transfer">O'tkazma</option>
                </select>
              </div>

              <div>
                <Label htmlFor="payment_notes">Eslatma</Label>
                <Textarea
                  id="payment_notes"
                  value={paymentForm.notes}
                  onChange={(e) => setPaymentForm({ ...paymentForm, notes: e.target.value })}
                  placeholder="Qo'shimcha ma'lumot"
                />
              </div>

              <div className="flex gap-2 pt-4">
                <Button variant="outline" onClick={closePaymentDialog} className="flex-1">
                  Bekor qilish
                </Button>
                <Button onClick={handleAddPayment} className="flex-1 bg-green-600 hover:bg-green-700">
                  To'lovni Qabul Qilish
                </Button>
              </div>
            </div>
          )}
        </div>
      </dialog>
    </div>
  )
}
