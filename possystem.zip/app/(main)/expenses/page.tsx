"use client"

import type React from "react"

import { useState, useMemo, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { DatePickerWithRange } from "@/components/ui/date-range-picker"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Search, Plus, DollarSign, TrendingDown, FileText, Edit, Trash2, Calendar, Tag } from "lucide-react"
import type { DateRange } from "react-day-picker"
import { addDays, format, subDays } from "date-fns"

interface Expense {
  id: string
  category_id: string
  amount: number
  description: string
  payment_method: "cash" | "card" | "transfer"
  employee_id: string
  created_at: string
  receipt_image?: string
  status: "pending" | "approved" | "rejected"
  approved_by?: string
  approved_at?: string
}

interface ExpenseCategory {
  id: string
  name: string
  description?: string
  is_active: boolean
}

// Default categories if none exist
const defaultCategories: ExpenseCategory[] = [
  {
    id: "cat_1",
    name: "Kommunal to'lovlar",
    description: "Elektr, suv, gaz va boshqa kommunal to'lovlar",
    is_active: true,
  },
  {
    id: "cat_2",
    name: "Ofis jihozlari",
    description: "Ofis uchun kerakli jihozlar va materiallar",
    is_active: true,
  },
  {
    id: "cat_3",
    name: "Transport",
    description: "Transport xarajatlari, yoqilg'i va ta'mirlash",
    is_active: true,
  },
  {
    id: "cat_4",
    name: "Ish haqi",
    description: "Xodimlar ish haqi va mukofotlar",
    is_active: true,
  },
  {
    id: "cat_5",
    name: "Marketing",
    description: "Reklama va marketing xarajatlari",
    is_active: true,
  },
]

// Helper functions for localStorage
const loadFromLocalStorage = <T,>(key: string, defaultValue: T): T => {
  if (typeof window === "undefined") return defaultValue
  try {
    const item = window.localStorage.getItem(key)
    return item ? JSON.parse(item) : defaultValue
  } catch (error) {
    console.error(`Error loading ${key} from localStorage:`, error)
    return defaultValue
  }
}

const saveToLocalStorage = <T,>(key: string, value: T): void => {
  if (typeof window === "undefined") return
  try {
    window.localStorage.setItem(key, JSON.stringify(value))
  } catch (error) {
    console.error(`Error saving ${key} to localStorage:`, error)
  }
}

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat("uz-UZ", { style: "currency", currency: "UZS", minimumFractionDigits: 0 }).format(amount)
}

const paymentMethodLabels = {
  cash: "Naqd",
  card: "Karta",
  transfer: "O'tkazma",
}

const statusLabels = {
  pending: "Kutilmoqda",
  approved: "Tasdiqlangan",
  rejected: "Rad etilgan",
}

export default function ExpensesPage() {
  const [expenses, setExpenses] = useState<Expense[]>(() => loadFromLocalStorage<Expense[]>("expenses", []))
  const [categories, setCategories] = useState<ExpenseCategory[]>(() =>
    loadFromLocalStorage<ExpenseCategory[]>("expense_categories", defaultCategories),
  )
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<string>("all")
  const [selectedStatus, setSelectedStatus] = useState<string>("all")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isCategoryDialogOpen, setIsCategoryDialogOpen] = useState(false)
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null)
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: subDays(new Date(), 30),
    to: new Date(),
  })
  const [formData, setFormData] = useState({
    category_id: "",
    amount: "",
    description: "",
    payment_method: "cash" as Expense["payment_method"],
  })
  const [categoryForm, setCategoryForm] = useState({
    name: "",
    description: "",
  })
  const [editingCategory, setEditingCategory] = useState<ExpenseCategory | null>(null)
  const [isCategoryListDialogOpen, setIsCategoryListDialogOpen] = useState(false)

  // Save data to localStorage when it changes
  useEffect(() => {
    saveToLocalStorage("expenses", expenses)
  }, [expenses])

  useEffect(() => {
    saveToLocalStorage("expense_categories", categories)
  }, [categories])

  const getCategoryName = (categoryId: string) => {
    return categories.find((c) => c.id === categoryId)?.name || "Noma'lum"
  }

  const filteredExpenses = useMemo(() => {
    return expenses.filter((expense) => {
      const matchesSearch =
        getCategoryName(expense.category_id).toLowerCase().includes(searchTerm.toLowerCase()) ||
        expense.description.toLowerCase().includes(searchTerm.toLowerCase())

      const matchesCategory = selectedCategory === "all" || expense.category_id === selectedCategory
      const matchesStatus = selectedStatus === "all" || expense.status === selectedStatus

      // Filter by date range
      const expenseDate = new Date(expense.created_at)
      const isInDateRange =
        (!dateRange?.from || expenseDate >= dateRange.from) &&
        (!dateRange?.to || expenseDate <= addDays(dateRange.to, 1))

      return matchesSearch && matchesCategory && matchesStatus && isInDateRange
    })
  }, [expenses, searchTerm, selectedCategory, selectedStatus, dateRange, categories])

  // Yangi harajat qo'shish funksiyasi
  const handleAddExpense = () => {
    console.log("Adding expense with data:", formData)

    // Validatsiya
    if (!formData.category_id) {
      alert("Iltimos, kategoriyani tanlang")
      return
    }

    if (!formData.amount || Number.parseFloat(formData.amount) <= 0) {
      alert("Iltimos, to'g'ri miqdorni kiriting")
      return
    }

    if (!formData.description.trim()) {
      alert("Iltimos, tavsifni kiriting")
      return
    }

    try {
      const newExpense: Expense = {
        id: Date.now().toString(),
        category_id: formData.category_id,
        amount: Number.parseFloat(formData.amount),
        description: formData.description.trim(),
        payment_method: formData.payment_method,
        employee_id: "current_user", // Haqiqiy tizimda bu joriy foydalanuvchi ID'si bo'lishi kerak
        created_at: new Date().toISOString(),
        status: "pending",
      }

      console.log("Creating new expense:", newExpense)
      setExpenses([newExpense, ...expenses])
      console.log("Expense added successfully")

      // Formani tozalash va dialogni yopish
      resetForm()
      setIsAddDialogOpen(false)

      // Muvaffaqiyatli qo'shilganligi haqida xabar
      alert("Harajat muvaffaqiyatli qo'shildi!")
    } catch (error) {
      console.error("Error adding expense:", error)
      alert("Xatolik yuz berdi: " + (error as Error).message)
    }
  }

  const handleEditExpense = () => {
    if (!editingExpense) return

    const updatedExpense: Expense = {
      ...editingExpense,
      category_id: formData.category_id,
      amount: Number.parseFloat(formData.amount),
      description: formData.description,
      payment_method: formData.payment_method,
    }

    setExpenses(expenses.map((e) => (e.id === editingExpense.id ? updatedExpense : e)))
    resetForm()
    setIsEditDialogOpen(false)
    setEditingExpense(null)
  }

  const handleDeleteExpense = (expenseId: string) => {
    if (confirm("Bu harajatni o'chirishni xohlaysizmi?")) {
      setExpenses(expenses.filter((e) => e.id !== expenseId))
    }
  }

  const handleApproveExpense = (expenseId: string) => {
    setExpenses(
      expenses.map((expense) => {
        if (expense.id === expenseId) {
          return {
            ...expense,
            status: "approved" as const,
            approved_by: "current_manager",
            approved_at: new Date().toISOString(),
          }
        }
        return expense
      }),
    )
  }

  const handleRejectExpense = (expenseId: string) => {
    setExpenses(
      expenses.map((expense) => {
        if (expense.id === expenseId) {
          return {
            ...expense,
            status: "rejected" as const,
          }
        }
        return expense
      }),
    )
  }

  // Kategoriya qo'shish funksiyasi
  const handleAddCategory = () => {
    if (!categoryForm.name.trim()) {
      alert("Iltimos, kategoriya nomini kiriting")
      return
    }

    try {
      const newCategory: ExpenseCategory = {
        id: Date.now().toString(),
        name: categoryForm.name.trim(),
        description: categoryForm.description.trim(),
        is_active: true,
      }

      setCategories([...categories, newCategory])
      resetCategoryForm()
      setIsCategoryDialogOpen(false)
      alert("Kategoriya muvaffaqiyatli qo'shildi!")
    } catch (error) {
      console.error("Error adding category:", error)
      alert("Xatolik yuz berdi: " + (error as Error).message)
    }
  }

  // Kategoriyani tahrirlash funksiyasi
  const handleEditCategory = () => {
    if (!editingCategory) return
    if (!categoryForm.name.trim()) {
      alert("Iltimos, kategoriya nomini kiriting")
      return
    }

    try {
      const updatedCategory: ExpenseCategory = {
        ...editingCategory,
        name: categoryForm.name.trim(),
        description: categoryForm.description.trim(),
      }

      setCategories(categories.map((c) => (c.id === editingCategory.id ? updatedCategory : c)))
      resetCategoryForm()
      setIsCategoryDialogOpen(false)
      setEditingCategory(null)
      alert("Kategoriya muvaffaqiyatli tahrirlandi!")
    } catch (error) {
      console.error("Error editing category:", error)
      alert("Xatolik yuz berdi: " + (error as Error).message)
    }
  }

  // Kategoriyani o'chirish funksiyasi
  const handleDeleteCategory = (categoryId: string) => {
    // Kategoriyaga bog'langan harajatlar bor-yo'qligini tekshirish
    const hasExpenses = expenses.some((expense) => expense.category_id === categoryId)

    if (hasExpenses) {
      alert("Bu kategoriyaga bog'langan harajatlar mavjud. Avval ularni boshqa kategoriyaga o'tkazing.")
      return
    }

    if (confirm("Bu kategoriyani o'chirishni xohlaysizmi?")) {
      setCategories(categories.filter((c) => c.id !== categoryId))
    }
  }

  const openEditDialog = (expense: Expense) => {
    setEditingExpense(expense)
    setFormData({
      category_id: expense.category_id,
      amount: expense.amount.toString(),
      description: expense.description,
      payment_method: expense.payment_method,
    })
    setIsEditDialogOpen(true)
  }

  const openEditCategoryDialog = (category: ExpenseCategory) => {
    setEditingCategory(category)
    setCategoryForm({
      name: category.name,
      description: category.description || "",
    })
    setIsCategoryDialogOpen(true)
  }

  const resetForm = () => {
    setFormData({
      category_id: "",
      amount: "",
      description: "",
      payment_method: "cash",
    })
  }

  const resetCategoryForm = () => {
    setCategoryForm({
      name: "",
      description: "",
    })
  }

  // Yangi harajat qo'shish dialogini ochish
  const openAddExpenseDialog = () => {
    resetForm()
    setIsAddDialogOpen(true)
  }

  // Yangi kategoriya qo'shish dialogini ochish
  const openAddCategoryDialog = () => {
    resetCategoryForm()
    setEditingCategory(null)
    setIsCategoryDialogOpen(true)
  }

  // Kategoriyalar ro'yxati dialogini ochish
  const openCategoryListDialog = () => {
    setIsCategoryListDialogOpen(true)
  }

  const getStatusBadge = (status: Expense["status"]) => {
    const colors = {
      pending: "bg-yellow-100 text-yellow-800",
      approved: "bg-green-100 text-green-800",
      rejected: "bg-red-100 text-red-800",
    }
    return <Badge className={colors[status]}>{statusLabels[status]}</Badge>
  }

  const getPaymentMethodBadge = (method: Expense["payment_method"]) => {
    const colors = {
      cash: "bg-blue-100 text-blue-800",
      card: "bg-purple-100 text-purple-800",
      transfer: "bg-indigo-100 text-indigo-800",
    }
    return <Badge className={colors[method]}>{paymentMethodLabels[method]}</Badge>
  }

  const totalExpenses = useMemo(() => {
    return filteredExpenses.reduce((sum, expense) => {
      if (expense.status === "approved" || expense.status === "pending") {
        return sum + expense.amount
      }
      return sum
    }, 0)
  }, [filteredExpenses])

  const expensesByCategory = useMemo(() => {
    const result: { [key: string]: number } = {}
    filteredExpenses.forEach((expense) => {
      if (expense.status === "approved" || expense.status === "pending") {
        const categoryName = getCategoryName(expense.category_id)
        result[categoryName] = (result[categoryName] || 0) + expense.amount
      }
    })
    return result
  }, [filteredExpenses, categories])

  const generateReport = () => {
    const reportData = {
      date: new Date().toLocaleDateString("uz-UZ"),
      totalExpenses: formatCurrency(totalExpenses),
      expensesByCategory: Object.entries(expensesByCategory).map(([category, amount]) => ({
        category,
        amount: formatCurrency(amount),
      })),
      dateRange: dateRange
        ? `${dateRange.from ? format(dateRange.from, "dd.MM.yyyy") : ""} - ${
            dateRange.to ? format(dateRange.to, "dd.MM.yyyy") : ""
          }`
        : "Barcha vaqt",
    }

    console.log("Hisobot ma'lumotlari:", reportData)
    alert("Hisobot yaratildi! Konsol loglarini tekshiring.")
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-3xl font-bold">Harajatlar</h1>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" onClick={openCategoryListDialog}>
            <Tag className="mr-2 h-4 w-4" />
            Kategoriyalar
          </Button>

          <Button variant="outline" size="sm" onClick={generateReport}>
            <FileText className="mr-2 h-4 w-4" />
            Hisobot
          </Button>

          {/* Yangi harajat qo'shish tugmasi */}
          <Button onClick={openAddExpenseDialog}>
            <Plus className="mr-2 h-4 w-4" />
            Yangi Harajat
          </Button>
        </div>
      </div>

      {/* Statistika kartalari */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Jami Harajatlar</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalExpenses)}</div>
            <p className="text-xs text-muted-foreground">Tanlangan davr uchun</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Eng Katta Harajat</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(Math.max(...filteredExpenses.map((e) => (e.status !== "rejected" ? e.amount : 0)), 0))}
            </div>
            <p className="text-xs text-muted-foreground">
              {getCategoryName(
                filteredExpenses.reduce(
                  (max, e) => (e.status !== "rejected" && e.amount > (max ? max.amount : 0) ? e : max),
                  null as Expense | null,
                )?.category_id || "",
              )}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Kutilayotgan Harajatlar</CardTitle>
            <Calendar className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(filteredExpenses.reduce((sum, e) => (e.status === "pending" ? sum + e.amount : sum), 0))}
            </div>
            <p className="text-xs text-muted-foreground">
              {filteredExpenses.filter((e) => e.status === "pending").length} ta tasdiqlanmagan
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Asosiy kontent */}
      <Card>
        <CardHeader>
          <CardTitle>Harajatlar Ro'yxati</CardTitle>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Harajatlarni qidirish..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex flex-wrap gap-2">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Kategoriya" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Barcha kategoriyalar</SelectItem>
                  {categories.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Holat" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Barcha holatlar</SelectItem>
                  <SelectItem value="pending">Kutilmoqda</SelectItem>
                  <SelectItem value="approved">Tasdiqlangan</SelectItem>
                  <SelectItem value="rejected">Rad etilgan</SelectItem>
                </SelectContent>
              </Select>
              <DatePickerWithRange date={dateRange} setDate={setDateRange} />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[500px]">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Sana</TableHead>
                  <TableHead>Kategoriya</TableHead>
                  <TableHead>Tavsif</TableHead>
                  <TableHead>Miqdor</TableHead>
                  <TableHead>To'lov Usuli</TableHead>
                  <TableHead>Holat</TableHead>
                  <TableHead>Amallar</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredExpenses.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-4 text-muted-foreground">
                      Harajatlar topilmadi
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredExpenses.map((expense) => (
                    <TableRow key={expense.id}>
                      <TableCell>{new Date(expense.created_at).toLocaleDateString("uz-UZ")}</TableCell>
                      <TableCell className="font-medium">{getCategoryName(expense.category_id)}</TableCell>
                      <TableCell className="max-w-xs truncate" title={expense.description}>
                        {expense.description}
                      </TableCell>
                      <TableCell className="font-medium">{formatCurrency(expense.amount)}</TableCell>
                      <TableCell>{getPaymentMethodBadge(expense.payment_method)}</TableCell>
                      <TableCell>{getStatusBadge(expense.status)}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          {expense.status === "pending" && (
                            <>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleApproveExpense(expense.id)}
                                className="h-8 w-8 p-0 text-green-600"
                              >
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="2"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  className="h-4 w-4"
                                >
                                  <polyline points="20 6 9 17 4 12" />
                                </svg>
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleRejectExpense(expense.id)}
                                className="h-8 w-8 p-0 text-red-600"
                              >
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="2"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  className="h-4 w-4"
                                >
                                  <line x1="18" y1="6" x2="6" y2="18" />
                                  <line x1="6" y1="6" x2="18" y2="18" />
                                </svg>
                              </Button>
                            </>
                          )}
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => openEditDialog(expense)}
                            className="h-8 w-8 p-0"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDeleteExpense(expense.id)}
                            className="h-8 w-8 p-0 text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Kategoriyalar bo'yicha harajatlar */}
      <Card>
        <CardHeader>
          <CardTitle>Kategoriyalar Bo'yicha Harajatlar</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Kategoriya</TableHead>
                <TableHead className="text-right">Miqdor</TableHead>
                <TableHead className="text-right">Foiz</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {Object.entries(expensesByCategory).map(([category, amount]) => (
                <TableRow key={category}>
                  <TableCell className="font-medium">{category}</TableCell>
                  <TableCell className="text-right">{formatCurrency(amount)}</TableCell>
                  <TableCell className="text-right">
                    {totalExpenses > 0 ? ((amount / totalExpenses) * 100).toFixed(1) : 0}%
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Yangi harajat qo'shish dialog oynasi */}
      {isAddDialogOpen && (
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Yangi Harajat Qo'shish</DialogTitle>
            </DialogHeader>
            <ExpenseForm
              formData={formData}
              setFormData={setFormData}
              categories={categories}
              onSubmit={handleAddExpense}
              onCancel={() => setIsAddDialogOpen(false)}
            />
          </DialogContent>
        </Dialog>
      )}

      {/* Harajatni tahrirlash dialog oynasi */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Harajatni Tahrirlash</DialogTitle>
          </DialogHeader>
          <ExpenseForm
            formData={formData}
            setFormData={setFormData}
            categories={categories}
            onSubmit={handleEditExpense}
            onCancel={() => setIsEditDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>

      {/* Kategoriya qo'shish/tahrirlash dialog oynasi */}
      {isCategoryDialogOpen && (
        <Dialog open={isCategoryDialogOpen} onOpenChange={setIsCategoryDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingCategory ? "Kategoriyani Tahrirlash" : "Yangi Kategoriya Qo'shish"}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="category_name">Kategoriya nomi *</Label>
                <Input
                  id="category_name"
                  value={categoryForm.name}
                  onChange={(e) => setCategoryForm({ ...categoryForm, name: e.target.value })}
                  placeholder="Kategoriya nomini kiriting"
                />
                {!categoryForm.name.trim() && (
                  <p className="text-xs text-red-500 mt-1">Kategoriya nomi kiritish majburiy</p>
                )}
              </div>

              <div>
                <Label htmlFor="category_description">Tavsif</Label>
                <Textarea
                  id="category_description"
                  value={categoryForm.description}
                  onChange={(e) => setCategoryForm({ ...categoryForm, description: e.target.value })}
                  placeholder="Kategoriya tavsifini kiriting"
                />
              </div>

              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setIsCategoryDialogOpen(false)} className="flex-1">
                  Bekor qilish
                </Button>
                <Button onClick={editingCategory ? handleEditCategory : handleAddCategory} className="flex-1">
                  Saqlash
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Kategoriyalar ro'yxati dialog oynasi */}
      {isCategoryListDialogOpen && (
        <Dialog open={isCategoryListDialogOpen} onOpenChange={setIsCategoryListDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Harajat Kategoriyalari</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium">Kategoriyalar ro'yxati</h3>
                <Button onClick={openAddCategoryDialog} size="sm">
                  <Plus className="mr-2 h-4 w-4" />
                  Yangi Kategoriya
                </Button>
              </div>

              <ScrollArea className="h-[300px]">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nomi</TableHead>
                      <TableHead>Tavsif</TableHead>
                      <TableHead className="text-right">Amallar</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {categories.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={3} className="text-center py-4 text-muted-foreground">
                          Kategoriyalar topilmadi
                        </TableCell>
                      </TableRow>
                    ) : (
                      categories.map((category) => (
                        <TableRow key={category.id}>
                          <TableCell className="font-medium">{category.name}</TableCell>
                          <TableCell className="max-w-xs truncate" title={category.description}>
                            {category.description || "-"}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-1">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => openEditCategoryDialog(category)}
                                className="h-8 w-8 p-0"
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleDeleteCategory(category.id)}
                                className="h-8 w-8 p-0 text-destructive"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </ScrollArea>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}

// ExpenseForm komponentini yangilash
function ExpenseForm({
  formData,
  setFormData,
  categories,
  onSubmit,
  onCancel,
}: {
  formData: any
  setFormData: any
  categories: ExpenseCategory[]
  onSubmit: () => void
  onCancel: () => void
}) {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault() // Formani qayta yuklanishini oldini olish
    console.log("Form submitted with data:", formData)
    onSubmit()
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="category">Kategoriya *</Label>
        <Select
          value={formData.category_id}
          onValueChange={(value) => setFormData({ ...formData, category_id: value })}
        >
          <SelectTrigger>
            <SelectValue placeholder="Kategoriyani tanlang" />
          </SelectTrigger>
          <SelectContent>
            {categories.map((category) => (
              <SelectItem key={category.id} value={category.id}>
                {category.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {!formData.category_id && <p className="text-xs text-red-500 mt-1">Kategoriya tanlash majburiy</p>}
      </div>

      <div>
        <Label htmlFor="amount">Miqdor *</Label>
        <Input
          id="amount"
          type="number"
          value={formData.amount}
          onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
          placeholder="0"
          required
        />
        {formData.amount && Number.parseFloat(formData.amount) <= 0 && (
          <p className="text-xs text-red-500 mt-1">Miqdor 0 dan katta bo'lishi kerak</p>
        )}
      </div>

      <div>
        <Label htmlFor="description">Tavsif *</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          placeholder="Harajat tavsifini kiriting"
          required
        />
        {!formData.description.trim() && <p className="text-xs text-red-500 mt-1">Tavsif kiritish majburiy</p>}
      </div>

      <div>
        <Label htmlFor="payment_method">To'lov usuli *</Label>
        <Select
          value={formData.payment_method}
          onValueChange={(value: any) => setFormData({ ...formData, payment_method: value })}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="cash">Naqd</SelectItem>
            <SelectItem value="card">Karta</SelectItem>
            <SelectItem value="transfer">O'tkazma</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex gap-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel} className="flex-1">
          Bekor qilish
        </Button>
        <Button type="submit" className="flex-1">
          Saqlash
        </Button>
      </div>
    </form>
  )
}
