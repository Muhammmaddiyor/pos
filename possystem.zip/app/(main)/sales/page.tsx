"use client"

import { useState, useMemo, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Switch } from "@/components/ui/switch"
import {
  Search,
  ShoppingCart,
  DollarSign,
  X,
  Scan,
  CreditCard,
  Smartphone,
  Gift,
  Scale,
  ClipboardList,
  PackageSearch,
  Plus,
} from "lucide-react"
import ProductCard from "@/components/product-card"
import CartItemRow from "@/components/cart-item-row"
import type { Product, CartItem, Customer, StockBatch } from "@/lib/types"

const initialProducts: Product[] = []
const initialCustomers: Customer[] = []

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat("uz-UZ", { style: "currency", currency: "UZS", minimumFractionDigits: 0 }).format(amount)
}

const formatQuantity = (quantity: number, unitType: "piece" | "weight") => {
  if (unitType === "weight") {
    return `${quantity.toFixed(3)} kg`
  }
  return `${quantity} ta`
}

const formatWeightInput = (value: string) => {
  if (value === "0") {
    return "0,"
  }
  if (value.length === 2 && value.startsWith("0") && /\d/.test(value[1])) {
    return `0,${value[1]}`
  }
  return value.replace(".", ",")
}

const parseWeightValue = (value: string) => {
  return Number.parseFloat(value.replace(",", "."))
}

// Helper function to load data from localStorage
const loadFromLocalStorage = <T,>(key: string, defaultValue: T): T => {
  if (typeof window === "undefined") return defaultValue
  try {
    const item = window.localStorage.getItem(key)
    return item ? JSON.parse(item) : defaultValue
  } catch (error) {
    console.error(`Error loading ${key} from localStorage:`, error)
    return defaultValue
  }
}

// Helper function to calculate reserved quantities
const calculateReservedQuantities = (reservedOrders: any[]) => {
  const reservedQuantities = new Map<string, number>()

  reservedOrders
    .filter((order) => order.status === "pending" || order.status === "ready")
    .forEach((order) => {
      order.products?.forEach((product: any) => {
        const currentReserved = reservedQuantities.get(product.id) || 0
        reservedQuantities.set(product.id, currentReserved + product.quantity)
      })
    })

  return reservedQuantities
}

interface PaymentMethod {
  type: "cash" | "card" | "qr" | "bonus" | "credit"
  amount: number
  label: string
}

export default function SalesPage() {
  // Load products and stock batches
  const [products, setProducts] = useState<Product[]>([])
  const [stockBatches, setStockBatches] = useState<StockBatch[]>([])
  const [customers, setCustomers] = useState<Customer[]>([])
  const [reservedOrders, setReservedOrders] = useState<any[]>([])

  // Calculate actual stock quantities from batches minus reserved quantities
  const productsWithStock = useMemo(() => {
    const reservedQuantities = calculateReservedQuantities(reservedOrders)

    return products.map((product) => {
      // Calculate total stock from all batches for this product
      const totalStock = stockBatches
        .filter((batch) => batch.product_id === product.id)
        .reduce((sum, batch) => sum + batch.quantity, 0)

      // Subtract reserved quantities
      const reservedQuantity = reservedQuantities.get(product.id) || 0
      const availableStock = Math.max(0, totalStock - reservedQuantity)

      return {
        ...product,
        stock_quantity: availableStock,
        total_stock: totalStock,
        reserved_quantity: reservedQuantity,
      }
    })
  }, [products, stockBatches, reservedOrders])

  const [cartItems, setCartItems] = useState<CartItem[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [barcodeInput, setBarcodeInput] = useState("")
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null)
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false)
  const [isWeightDialogOpen, setIsWeightDialogOpen] = useState(false)
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [weightInput, setWeightInput] = useState("")
  const [showCart, setShowCart] = useState(false)

  // Mixed payment states
  const [isMixedPayment, setIsMixedPayment] = useState(false)
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([{ type: "cash", amount: 0, label: "Naqd" }])

  // Load data on component mount
  useEffect(() => {
    const loadData = () => {
      const productsList = loadFromLocalStorage<Product[]>("products_list", [])
      const batches = loadFromLocalStorage<StockBatch[]>("stock_batches", [])
      const customersList = loadFromLocalStorage<Customer[]>("customers", [])
      const reservedOrdersList = loadFromLocalStorage<any[]>("reserved_orders", [])

      console.log("Loaded products:", productsList.length)
      console.log("Loaded batches:", batches.length)
      console.log("Loaded customers:", customersList.length)
      console.log("Loaded reserved orders:", reservedOrdersList.length)

      setProducts(productsList)
      setStockBatches(batches)
      setCustomers(customersList)
      setReservedOrders(reservedOrdersList)
    }

    loadData()
  }, [])

  const handleAddToCart = (product: Product, customQuantity?: number) => {
    if (product.stock_quantity <= 0) {
      alert("Bu mahsulot ombordan tugagan yoki band qilingan!")
      return
    }

    if (product.unit_type === "weight" && customQuantity === undefined) {
      setSelectedProduct(product)
      setWeightInput("")
      setIsWeightDialogOpen(true)
      return
    }

    const quantity = customQuantity || 1

    if (quantity > product.stock_quantity) {
      alert("Ombordan ko'p mahsulot so'ralyapti! Mavjud: " + product.stock_quantity)
      return
    }

    setCartItems((prevItems) => {
      const existingItem = prevItems.find((item) => item.id === product.id)
      if (existingItem) {
        const newQuantity = existingItem.quantity + quantity
        if (newQuantity > product.stock_quantity) {
          alert("Ombordan ko'p mahsulot so'ralyapti! Mavjud: " + product.stock_quantity)
          return prevItems
        }
        return prevItems.map((item) => (item.id === product.id ? { ...item, quantity: newQuantity } : item))
      }
      return [...prevItems, { ...product, quantity }]
    })

    if (window.innerWidth < 1024) {
      setShowCart(true)
    }
  }

  const handleWeightInputChange = (value: string) => {
    const formattedValue = formatWeightInput(value)
    setWeightInput(formattedValue)
  }

  const handleWeightConfirm = () => {
    if (!selectedProduct || !weightInput) return

    const weight = parseWeightValue(weightInput)
    if (isNaN(weight) || weight <= 0) {
      alert("To'g'ri vazn kiriting!")
      return
    }

    handleAddToCart(selectedProduct, weight)
    setIsWeightDialogOpen(false)
    setSelectedProduct(null)
    setWeightInput("")
  }

  const handleBarcodeSearch = () => {
    if (!barcodeInput.trim()) return

    const product = productsWithStock.find((p) => p.barcode === barcodeInput.trim())
    if (product) {
      handleAddToCart(product)
      setBarcodeInput("")
    } else {
      alert("Mahsulot topilmadi!")
    }
  }

  const handleUpdateQuantity = (productId: string, change: number) => {
    setCartItems((prevItems) => {
      const updatedItems = prevItems.map((item) => {
        if (item.id === productId) {
          let newQuantity: number

          if (item.unit_type === "weight") {
            newQuantity = Math.max(0, item.quantity + change * 0.1)
            newQuantity = Math.round(newQuantity * 1000) / 1000
          } else {
            newQuantity = Math.max(0, item.quantity + change)
          }

          const product = productsWithStock.find((p) => p.id === productId)
          if (product && newQuantity > product.stock_quantity) {
            alert("Ombordan ko'p mahsulot so'ralyapti! Mavjud: " + product.stock_quantity)
            return item
          }
          return { ...item, quantity: newQuantity }
        }
        return item
      })
      return updatedItems.filter((item) => item.quantity > 0)
    })
  }

  const handleSetExactQuantity = (productId: string, quantity: number) => {
    setCartItems((prevItems) => {
      const updatedItems = prevItems.map((item) => {
        if (item.id === productId) {
          const product = productsWithStock.find((p) => p.id === productId)
          if (product && quantity > product.stock_quantity) {
            alert("Ombordan ko'p mahsulot so'ralyapti! Mavjud: " + product.stock_quantity)
            return item
          }
          return { ...item, quantity: Math.max(0, quantity) }
        }
        return item
      })
      return updatedItems.filter((item) => item.quantity > 0)
    })
  }

  const handleRemoveFromCart = (productId: string) => {
    setCartItems((prevItems) => prevItems.filter((item) => item.id !== productId))
  }

  const handleClearCart = () => {
    setCartItems([])
    setSelectedCustomer(null)
  }

  const handleCheckout = () => {
    if (cartItems.length === 0) {
      alert("Savat bo'sh! Iltimos, mahsulot qo'shing.")
      return
    }
    // Reset payment methods
    setIsMixedPayment(false)
    setPaymentMethods([{ type: "cash", amount: totalAmount, label: "Naqd" }])
    setIsPaymentDialogOpen(true)
  }

  const addPaymentMethod = () => {
    setPaymentMethods((prev) => [...prev, { type: "card", amount: 0, label: "Karta" }])
  }

  const removePaymentMethod = (index: number) => {
    if (paymentMethods.length > 1) {
      setPaymentMethods((prev) => prev.filter((_, i) => i !== index))
    }
  }

  const updatePaymentMethod = (index: number, field: keyof PaymentMethod, value: any) => {
    setPaymentMethods((prev) => prev.map((method, i) => (i === index ? { ...method, [field]: value } : method)))
  }

  const getPaymentMethodLabel = (type: string) => {
    switch (type) {
      case "cash":
        return "Naqd"
      case "card":
        return "Karta"
      case "qr":
        return "QR/UzCard"
      case "bonus":
        return "Bonus"
      case "credit":
        return "Qarzga"
      default:
        return "Naqd"
    }
  }

  const totalPaid = useMemo(() => {
    return paymentMethods.reduce((sum, method) => sum + (method.amount || 0), 0)
  }, [paymentMethods])

  const handlePayment = () => {
    if (totalPaid < totalAmount) {
      alert("Yetarli summa kiritilmagan!")
      return
    }

    // Check if credit payment requires customer
    const hasCreditPayment = paymentMethods.some((method) => method.type === "credit" && method.amount > 0)
    if (hasCreditPayment && !selectedCustomer) {
      alert("Qarzga sotish uchun mijoz tanlanishi shart!")
      return
    }

    // Update customer debt if there's credit payment
    if (hasCreditPayment && selectedCustomer) {
      const creditAmount = paymentMethods
        .filter((method) => method.type === "credit")
        .reduce((sum, method) => sum + method.amount, 0)

      const updatedCustomers = customers.map((c) =>
        c.id === selectedCustomer.id ? { ...c, debt_amount: c.debt_amount + creditAmount } : c,
      )
      setCustomers(updatedCustomers)

      // Save updated customers to localStorage
      if (typeof window !== "undefined") {
        try {
          window.localStorage.setItem("customers", JSON.stringify(updatedCustomers))
        } catch (error) {
          console.error("Error saving customers:", error)
        }
      }
    }

    // Create payment summary
    const paymentSummary = paymentMethods
      .filter((method) => method.amount > 0)
      .map((method) => `${getPaymentMethodLabel(method.type)}: ${formatCurrency(method.amount)}`)
      .join("\n")

    const changeAmount = totalPaid - totalAmount
    const alertMessage = `To'lov muvaffaqiyatli!
Jami: ${formatCurrency(totalAmount)}
To'lov usullari:
${paymentSummary}
Jami to'landi: ${formatCurrency(totalPaid)}
Qaytim: ${formatCurrency(changeAmount)}
Mijoz: ${selectedCustomer?.name || "Noma'lum"}`

    // Update stock quantities by reducing from batches
    const updatedBatches = [...stockBatches]
    cartItems.forEach((cartItem) => {
      let remainingToReduce = cartItem.quantity

      // Find batches for this product and reduce quantities
      for (let i = 0; i < updatedBatches.length && remainingToReduce > 0; i++) {
        if (updatedBatches[i].product_id === cartItem.id && updatedBatches[i].quantity > 0) {
          const reduceAmount = Math.min(updatedBatches[i].quantity, remainingToReduce)
          updatedBatches[i] = {
            ...updatedBatches[i],
            quantity: updatedBatches[i].quantity - reduceAmount,
          }
          remainingToReduce -= reduceAmount
        }
      }
    })

    // Save updated batches
    setStockBatches(updatedBatches)
    if (typeof window !== "undefined") {
      try {
        window.localStorage.setItem("stock_batches", JSON.stringify(updatedBatches))
      } catch (error) {
        console.error("Error saving stock batches:", error)
      }
    }

    alert(alertMessage)
    console.log("Chek chiqarilmoqda...")

    handleClearCart()
    setIsPaymentDialogOpen(false)
    setShowCart(false)
  }

  const totalAmount = useMemo(() => {
    return cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
  }, [cartItems])

  const filteredProducts = useMemo(() => {
    return productsWithStock.filter(
      (product) => product.name.toLowerCase().includes(searchTerm.toLowerCase()) && product.is_active,
    )
  }, [productsWithStock, searchTerm])

  const getPaymentIcon = (method: string) => {
    switch (method) {
      case "cash":
        return <DollarSign className="h-4 w-4" />
      case "card":
        return <CreditCard className="h-4 w-4" />
      case "qr":
        return <Smartphone className="h-4 w-4" />
      case "bonus":
        return <Gift className="h-4 w-4" />
      case "credit":
        return <ClipboardList className="h-4 w-4" />
      default:
        return <DollarSign className="h-4 w-4" />
    }
  }

  // Listen for changes in localStorage from other tabs/windows
  useEffect(() => {
    const handleStorageChange = () => {
      const productsList = loadFromLocalStorage<Product[]>("products_list", [])
      const batches = loadFromLocalStorage<StockBatch[]>("stock_batches", [])
      const customersList = loadFromLocalStorage<Customer[]>("customers", [])
      const reservedOrdersList = loadFromLocalStorage<any[]>("reserved_orders", [])

      setProducts(productsList)
      setStockBatches(batches)
      setCustomers(customersList)
      setReservedOrders(reservedOrdersList)
    }

    if (typeof window !== "undefined") {
      window.addEventListener("storage", handleStorageChange)
    }

    return () => {
      if (typeof window !== "undefined") {
        window.removeEventListener("storage", handleStorageChange)
      }
    }
  }, [])

  return (
    <div className="flex flex-col lg:flex-row h-screen bg-muted/40 p-2 lg:p-4 gap-2 lg:gap-4">
      <div className="lg:hidden fixed bottom-4 right-4 z-50">
        <Button
          onClick={() => setShowCart(!showCart)}
          className="h-14 w-14 rounded-full bg-green-600 hover:bg-green-700 shadow-lg"
          size="icon"
        >
          <div className="relative">
            <ShoppingCart className="h-6 w-6" />
            {cartItems.length > 0 && (
              <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                {cartItems.length}
              </Badge>
            )}
          </div>
        </Button>
      </div>

      <div className={`${showCart ? "hidden" : "flex"} lg:flex lg:w-3/5 flex-col`}>
        <Card className="flex-grow flex flex-col">
          <CardHeader className="pb-3">
            <CardTitle className="text-xl lg:text-2xl">Sotuv Nuqtasi</CardTitle>
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Mahsulotlarni qidirish..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div className="flex gap-1">
                <Input
                  type="text"
                  placeholder="Barkod..."
                  className="w-24 sm:w-32"
                  value={barcodeInput}
                  onChange={(e) => setBarcodeInput(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleBarcodeSearch()}
                />
                <Button variant="outline" size="icon" onClick={handleBarcodeSearch}>
                  <Scan className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="flex-grow p-0">
            <ScrollArea className="h-[calc(100vh-180px)] lg:h-[calc(100vh-200px)] p-2 lg:p-4">
              {filteredProducts.length > 0 ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2 lg:gap-4">
                  {filteredProducts.map((product) => (
                    <ProductCard key={product.id} product={product} onAddToCart={handleAddToCart} />
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
                  <PackageSearch className="h-12 w-12 mb-4 text-gray-400" />
                  <p className="text-lg">Hozircha mahsulotlar yo'q.</p>
                  <p className="text-sm text-gray-500">Iltimos, avval "Mahsulotlar" bo'limida mahsulot qo'shing.</p>
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      <div className={`${!showCart ? "hidden" : "flex"} lg:flex lg:w-2/5 flex-col`}>
        <Card className="flex-grow flex flex-col">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg lg:text-xl flex items-center gap-2">
                <span>Joriy Buyurtma</span>
                <Badge variant="secondary" className="text-xs lg:text-sm">
                  {cartItems.length} xil
                </Badge>
              </CardTitle>
              <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setShowCart(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
            <div className="flex gap-2">
              <Select
                onValueChange={(value) => {
                  const customer = customers.find((c) => c.id === value) || null
                  setSelectedCustomer(customer)
                }}
              >
                <SelectTrigger className="flex-1">
                  <SelectValue placeholder="Mijozni tanlang" />
                </SelectTrigger>
                <SelectContent>
                  {customers.length > 0 ? (
                    customers.map((customer) => (
                      <SelectItem key={customer.id} value={customer.id}>
                        <span className="block truncate">{customer.name}</span>
                        <span className="text-xs text-muted-foreground block">{customer.phone}</span>
                      </SelectItem>
                    ))
                  ) : (
                    <div className="p-4 text-center text-sm text-muted-foreground">
                      Mijozlar topilmadi.
                      <br />
                      Iltimos, avval "Mijozlar" bo'limida mijoz qo'shing.
                    </div>
                  )}
                </SelectContent>
              </Select>
            </div>
            {selectedCustomer && (
              <div className="text-xs lg:text-sm text-muted-foreground">
                Bonus: {selectedCustomer.bonus_points} ball | Qarz: {formatCurrency(selectedCustomer.debt_amount)}
              </div>
            )}
          </CardHeader>
          <CardContent className="flex-grow p-0">
            <ScrollArea className="h-[calc(50vh-120px)] lg:h-[calc(50vh-120px)] p-2 lg:p-4">
              {cartItems.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
                  <ShoppingCart className="h-8 w-8 lg:h-10 lg:w-10 mb-2" />
                  <p className="text-sm lg:text-base">Savatda mahsulot yo'q</p>
                </div>
              ) : (
                <div className="space-y-2 lg:space-y-3">
                  {cartItems.map((item) => (
                    <CartItemRow
                      key={item.id}
                      item={item}
                      onUpdateQuantity={handleUpdateQuantity}
                      onSetExactQuantity={handleSetExactQuantity}
                      onRemoveItem={handleRemoveFromCart}
                      formatCurrency={formatCurrency}
                      formatQuantity={formatQuantity}
                    />
                  ))}
                </div>
              )}
            </ScrollArea>
          </CardContent>
          {cartItems.length > 0 && <Separator />}
          <CardFooter className="flex flex-col gap-3 lg:gap-4 pt-3 lg:pt-4">
            <div className="w-full flex justify-between items-center text-lg lg:text-xl font-semibold">
              <span>Jami:</span>
              <span>{formatCurrency(totalAmount)}</span>
            </div>
            <div className="w-full grid grid-cols-2 gap-2">
              <Button variant="outline" onClick={handleClearCart} className="w-full">
                <X className="mr-2 h-4 w-4" /> Tozalash
              </Button>
              <Button onClick={handleCheckout} className="w-full bg-green-600 hover:bg-green-700 text-white">
                <DollarSign className="mr-2 h-4 w-4" /> To'lov
              </Button>
            </div>
          </CardFooter>
        </Card>
      </div>

      <Dialog open={isWeightDialogOpen} onOpenChange={setIsWeightDialogOpen}>
        <DialogContent className="sm:max-w-md mx-4">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-lg">
              <Scale className="h-5 w-5" />
              Vazn kiriting
            </DialogTitle>
          </DialogHeader>
          {selectedProduct && (
            <div className="space-y-4">
              <div className="text-center">
                <p className="text-lg font-medium">{selectedProduct.name}</p>
                <p className="text-sm text-muted-foreground">Narx: {formatCurrency(selectedProduct.price)} / kg</p>
                <p className="text-sm text-muted-foreground">Qoldiq: {selectedProduct.stock_quantity.toFixed(3)} kg</p>
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium">Vazn (kg):</Label>
                <Input
                  type="text"
                  inputMode="decimal"
                  value={weightInput}
                  onChange={(e) => handleWeightInputChange(e.target.value)}
                  placeholder="0,000"
                  className="text-center text-lg h-12"
                  autoFocus
                />
                {weightInput && !isNaN(parseWeightValue(weightInput)) && (
                  <p className="text-center text-sm text-muted-foreground">
                    Jami: {formatCurrency(selectedProduct.price * parseWeightValue(weightInput))}
                  </p>
                )}
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[0.1, 0.25, 0.5, 1.0].map((weight) => (
                  <Button
                    key={weight}
                    variant="outline"
                    size="sm"
                    onClick={() => setWeightInput(weight.toString().replace(".", ","))}
                    className="h-10"
                  >
                    {weight.toString().replace(".", ",")} kg
                  </Button>
                ))}
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setIsWeightDialogOpen(false)} className="flex-1 h-12">
                  Bekor qilish
                </Button>
                <Button onClick={handleWeightConfirm} className="flex-1 h-12 bg-green-600 hover:bg-green-700">
                  Savatga qo'shish
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
        <DialogContent className="sm:max-w-lg mx-4 max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-lg">To'lov</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="text-center">
              <p className="text-2xl font-bold">{formatCurrency(totalAmount)}</p>
              <p className="text-sm text-muted-foreground">Jami to'lov miqdori</p>
            </div>

            {/* Mixed Payment Toggle */}
            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div className="space-y-1">
                <Label className="text-sm font-medium">Aralash to'lov</Label>
                <p className="text-xs text-muted-foreground">Bir nechta usul bilan to'lash</p>
              </div>
              <Switch
                checked={isMixedPayment}
                onCheckedChange={(checked) => {
                  setIsMixedPayment(checked)
                  if (!checked) {
                    setPaymentMethods([{ type: "cash", amount: totalAmount, label: "Naqd" }])
                  } else {
                    setPaymentMethods([
                      { type: "cash", amount: 0, label: "Naqd" },
                      { type: "card", amount: 0, label: "Karta" },
                    ])
                  }
                }}
              />
            </div>

            {/* Payment Methods */}
            <div className="space-y-3">
              <Label>To'lov usullari:</Label>
              {paymentMethods.map((method, index) => (
                <div key={index} className="border p-3 rounded-lg space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {getPaymentIcon(method.type)}
                      <Select
                        value={method.type}
                        onValueChange={(value) => {
                          updatePaymentMethod(index, "type", value)
                          updatePaymentMethod(index, "label", getPaymentMethodLabel(value))
                        }}
                        disabled={false}
                      >
                        <SelectTrigger className="w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="cash">Naqd</SelectItem>
                          <SelectItem value="card">Karta</SelectItem>
                          <SelectItem value="qr">QR/UzCard</SelectItem>
                          <SelectItem value="bonus" disabled={!selectedCustomer}>
                            Bonus
                          </SelectItem>
                          <SelectItem value="credit" disabled={!selectedCustomer}>
                            Qarzga
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    {isMixedPayment && paymentMethods.length > 1 && (
                      <Button variant="ghost" size="sm" onClick={() => removePaymentMethod(index)}>
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm">Summa:</Label>
                    <Input
                      type="number"
                      value={method.amount || ""}
                      onChange={(e) => updatePaymentMethod(index, "amount", Number(e.target.value) || 0)}
                      className="h-10"
                      placeholder="0"
                    />
                  </div>

                  {/* Quick amount buttons for cash */}
                  {method.type === "cash" && (
                    <div className="grid grid-cols-4 gap-1">
                      {[
                        Math.ceil((totalAmount - totalPaid + method.amount) / 1000) * 1000,
                        Math.ceil((totalAmount - totalPaid + method.amount) / 5000) * 5000,
                        Math.ceil((totalAmount - totalPaid + method.amount) / 10000) * 10000,
                        Math.ceil((totalAmount - totalPaid + method.amount) / 50000) * 50000,
                      ].map((amount) => (
                        <Button
                          key={amount}
                          variant="outline"
                          size="sm"
                          onClick={() => updatePaymentMethod(index, "amount", amount)}
                          className="h-8 text-xs"
                        >
                          {(amount / 1000).toFixed(0)}k
                        </Button>
                      ))}
                    </div>
                  )}
                </div>
              ))}

              {isMixedPayment && (
                <Button variant="outline" onClick={addPaymentMethod} className="w-full">
                  <Plus className="h-4 w-4 mr-2" />
                  To'lov usuli qo'shish
                </Button>
              )}
            </div>

            {/* Payment Summary */}
            <div className="border p-3 rounded-lg bg-muted/50">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Jami to'lov:</span>
                  <span className="font-medium">{formatCurrency(totalAmount)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>To'landi:</span>
                  <span className={`font-medium ${totalPaid >= totalAmount ? "text-green-600" : "text-red-600"}`}>
                    {formatCurrency(totalPaid)}
                  </span>
                </div>
                <Separator />
                <div className="flex justify-between font-bold">
                  <span>Qaytim:</span>
                  <span className={`${totalPaid >= totalAmount ? "text-green-600" : "text-red-600"}`}>
                    {formatCurrency(Math.max(0, totalPaid - totalAmount))}
                  </span>
                </div>
                {totalPaid < totalAmount && (
                  <p className="text-xs text-red-600">Kamomad: {formatCurrency(totalAmount - totalPaid)}</p>
                )}
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <Button variant="outline" onClick={() => setIsPaymentDialogOpen(false)} className="flex-1 h-12">
                Bekor qilish
              </Button>
              <Button
                onClick={handlePayment}
                className="flex-1 h-12 bg-green-600 hover:bg-green-700"
                disabled={totalPaid < totalAmount}
              >
                To'lash va Chek chiqarish
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
